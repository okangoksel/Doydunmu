const http = require('http');
const fs = require('fs');
const path = require('path');


function getDrawableBase64(filename) {
  try {
    const p = path.join(__dirname, 'app/src/main/res/drawable', filename);
    if (fs.existsSync(p)) {
      const data = fs.readFileSync(p);
      return `data:image/jpeg;base64,${data.toString('base64')}`;
    }
  } catch (e) {
    // fallback
  }
  return null;
}

const zurnaImg = getDrawableBase64('fp_zurna_durum.jpg') || 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=600&auto=format&fit=crop&q=80';
const kofteImg = getDrawableBase64('fp_kofte_piyaz.jpg') || 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=600&auto=format&fit=crop&q=80';
const lahmacunImg = getDrawableBase64('fp_lahmacun_salata.jpg') || 'https://images.unsplash.com/photo-1541544741938-0af808871cc0?w=600&auto=format&fit=crop&q=80';
const burgerImg = getDrawableBase64('fp_gourmet_burger.jpg') || 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80';

const htmlContent = `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Doydunmu - Mekan ve Lezzet Keşfi</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            sans: ['"Plus Jakarta Sans"', 'sans-serif'],
            mono: ['"JetBrains Mono"', 'monospace'],
          },
          colors: {
            brand: {
              orange: '#FF5722',
              orangeDark: '#E64A19',
              orangeLight: '#FF8A65',
              green: '#10B981',
              red: '#EF4444',
              gold: '#F59E0B',
              slate: '#121212',
              surface: '#1E1E24',
              card: '#26262E',
              border: '#33333F',
            }
          }
        }
      }
    }
  </script>
  <style>
    body {
      background-color: #0b0b0e;
      color: #f8fafc;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .custom-scrollbar::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb {
      background: #33333f;
      border-radius: 4px;
    }
    .gauge-circle {
      transform: rotate(-90deg);
      transform-origin: 50% 50%;
    }
  </style>
</head>
<body class="min-h-screen flex flex-col justify-between selection:bg-orange-500 selection:text-white">

  <!-- TOP HEADER -->
  <header class="border-b border-brand-border bg-[#16161b] px-4 lg:px-8 py-3.5 sticky top-0 z-50 shadow-md">
    <div class="max-w-7xl mx-auto flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#E64A19] to-[#FF5722] flex items-center justify-center text-white shadow-lg shadow-orange-500/20">
          <i class="fa-solid fa-utensils text-lg"></i>
        </div>
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-xl font-extrabold tracking-tight text-white">Doydunmu <span class="text-brand-orange">Ye</span></h1>
            <span class="text-[10px] bg-brand-orange/20 text-brand-orange border border-brand-orange/40 font-bold px-1.5 py-0.5 rounded">FOTOĞRAFLI YORUM SİSTEMİ</span>
          </div>
          <p class="text-xs text-slate-400 hidden sm:block">Daha iyi yemekler, daha akıllı seçimler. Doğru seçim senin elinde.</p>
        </div>
      </div>

      <div class="flex items-center gap-2">
        <button onclick="requestPlayServicesLocation()" id="headerGpsBtn" class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/50 text-emerald-300 shadow">
          <i class="fa-solid fa-location-crosshairs text-emerald-400"></i>
          <span id="headerGpsText" class="hidden sm:inline">Play Services GPS</span>
          <span class="sm:hidden">GPS</span>
        </button>
        <button onclick="openAiAdvisorModal()" class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-lg shadow-indigo-500/20">
          <i class="fa-solid fa-wand-magic-sparkles"></i>
          <span>Yapay Zeka (AI)</span>
        </button>
        <button onclick="openFavoritesModal()" class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-rose-950/80 hover:bg-rose-900 border border-rose-500/50 text-rose-300 shadow relative">
          <i class="fa-solid fa-heart text-rose-400"></i>
          <span>Favorilerim</span>
          <span class="fav-count-badge bg-rose-500 text-white text-[9px] font-black px-1.5 py-0.2 rounded-full">2</span>
        </button>
        <button id="viewGalleryBtn" onclick="switchMainView('gallery')" class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-brand-orange text-white shadow">
          <i class="fa-solid fa-table-columns"></i>
          <span class="hidden sm:inline">6 Ekran Yan Yana</span>
          <span class="sm:hidden">6 Ekran</span>
        </button>
        <button id="viewInteractiveBtn" onclick="switchMainView('interactive')" class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-brand-surface hover:bg-brand-card text-slate-300 border border-brand-border">
          <i class="fa-solid fa-mobile-screen"></i>
          <span>Canlı Telefon</span>
        </button>
        <button onclick="openAddReviewDirect()" class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-orange-600 hover:bg-orange-500 text-white shadow">
          <i class="fa-solid fa-camera"></i>
          <span>+ Fotoğraflı Yorum</span>
        </button>
        <button onclick="toggleFlutterModal(true)" class="px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300">
          <i class="fa-solid fa-code"></i>
          <span class="hidden md:inline">Flutter Kodları</span>
          <span class="md:hidden">Kod</span>
        </button>
      </div>
    </div>
  </header>

  <!-- MAIN BODY -->
  <main class="flex-1 p-4 lg:p-8 max-w-7xl mx-auto w-full">

    <!-- SUB-BANNER INFO -->
    <div class="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-brand-surface via-[#202028] to-[#1a1a20] border border-brand-border">
      <div class="flex items-center gap-6 overflow-x-auto pb-2 md:pb-0">
        <div class="flex items-center gap-2 shrink-0">
          <div class="w-8 h-8 rounded-full bg-brand-card flex items-center justify-center text-brand-orange text-sm">
            <i class="fa-solid fa-location-crosshairs"></i>
          </div>
          <div>
            <div class="text-xs font-bold text-white">Gerçek Mekanlar</div>
            <div class="text-[10px] text-slate-400">GPS & Harita Konumu</div>
          </div>
        </div>
        <div class="flex items-center gap-2 shrink-0">
          <div class="w-8 h-8 rounded-full bg-brand-card flex items-center justify-center text-brand-gold text-sm">
            <i class="fa-solid fa-tag"></i>
          </div>
          <div>
            <div class="text-xs font-bold text-white">Fiyat Karşılaştırması</div>
            <div class="text-[10px] text-slate-400">Net Gramaj & Porsiyon</div>
          </div>
        </div>
        <div class="flex items-center gap-2 shrink-0">
          <div class="w-8 h-8 rounded-full bg-brand-card flex items-center justify-center text-brand-green text-sm">
            <i class="fa-solid fa-camera"></i>
          </div>
          <div>
            <div class="text-xs font-bold text-white">Fotoğraflı Denetim</div>
            <div class="text-[10px] text-slate-400">Masadan Yemek & Fiş Görselleri</div>
          </div>
        </div>
        <div class="flex items-center gap-2 shrink-0">
          <div class="w-8 h-8 rounded-full bg-brand-card flex items-center justify-center text-orange-400 text-sm">
            <i class="fa-solid fa-fire"></i>
          </div>
          <div>
            <div class="text-xs font-bold text-white">En İyi F/P Oranı</div>
            <div class="text-[10px] text-slate-400">%92+ Değer Şampiyonları</div>
          </div>
        </div>
      </div>
      <div class="text-right shrink-0">
        <span class="italic text-brand-orangeLight font-medium text-xs">"İyi yemek sadece lezzet değil, doğru seçimdir."</span>
      </div>
    </div>

    <!-- VIEW 1: 6 SCREENS SIDE-BY-SIDE (EXACT REPLICA OF USER'S UPLOADED MOCKUP) -->
    <div id="galleryView" class="block">
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6 items-start">

        <!-- SCREEN 1: Ana Sayfa & Bütçe -->
        <div class="flex flex-col items-center">
          <div class="w-full max-w-[270px] bg-brand-slate rounded-[38px] border-[5px] border-[#2d2d38] shadow-2xl overflow-hidden flex flex-col h-[560px] relative">
            <div class="px-5 pt-3 pb-2 flex justify-between items-center text-[11px] text-white font-semibold">
              <span>9:41</span>
              <div class="w-16 h-4 bg-black rounded-full mx-auto"></div>
              <div class="flex items-center gap-1 text-[10px]">
                <i class="fa-solid fa-signal"></i><i class="fa-solid fa-wifi"></i><i class="fa-solid fa-battery-full"></i>
              </div>
            </div>
            <div class="px-4 py-2 flex items-center justify-between border-b border-brand-border">
              <div class="flex items-center gap-2">
                <div class="w-6 h-6 rounded-md bg-brand-orange flex items-center justify-center text-white text-[10px]">
                  <i class="fa-solid fa-utensils"></i>
                </div>
                <span class="text-xs font-extrabold text-white">Doydunmu <span class="text-brand-orange">Ye</span></span>
              </div>
              <i class="fa-solid fa-bars text-slate-400 text-xs"></i>
            </div>
            <div class="p-3 flex-1 overflow-y-auto space-y-3 custom-scrollbar">
              <div class="p-3 rounded-2xl bg-gradient-to-br from-brand-card to-brand-surface border border-brand-border flex items-center gap-2">
                <div>
                  <h3 class="text-[12px] font-black text-white leading-tight">Bütçene ve konumuna en uygun yemekleri bul!</h3>
                  <p class="text-[9px] text-slate-400 mt-1 leading-snug">Az para, çok lezzet. Doğru seçim senin elinde.</p>
                </div>
                <img src="${zurnaImg}" class="w-12 h-12 rounded-xl object-cover shrink-0 border border-brand-border" alt="Dürüm">
              </div>
              <div class="p-3 rounded-2xl bg-brand-card border border-brand-orange/40">
                <div class="flex items-center gap-1.5 text-brand-orangeLight text-[10px] font-extrabold uppercase">
                  <i class="fa-solid fa-wallet"></i>
                  <span>Bütçe Aralığın</span>
                </div>
                <div class="text-xl font-black text-white mt-1">200 TL</div>
                <input type="range" min="50" max="500" value="200" class="w-full accent-brand-orange mt-2 cursor-pointer h-1 bg-brand-border rounded">
                <div class="flex justify-between text-[9px] text-slate-400 mt-1">
                  <span>50 TL</span>
                  <span>500 TL</span>
                </div>
              </div>
              <div class="p-2.5 rounded-xl bg-brand-card border border-brand-border flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <div class="w-6 h-6 rounded-lg bg-orange-500/20 text-brand-orange flex items-center justify-center text-xs">
                    <i class="fa-solid fa-location-dot"></i>
                  </div>
                  <div>
                    <div class="text-[9px] text-slate-400">Konumun</div>
                    <div class="text-xs font-bold text-white">Kadıköy</div>
                  </div>
                </div>
                <i class="fa-solid fa-chevron-right text-slate-500 text-xs"></i>
              </div>
              <button onclick="simulateGoToTab(1)" class="w-full py-2.5 bg-brand-orange hover:bg-brand-orangeDark text-white font-extrabold text-xs rounded-xl shadow-lg shadow-orange-500/30 flex items-center justify-center gap-1.5 transition active:scale-95">
                <i class="fa-solid fa-magnifying-glass"></i>
                <span>En İyisini Bul</span>
              </button>
            </div>
            <div class="px-3 py-2 bg-brand-surface border-t border-brand-border flex justify-around text-center">
              <div class="text-brand-orange cursor-pointer"><i class="fa-solid fa-house text-xs"></i><div class="text-[8px] font-bold">Ana Sayfa</div></div>
              <div class="text-slate-500 cursor-pointer" onclick="simulateGoToTab(1)"><i class="fa-solid fa-map text-xs"></i><div class="text-[8px]">Harita</div></div>
              <div class="text-slate-500 cursor-pointer" onclick="simulateGoToTab(3)"><i class="fa-solid fa-magnifying-glass text-xs"></i><div class="text-[8px]">Ara</div></div>
              <div class="text-slate-500 cursor-pointer"><i class="fa-regular fa-heart text-xs"></i><div class="text-[8px]">Favoriler</div></div>
              <div class="text-slate-500 cursor-pointer"><i class="fa-regular fa-user text-xs"></i><div class="text-[8px]">Profil</div></div>
            </div>
          </div>
          <div class="mt-3 text-center">
            <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-brand-orange text-white text-xs font-bold mr-1">1</span>
            <span class="text-xs font-bold text-white">Ana Sayfa & Bütçe</span>
            <p class="text-[10px] text-slate-400 mt-0.5">Bütçeni belirle, konumunu seç.</p>
          </div>
        </div>

        <!-- SCREEN 2: Harita Görünümü -->
        <div class="flex flex-col items-center">
          <div class="w-full max-w-[270px] bg-brand-slate rounded-[38px] border-[5px] border-[#2d2d38] shadow-2xl overflow-hidden flex flex-col h-[560px] relative">
            <div class="px-5 pt-3 pb-1 flex justify-between items-center text-[11px] text-white font-semibold">
              <span>9:41</span>
              <div class="w-16 h-4 bg-black rounded-full mx-auto"></div>
              <div class="flex items-center gap-1 text-[10px]">
                <i class="fa-solid fa-battery-full"></i>
              </div>
            </div>
            <div class="px-3 pt-1 pb-2 space-y-1.5 z-10 bg-brand-slate/90 backdrop-blur">
              <div class="flex items-center gap-1.5 bg-brand-surface rounded-xl px-2.5 py-1.5 border border-brand-border">
                <i class="fa-solid fa-magnifying-glass text-brand-orange text-xs"></i>
                <input type="text" value="Kadıköy" class="bg-transparent text-xs text-white focus:outline-none w-full" readonly>
                <i class="fa-solid fa-sliders text-slate-400 text-xs"></i>
              </div>
              <div class="flex gap-1 overflow-x-auto text-[10px] pb-1 custom-scrollbar">
                <span class="px-2 py-0.5 rounded-md bg-brand-orange text-white font-bold shrink-0">Tümü</span>
                <span class="px-2 py-0.5 rounded-md bg-brand-surface text-slate-300 border border-brand-border shrink-0">Döner</span>
                <span class="px-2 py-0.5 rounded-md bg-brand-surface text-slate-300 border border-brand-border shrink-0">Kebap</span>
                <span class="px-2 py-0.5 rounded-md bg-brand-surface text-slate-300 border border-brand-border shrink-0">Burger</span>
              </div>
            </div>
            <div class="flex-1 relative bg-[#181a20] overflow-hidden cursor-pointer" onclick="simulateGoToTab(2)">
              <svg class="w-full h-full opacity-35" viewBox="0 0 260 400">
                <path d="M0 60 Q 80 120 180 80 T 260 140" fill="none" stroke="#33374b" stroke-width="8"/>
                <path d="M40 0 L 80 400" fill="none" stroke="#252837" stroke-width="6"/>
                <path d="M0 260 Q 120 220 260 280" fill="none" stroke="#33374b" stroke-width="10"/>
              </svg>
              <span class="absolute top-16 left-6 text-[10px] font-bold text-slate-500">Kadıköy</span>
              <span class="absolute bottom-20 right-6 text-[10px] font-bold text-slate-600">Moda</span>

              <!-- Green Pins -->
              <div class="absolute top-8 left-12 animate-bounce">
                <div class="px-2 py-1 rounded-lg bg-emerald-600 text-white text-[9px] font-extrabold shadow flex items-center gap-1 border border-emerald-400">
                  <span>180 TL</span><span class="text-[8px] opacity-80">★ 4.8</span>
                </div>
                <div class="w-2 h-2 bg-emerald-600 rotate-45 mx-auto -mt-1"></div>
              </div>

              <!-- Red Pin -->
              <div class="absolute top-14 right-4">
                <div class="px-2 py-1 rounded-lg bg-red-600 text-white text-[9px] font-extrabold shadow flex items-center gap-1 border border-red-400">
                  <span>380 TL</span><span class="text-[8px] opacity-80">★ 2.9</span>
                </div>
                <div class="w-2 h-2 bg-red-600 rotate-45 mx-auto -mt-1"></div>
              </div>

              <!-- Green Pin 2 -->
              <div class="absolute bottom-28 left-10">
                <div class="px-2 py-1 rounded-lg bg-emerald-600 text-white text-[9px] font-extrabold shadow flex items-center gap-1 border border-emerald-400">
                  <span>180 TL</span><span class="text-[8px] opacity-80">★ 4.6</span>
                </div>
                <div class="w-2 h-2 bg-emerald-600 rotate-45 mx-auto -mt-1"></div>
              </div>

              <!-- Red Pin 2 -->
              <div class="absolute bottom-24 right-4">
                <div class="px-2 py-1 rounded-lg bg-red-600 text-white text-[9px] font-extrabold shadow flex items-center gap-1 border border-red-400">
                  <span>280 TL</span><span class="text-[8px] opacity-80">★ 3.2</span>
                </div>
                <div class="w-2 h-2 bg-red-600 rotate-45 mx-auto -mt-1"></div>
              </div>
            </div>
            <div class="px-3 py-2 bg-brand-surface border-t border-brand-border flex justify-around text-center">
              <div class="text-slate-500 cursor-pointer" onclick="simulateGoToTab(0)"><i class="fa-solid fa-house text-xs"></i><div class="text-[8px]">Ana Sayfa</div></div>
              <div class="text-brand-orange cursor-pointer"><i class="fa-solid fa-map text-xs"></i><div class="text-[8px] font-bold">Harita</div></div>
              <div class="text-slate-500 cursor-pointer" onclick="simulateGoToTab(3)"><i class="fa-solid fa-magnifying-glass text-xs"></i><div class="text-[8px]">Ara</div></div>
              <div class="text-slate-500 cursor-pointer"><i class="fa-regular fa-heart text-xs"></i><div class="text-[8px]">Favoriler</div></div>
              <div class="text-slate-500 cursor-pointer"><i class="fa-regular fa-user text-xs"></i><div class="text-[8px]">Profil</div></div>
            </div>
          </div>
          <div class="mt-3 text-center">
            <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-brand-orange text-white text-xs font-bold mr-1">2</span>
            <span class="text-xs font-bold text-white">Harita Görünümü</span>
            <p class="text-[10px] text-slate-400 mt-0.5">Yeşil ve kırmızı pinlerle F/P analizi.</p>
          </div>
        </div>

        <!-- SCREEN 3: Alt Açılır Pencere -->
        <div class="flex flex-col items-center">
          <div class="w-full max-w-[270px] bg-brand-slate rounded-[38px] border-[5px] border-[#2d2d38] shadow-2xl overflow-hidden flex flex-col h-[560px] relative">
            <div class="absolute inset-0 bg-[#16171f] opacity-40"></div>
            <div class="px-5 pt-3 pb-2 flex justify-between items-center text-[11px] text-white font-semibold relative z-10">
              <span>9:41</span>
              <div class="w-16 h-4 bg-black rounded-full mx-auto"></div>
              <i class="fa-solid fa-battery-full text-[10px]"></i>
            </div>
            <div class="mt-auto bg-brand-surface border-t border-brand-border rounded-t-3xl p-3.5 relative z-20 shadow-2xl space-y-2.5">
              <div class="flex justify-between items-center">
                <i class="fa-solid fa-xmark text-slate-400 text-xs cursor-pointer"></i>
                <div class="w-8 h-1 bg-slate-600 rounded-full mx-auto"></div>
                <div class="w-3"></div>
              </div>
              <div class="relative rounded-xl overflow-hidden h-28 border border-brand-border">
                <img src="${zurnaImg}" class="w-full h-full object-cover" alt="Zurna Dürüm">
                <div class="absolute top-2 right-2 bg-emerald-500 text-white text-[9px] font-black px-2 py-0.5 rounded-md shadow flex items-center gap-1">
                  <i class="fa-solid fa-fire text-[8px]"></i>
                  <span>%92 F/P Canavarı</span>
                </div>
              </div>
              <div class="flex items-start justify-between">
                <div>
                  <h4 class="text-sm font-black text-white">Zurna Döner</h4>
                  <div class="text-[10px] text-slate-400">Dönerci Ali Usta</div>
                  <div class="flex items-center gap-1 text-[10px] text-slate-300 mt-0.5">
                    <span class="text-brand-gold font-bold">★ 4.8</span>
                    <span class="text-slate-400">(1.248)</span>
                    <span>· 450 m</span>
                  </div>
                </div>
                <button onclick="toggleFavoriteFood({ id: '1', name: '70cm Tavuk Zurna Dürüm', shop: 'Dönerci Ali Usta', price: 180, fpScore: 96, img: '${zurnaImg}' })" class="text-rose-500 hover:text-rose-400 text-sm p-1 transition" title="Favorilere Ekle / Çıkar"><i class="fa-solid fa-heart"></i></button>
              </div>
              <div class="flex gap-1 text-[9px]">
                <span class="px-2 py-0.5 rounded bg-brand-card text-slate-300 border border-brand-border">Döner</span>
                <span class="px-2 py-0.5 rounded bg-brand-card text-slate-300 border border-brand-border">Öğrenci Dostu</span>
              </div>
              <div class="pt-1">
                <div class="text-base font-black text-white">180 TL <span class="text-[9px] text-slate-400 font-normal">(Ortalama)</span></div>
                <button onclick="simulateGoToTab(4)" class="w-full mt-2 py-2 bg-brand-orange hover:bg-brand-orangeDark text-white font-extrabold text-xs rounded-xl shadow flex items-center justify-center gap-1">
                  <span>Detayları Gör</span>
                  <i class="fa-solid fa-chevron-right text-[10px]"></i>
                </button>
              </div>
            </div>
          </div>
          <div class="mt-3 text-center">
            <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-brand-orange text-white text-xs font-bold mr-1">3</span>
            <span class="text-xs font-bold text-white">Alt Açılır Pencere</span>
            <p class="text-[10px] text-slate-400 mt-0.5">Pine dokununca mekan kartı açılır.</p>
          </div>
        </div>

        <!-- SCREEN 4: Arama & Filtreler -->
        <div class="flex flex-col items-center">
          <div class="w-full max-w-[270px] bg-brand-slate rounded-[38px] border-[5px] border-[#2d2d38] shadow-2xl overflow-hidden flex flex-col h-[560px] relative">
            <div class="px-5 pt-3 pb-2 flex justify-between items-center text-[11px] text-white font-semibold">
              <span>9:41</span>
              <div class="w-16 h-4 bg-black rounded-full mx-auto"></div>
              <i class="fa-solid fa-battery-full text-[10px]"></i>
            </div>
            <div class="px-3 py-1 flex items-center gap-2 border-b border-brand-border">
              <i class="fa-solid fa-chevron-left text-white text-xs cursor-pointer"></i>
              <h3 class="text-xs font-bold text-white flex-1 text-center pr-3">Ara</h3>
            </div>
            <div class="p-3 space-y-2 border-b border-brand-border">
              <div class="flex items-center gap-1.5 bg-brand-surface rounded-xl px-2.5 py-1.5 border border-brand-border">
                <i class="fa-solid fa-magnifying-glass text-slate-400 text-xs"></i>
                <input type="text" placeholder="Mekan, yemek ara..." class="bg-transparent text-[10px] text-white focus:outline-none w-full">
                <i class="fa-solid fa-sliders text-brand-orange text-xs"></i>
              </div>
            </div>
            <div class="p-2.5 flex-1 overflow-y-auto space-y-2 custom-scrollbar">
              <div class="p-2 rounded-xl bg-brand-card border border-brand-border flex gap-2 cursor-pointer hover:border-brand-orange/50 transition" onclick="simulateGoToTab(4)">
                <img src="${zurnaImg}" class="w-14 h-14 rounded-lg object-cover border border-brand-border shrink-0" alt="Zurna">
                <div class="flex-1 min-w-0">
                  <div class="flex items-start justify-between">
                    <h4 class="text-xs font-bold text-white truncate">Zurna Döner</h4>
                    <span class="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-black">%92</span>
                  </div>
                  <div class="text-[9px] text-brand-gold mt-0.5">★ 4.8 · Dönerci Ali Usta</div>
                  <div class="flex justify-between items-center mt-1">
                    <span class="text-[8px] text-brand-green font-bold">Öğrenci Dostu</span>
                    <span class="text-xs font-black text-white">180 TL</span>
                  </div>
                </div>
              </div>
              <div class="p-2 rounded-xl bg-brand-card border border-brand-border flex gap-2 cursor-pointer hover:border-brand-orange/50 transition" onclick="simulateGoToTab(4)">
                <img src="${kofteImg}" class="w-14 h-14 rounded-lg object-cover border border-brand-border shrink-0" alt="Köfte">
                <div class="flex-1 min-w-0">
                  <div class="flex items-start justify-between">
                    <h4 class="text-xs font-bold text-white truncate">Köfteci Yusuf</h4>
                    <span class="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-black">%88</span>
                  </div>
                  <div class="text-[9px] text-brand-gold mt-0.5">★ 4.5 · Köfte & Izgara</div>
                  <div class="flex justify-between items-center mt-1">
                    <span class="text-[8px] text-brand-green font-bold">F/P Canavarı</span>
                    <span class="text-xs font-black text-white">220 TL</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="px-3 py-2 bg-brand-surface border-t border-brand-border flex justify-around text-center">
              <div class="text-slate-500 cursor-pointer" onclick="simulateGoToTab(0)"><i class="fa-solid fa-house text-xs"></i><div class="text-[8px]">Ana Sayfa</div></div>
              <div class="text-slate-500 cursor-pointer" onclick="simulateGoToTab(1)"><i class="fa-solid fa-map text-xs"></i><div class="text-[8px]">Harita</div></div>
              <div class="text-brand-orange cursor-pointer"><i class="fa-solid fa-magnifying-glass text-xs"></i><div class="text-[8px] font-bold">Ara</div></div>
              <div class="text-slate-500 cursor-pointer"><i class="fa-regular fa-heart text-xs"></i><div class="text-[8px]">Favoriler</div></div>
              <div class="text-slate-500 cursor-pointer"><i class="fa-regular fa-user text-xs"></i><div class="text-[8px]">Profil</div></div>
            </div>
          </div>
          <div class="mt-3 text-center">
            <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-brand-orange text-white text-xs font-bold mr-1">4</span>
            <span class="text-xs font-bold text-white">Arama & Filtreler</span>
            <p class="text-[10px] text-slate-400 mt-0.5">Dükkan ve yemek arama.</p>
          </div>
        </div>

        <!-- SCREEN 5: Yemek İnceleme Detayı (Mekan Detayı) -->
        <div class="flex flex-col items-center">
          <div class="w-full max-w-[270px] bg-brand-slate rounded-[38px] border-[5px] border-[#2d2d38] shadow-2xl overflow-hidden flex flex-col h-[560px] relative">
            <div class="px-5 pt-3 pb-2 flex justify-between items-center text-[11px] text-white font-semibold">
              <span>9:41</span>
              <div class="w-16 h-4 bg-black rounded-full mx-auto"></div>
              <i class="fa-solid fa-battery-full text-[10px]"></i>
            </div>
            <div class="px-3 py-1 flex items-center justify-between border-b border-brand-border">
              <i class="fa-solid fa-chevron-left text-white text-xs cursor-pointer" onclick="simulateGoToTab(3)"></i>
              <h3 class="text-xs font-bold text-white">Mekan Detayı</h3>
              <i class="fa-regular fa-share-from-square text-slate-400 text-xs"></i>
            </div>
            <div class="p-3 flex-1 overflow-y-auto space-y-3 custom-scrollbar" id="screen5Content">
              <!-- CIRCULAR GAUGE METER (%88 DEĞER) -->
              <div class="flex flex-col items-center justify-center py-2">
                <div class="relative w-28 h-28 flex items-center justify-center">
                  <svg class="w-full h-full gauge-circle" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="42" fill="none" stroke="#25252e" stroke-width="8"/>
                    <circle cx="50" cy="50" r="42" fill="none" stroke="#10B981" stroke-width="8" stroke-dasharray="264" stroke-dashoffset="32" stroke-linecap="round"/>
                  </svg>
                  <div class="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span class="text-xl font-black text-white leading-none">%88</span>
                    <span class="text-[9px] font-extrabold text-emerald-400 tracking-wider">DEĞER</span>
                  </div>
                </div>
              </div>
              <div class="text-center">
                <h3 class="text-sm font-black text-white">Zurna Döner</h3>
                <div class="text-[10px] text-slate-400">Dönerci Ali Usta · 450 m</div>
              </div>

              <!-- Real Photo Gallery -->
              <div>
                <div class="flex justify-between items-center text-[10px] text-slate-400 mb-1.5">
                  <span class="font-bold text-white" id="galleryCountTitle">Masadan Fotoğraflar (3)</span>
                  <span class="text-brand-orange cursor-pointer" onclick="simulateGoToTab(5)">+ Fotoğraf Ekle</span>
                </div>
                <div class="grid grid-cols-3 gap-1.5" id="photoGalleryThumbnails">
                  <img src="${zurnaImg}" class="h-12 w-full object-cover rounded-lg border border-brand-border cursor-pointer hover:opacity-80 transition" onclick="openPhotoPreview('${zurnaImg}', 'Masadan Çıtır Zurna Dürüm Fotoğrafı')" alt="Dürüm">
                  <img src="${kofteImg}" class="h-12 w-full object-cover rounded-lg border border-brand-border cursor-pointer hover:opacity-80 transition" onclick="openPhotoPreview('${kofteImg}', 'Köfte ve Piyaz Masası')" alt="Köfte">
                  <img src="${burgerImg}" class="h-12 w-full object-cover rounded-lg border border-brand-border cursor-pointer hover:opacity-80 transition" onclick="openPhotoPreview('${burgerImg}', 'Restoran Adisyon Fişi Onaylı')" alt="Fiş">
                </div>
              </div>

              <!-- Reviews list with photos -->
              <div class="space-y-1.5" id="reviewsContainer">
                <div class="flex justify-between items-center text-[10px] text-slate-400">
                  <span class="font-bold text-white">Kullanıcı Yorumları (<span id="revCountSpan">2</span>)</span>
                  <span class="text-brand-orange cursor-pointer" onclick="simulateGoToTab(5)">Yorum Yaz</span>
                </div>

                <div class="p-2 rounded-xl bg-brand-card border border-brand-border space-y-1.5 text-[10px]">
                  <div class="flex items-center justify-between">
                    <div class="flex items-center gap-1.5">
                      <div class="w-5 h-5 rounded-full bg-orange-600/30 text-brand-orange text-[9px] flex items-center justify-center font-bold">LA</div>
                      <span class="font-bold text-white">Lezzet Avcısı</span>
                    </div>
                    <span class="text-[8px] bg-emerald-500/20 text-emerald-400 px-1 py-0.5 rounded font-bold">F/P Canavarı</span>
                  </div>
                  <p class="text-slate-300 text-[9px] leading-tight">Fiyatına göre gerçekten efsane. Eti çok lezzetli, porsiyon da doyurucu. Tavsiye ederim!</p>
                  <div class="flex items-center gap-1 text-[8px] text-brand-gold font-bold">
                    <i class="fa-solid fa-receipt"></i>
                    <span>Masadan Fiş Yüklendi · 180 TL</span>
                  </div>
                </div>
              </div>

              <button onclick="simulateGoToTab(5)" class="w-full py-2 bg-brand-orange hover:bg-brand-orangeDark text-white font-extrabold text-xs rounded-xl shadow transition flex items-center justify-center gap-1">
                <i class="fa-solid fa-camera"></i>
                <span>Fotoğraflı Yorum Ekle</span>
              </button>
            </div>
            <div class="px-3 py-2 bg-brand-surface border-t border-brand-border flex justify-around text-center">
              <div class="text-slate-500 cursor-pointer" onclick="simulateGoToTab(0)"><i class="fa-solid fa-house text-xs"></i><div class="text-[8px]">Ana Sayfa</div></div>
              <div class="text-slate-500 cursor-pointer" onclick="simulateGoToTab(1)"><i class="fa-solid fa-map text-xs"></i><div class="text-[8px]">Harita</div></div>
              <div class="text-slate-500 cursor-pointer" onclick="simulateGoToTab(3)"><i class="fa-solid fa-magnifying-glass text-xs"></i><div class="text-[8px]">Ara</div></div>
              <div class="text-slate-500 cursor-pointer"><i class="fa-regular fa-heart text-xs"></i><div class="text-[8px]">Favoriler</div></div>
              <div class="text-slate-500 cursor-pointer"><i class="fa-regular fa-user text-xs"></i><div class="text-[8px]">Profil</div></div>
            </div>
          </div>
          <div class="mt-3 text-center">
            <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-brand-orange text-white text-xs font-bold mr-1">5</span>
            <span class="text-xs font-bold text-white">Yemek İnceleme Detayı</span>
            <p class="text-[10px] text-slate-400 mt-0.5">Fotoğraflar, %88 değer ve yorumlar.</p>
          </div>
        </div>

        <!-- SCREEN 6: Yorum ve Fotoğraf Ekleme -->
        <div class="flex flex-col items-center">
          <div class="w-full max-w-[270px] bg-brand-slate rounded-[38px] border-[5px] border-[#2d2d38] shadow-2xl overflow-hidden flex flex-col h-[560px] relative">
            <div class="px-5 pt-3 pb-2 flex justify-between items-center text-[11px] text-white font-semibold">
              <span>9:41</span>
              <div class="w-16 h-4 bg-black rounded-full mx-auto"></div>
              <i class="fa-solid fa-battery-full text-[10px]"></i>
            </div>
            <div class="px-3 py-1 flex items-center justify-between border-b border-brand-border">
              <i class="fa-solid fa-xmark text-white text-xs cursor-pointer" onclick="simulateGoToTab(4)"></i>
              <h3 class="text-xs font-bold text-white">Yorum Ekle</h3>
              <div class="w-3"></div>
            </div>
            <div class="p-3 flex-1 overflow-y-auto space-y-3 custom-scrollbar">
              <!-- Real Photo Box with Input Trigger -->
              <input type="file" id="reviewPhotoInput" accept="image/*" class="hidden" onchange="handlePhotoUpload(event)">
              <div onclick="document.getElementById('reviewPhotoInput').click()" class="relative rounded-xl overflow-hidden h-28 border border-brand-border group cursor-pointer bg-brand-card flex flex-col items-center justify-center">
                <img id="previewUploadedImg" src="${zurnaImg}" class="w-full h-full object-cover" alt="Yemek">
                <div class="absolute inset-0 bg-black/60 hover:bg-black/40 flex flex-col items-center justify-center p-2 text-center transition">
                  <i class="fa-solid fa-camera text-brand-orange text-lg mb-1"></i>
                  <span class="text-[10px] font-bold text-white" id="photoUploadLabel">Fotoğraf Değiştir / Çek</span>
                  <p class="text-[8px] text-slate-300 leading-tight">Yemeğin masadaki halini veya kasa fişini yükle.</p>
                </div>
              </div>

              <!-- Dükkan Seçimi -->
              <div>
                <label class="text-[9px] text-slate-400 font-bold block mb-1">Dükkan / Mekan</label>
                <select id="reviewShopSelect" class="w-full bg-brand-surface border border-brand-border rounded-lg text-white text-[10px] p-1.5 focus:outline-none">
                  <option value="Dönerci Ali Usta - Zurna Döner">Dönerci Ali Usta - Zurna Döner</option>
                  <option value="Köfteci Yusuf - Tekirdağ Köfte">Köfteci Yusuf - Tekirdağ Köfte</option>
                  <option value="Pizza Locale - Taş Fırın">Pizza Locale - Taş Fırın</option>
                  <option value="Boğa Gurme Döner - Et Döner">Boğa Gurme Döner - Et Döner</option>
                </select>
              </div>

              <!-- Sliders (Lezzet, Doyuruculuk, F/P) -->
              <div class="space-y-2 text-[10px]">
                <div>
                  <div class="flex justify-between items-center text-slate-300">
                    <span class="font-bold flex items-center gap-1"><i class="fa-solid fa-burger text-brand-orange"></i> Lezzet</span>
                    <span id="sliderVal1" class="font-mono text-brand-gold font-bold">4.5</span>
                  </div>
                  <input id="reviewTasteScore" type="range" min="1" max="5" step="0.5" value="4.5" oninput="document.getElementById('sliderVal1').innerText = this.value" class="w-full accent-brand-orange h-1 bg-brand-border rounded cursor-pointer mt-1">
                </div>

                <div>
                  <div class="flex justify-between items-center text-slate-300">
                    <span class="font-bold flex items-center gap-1"><i class="fa-solid fa-gauge-high text-brand-green"></i> Doyuruculuk</span>
                    <span id="sliderVal2" class="font-mono text-brand-green font-bold">4.0</span>
                  </div>
                  <input id="reviewFullnessScore" type="range" min="1" max="5" step="0.5" value="4.0" oninput="document.getElementById('sliderVal2').innerText = this.value" class="w-full accent-brand-green h-1 bg-brand-border rounded cursor-pointer mt-1">
                </div>

                <div>
                  <div class="flex justify-between items-center text-slate-300">
                    <span class="font-bold flex items-center gap-1"><i class="fa-solid fa-coins text-brand-gold"></i> Fiyat / Performans</span>
                    <span id="sliderVal3" class="font-mono text-brand-gold font-bold">4.5</span>
                  </div>
                  <input id="reviewFpScore" type="range" min="1" max="5" step="0.5" value="4.5" oninput="document.getElementById('sliderVal3').innerText = this.value" class="w-full accent-brand-orange h-1 bg-brand-border rounded cursor-pointer mt-1">
                </div>
              </div>

              <!-- Yorum Metni -->
              <div>
                <div>
                <label for="reviewPricePaid" class="text-[9px] text-slate-400 font-bold block mb-1">Ödediğin fiyat (TL)</label>
                <input id="reviewPricePaid" type="number" min="0" max="100000" step="1" placeholder="Örn. 185"
                  class="w-full bg-brand-surface border border-brand-border rounded-lg text-white text-[10px] p-2 focus:outline-none placeholder:text-slate-500">
              </div>

              <textarea id="reviewCommentInput" placeholder="Yemek nasıldı? Porsiyon doyurdu mu? Fişi ekledin mi?.." rows="2" class="w-full bg-brand-surface border border-brand-border rounded-lg text-white text-[10px] p-2 focus:outline-none placeholder:text-slate-500"></textarea>
              </div>

              <!-- Dual Decision Button: "Bu Paraya Değer mi?" -->
              <div>
                <div class="text-[10px] font-bold text-white mb-1.5">Bu Paraya Değer mi?</div>
                <div class="grid grid-cols-2 gap-2 text-xs">
                  <button id="btnWorthYes" onclick="selectWorth(true)" class="py-2 rounded-xl bg-emerald-600 text-white font-extrabold flex items-center justify-center gap-1 shadow">
                    <i class="fa-solid fa-check"></i>
                    <span>EVET</span>
                  </button>
                  <button id="btnWorthNo" onclick="selectWorth(false)" class="py-2 rounded-xl bg-brand-card text-slate-300 border border-brand-border font-bold flex items-center justify-center gap-1">
                    <span>HAYIR</span>
                  </button>
                </div>
              </div>

              <!-- Submit CTA -->
              <button onclick="submitRealReview()" class="w-full py-2.5 bg-brand-orange hover:bg-brand-orangeDark text-white font-extrabold text-xs rounded-xl shadow-lg shadow-orange-500/20 flex items-center justify-center gap-1.5 transition active:scale-95">
                <i class="fa-solid fa-paper-plane text-[10px]"></i>
                <span>Yorumu Gönder (+Fotoğraf)</span>
              </button>
            </div>
          </div>
          <div class="mt-3 text-center">
            <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-brand-orange text-white text-xs font-bold mr-1">6</span>
            <span class="text-xs font-bold text-white">Fotoğraflı Yorum Ekle</span>
            <p class="text-[10px] text-slate-400 mt-0.5">Dükkanlar için fotoğraf ve fiş yükle.</p>
          </div>
        </div>

      </div>
    </div>

    <!-- VIEW 2: INTERACTIVE SINGLE PHONE SIMULATOR -->
    <div id="interactiveView" class="hidden">
      <div class="max-w-md mx-auto bg-brand-slate rounded-[44px] border-[6px] border-[#2d2d38] shadow-2xl overflow-hidden flex flex-col h-[740px] relative">
        <div class="px-6 pt-3 pb-2 flex justify-between items-center text-xs text-white font-semibold">
          <span>9:41</span>
          <div class="w-20 h-4 bg-black rounded-full mx-auto"></div>
          <div class="flex items-center gap-1.5 text-xs">
            <i class="fa-solid fa-battery-full"></i>
          </div>
        </div>
        <div id="phoneScreenContent" class="flex-1 overflow-y-auto custom-scrollbar flex flex-col">
          <!-- Dynamically filled by JS -->
        </div>
        <div class="px-4 py-2.5 bg-brand-surface border-t border-brand-border flex justify-around text-center">
          <div id="tab0" onclick="simulateGoToTab(0)" class="text-brand-orange cursor-pointer transition">
            <i class="fa-solid fa-house text-sm"></i>
            <div class="text-[9px] font-bold mt-0.5">Ana Sayfa</div>
          </div>
          <div id="tab1" onclick="simulateGoToTab(1)" class="text-slate-400 cursor-pointer transition hover:text-white">
            <i class="fa-solid fa-map text-sm"></i>
            <div class="text-[9px] mt-0.5">Harita</div>
          </div>
          <div id="tab6" onclick="simulateGoToTab(6)" class="text-slate-400 cursor-pointer transition hover:text-white relative">
            <i class="fa-solid fa-heart text-sm text-rose-500"></i>
            <span class="fav-count-badge absolute -top-1.5 -right-1.5 bg-rose-500 text-white text-[8px] font-black w-3.5 h-3.5 rounded-full flex items-center justify-center">2</span>
            <div class="text-[9px] mt-0.5 font-bold">Favoriler</div>
          </div>
          <div id="tab3" onclick="simulateGoToTab(3)" class="text-slate-400 cursor-pointer transition hover:text-white">
            <i class="fa-solid fa-magnifying-glass text-sm"></i>
            <div class="text-[9px] mt-0.5">Ara</div>
          </div>
          <div id="tab5" onclick="simulateGoToTab(5)" class="text-slate-400 cursor-pointer transition hover:text-white">
            <i class="fa-solid fa-camera text-sm"></i>
            <div class="text-[9px] mt-0.5">Yorumla</div>
          </div>
        </div>
      </div>
    </div>

  </main>

  <!-- FULLSCREEN PHOTO PREVIEW MODAL -->
  <div id="photoPreviewModal" class="fixed inset-0 bg-black/90 backdrop-blur-md z-50 hidden flex flex-col items-center justify-center p-4" onclick="closePhotoPreview()">
    <div class="max-w-xl w-full bg-brand-surface rounded-2xl overflow-hidden border border-brand-border shadow-2xl relative" onclick="event.stopPropagation()">
      <div class="p-3 bg-brand-card flex items-center justify-between border-b border-brand-border">
        <span class="text-xs font-bold text-white flex items-center gap-1.5" id="photoModalTitle">
          <i class="fa-solid fa-camera text-brand-orange"></i> Masadan Gerçek Fotoğraf
        </span>
        <button onclick="closePhotoPreview()" class="text-slate-400 hover:text-white text-sm"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div class="relative bg-black flex items-center justify-center max-h-[60vh] overflow-hidden">
        <img id="photoModalImg" src="" class="w-full h-auto max-h-[60vh] object-contain" alt="Yemek">
        <div class="absolute bottom-3 left-3 bg-black/70 px-2.5 py-1 rounded-lg border border-brand-border text-[10px] text-emerald-400 font-bold flex items-center gap-1">
          <i class="fa-solid fa-shield-halved"></i>
          <span>Kullanıcı Doğrulamalı Görsel</span>
        </div>
      </div>
      <div class="p-3 text-center">
        <p class="text-xs text-slate-300">Bu fotoğraf masada müşteri tarafından çekilmiş ve sisteme yüklenmiştir.</p>
      </div>
    </div>
  </div>

  <!-- PLAY SERVICES LOCATION PERMISSION MODAL -->
  <div id="locationModal" class="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="bg-brand-surface border border-brand-border rounded-3xl max-w-lg w-full p-6 shadow-2xl relative">
      <div class="flex items-center justify-between pb-4 border-b border-brand-border">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-lg">
            <i class="fa-solid fa-location-crosshairs"></i>
          </div>
          <div>
            <h3 class="text-base font-extrabold text-white">Play Services Konum İzni</h3>
            <p class="text-xs text-slate-400">FusedLocationProviderClient İzin Akışı</p>
          </div>
        </div>
        <button onclick="toggleLocationModal(false)" class="text-slate-400 hover:text-white"><i class="fa-solid fa-xmark"></i></button>
      </div>

      <div class="py-4 space-y-3">
        <div class="p-3.5 rounded-2xl bg-brand-card border border-brand-border space-y-2">
          <div class="flex items-center gap-2 text-xs font-bold text-white">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Neden Konum İzni İsteniyor?</span>
          </div>
          <p class="text-xs text-slate-300 leading-relaxed">
            Doydunmu, Google Play Services Location SDK'sı ile hassas GPS koordinatlarınızı alarak 200m - 500m yürüme mesafenizdeki gerçek F/P restoranlarını anlık olarak hesaplar ve listeler.
          </p>
        </div>

        <div class="p-3 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-400 space-y-1 font-mono">
          <div>• ACCESS_FINE_LOCATION (Hassas GPS)</div>
          <div>• ACCESS_COARSE_LOCATION (Ağ Bazlı Konum)</div>
          <div>• Priority.PRIORITY_HIGH_ACCURACY</div>
        </div>

        <div id="gpsStatusBox" class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-300 hidden">
          <div class="font-bold flex items-center gap-1.5">
            <i class="fa-solid fa-check-circle"></i>
            <span>Canlı GPS Konumu Tespit Edildi</span>
          </div>
          <div id="gpsCoordsText" class="text-[11px] text-emerald-400/80 mt-1">Enlem: 40.9880 | Boylam: 29.0250 (Kadıköy Moda)</div>
        </div>
      </div>

      <div class="flex flex-col sm:flex-row gap-2 pt-2">
        <button onclick="executeLocationPermission(true)" class="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2 transition">
          <i class="fa-solid fa-satellite-dish"></i>
          <span>GPS İzni Ver ve Konumu Al</span>
        </button>
        <button onclick="executeLocationPermission(false)" class="py-3 px-4 bg-brand-card hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl border border-brand-border transition">
          <span>Kadıköy Olarak Devam Et</span>
        </button>
      </div>
    </div>
  </div>

  <!-- AI ADVISOR MODAL (GEMINI POWERED) -->
  <div id="aiAdvisorModal" class="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="bg-brand-surface border border-indigo-500/30 rounded-3xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl shadow-indigo-500/10 overflow-hidden">
      <!-- Modal Header -->
      <div class="p-4 border-b border-brand-border flex items-center justify-between bg-gradient-to-r from-[#1e1b4b] via-brand-card to-brand-surface">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
            <i class="fa-solid fa-wand-magic-sparkles text-lg"></i>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h3 class="text-base font-extrabold text-white">Doydunmu AI Motoru</h3>
              <span class="text-[9px] bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 px-1.5 py-0.5 rounded font-black">GEMINI AI</span>
            </div>
            <p class="text-xs text-slate-400">Bütçene göre en doyurucu menüyü bulur, adisyon tuzaklarını deşifre eder.</p>
          </div>
        </div>
        <button onclick="toggleAiAdvisorModal(false)" class="w-8 h-8 rounded-full bg-brand-surface flex items-center justify-center text-slate-400 hover:text-white">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <!-- Tabs -->
      <div class="flex border-b border-brand-border bg-[#15151c] px-4 pt-2 gap-2 text-xs font-bold">
        <button onclick="switchAiTab('recommend')" id="aiTabBtn_recommend" class="px-4 py-2.5 border-b-2 border-indigo-500 text-indigo-400 flex items-center gap-2">
          <i class="fa-solid fa-utensils"></i>
          <span>Bugün Ne Yesem?</span>
        </button>
        <button onclick="switchAiTab('audit')" id="aiTabBtn_audit" class="px-4 py-2.5 border-b-2 border-transparent text-slate-400 hover:text-white flex items-center gap-2">
          <i class="fa-solid fa-receipt"></i>
          <span>Fiş & Adisyon Denetçisi</span>
        </button>
        <button onclick="switchAiTab('compare')" id="aiTabBtn_compare" class="px-4 py-2.5 border-b-2 border-transparent text-slate-400 hover:text-white flex items-center gap-2">
          <i class="fa-solid fa-scale-balanced"></i>
          <span>F/P Karşılaştırıcı</span>
        </button>
      </div>

      <!-- Tab Content Area -->
      <div class="p-5 overflow-y-auto space-y-4 flex-1 custom-scrollbar">

        <!-- TAB 1: RECOMMEND -->
        <div id="aiTab_recommend" class="space-y-4">
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div class="p-3 bg-brand-card rounded-xl border border-brand-border">
              <label class="text-[11px] font-bold text-slate-300 block mb-1">Cebindeki Bütçe (TL)</label>
              <div class="flex items-center justify-between text-base font-black text-white">
                <span id="aiBudgetDisplay">200 TL</span>
                <span class="text-[10px] text-emerald-400 font-bold">Kadıköy Bölgesi</span>
              </div>
              <input type="range" id="aiBudgetInput" min="80" max="450" value="200" oninput="document.getElementById('aiBudgetDisplay').innerText = this.value + ' TL'" class="w-full accent-indigo-500 mt-2 h-1 bg-brand-border rounded cursor-pointer">
            </div>

            <div class="p-3 bg-brand-card rounded-xl border border-brand-border">
              <label class="text-[11px] font-bold text-slate-300 block mb-1">Açlık Seviyen</label>
              <div class="grid grid-cols-3 gap-1.5 mt-1">
                <button onclick="setAiHunger('Çok Açım', this)" class="ai-hunger-btn py-1.5 text-[11px] font-bold rounded-lg bg-indigo-600 text-white">Çok Açım 🦁</button>
                <button onclick="setAiHunger('Normal', this)" class="ai-hunger-btn py-1.5 text-[11px] font-bold rounded-lg bg-brand-surface text-slate-300 hover:bg-slate-700">Normal 🍽️</button>
                <button onclick="setAiHunger('Hafif', this)" class="ai-hunger-btn py-1.5 text-[11px] font-bold rounded-lg bg-brand-surface text-slate-300 hover:bg-slate-700">Hafif 🥪</button>
              </div>
            </div>
          </div>

          <div class="p-3 bg-brand-card rounded-xl border border-brand-border">
            <label class="text-[11px] font-bold text-slate-300 block mb-1.5">Canın Ne Çekiyor?</label>
            <div class="flex flex-wrap gap-2 text-xs font-semibold">
              <button onclick="setAiCraving('Fark Etmez', this)" class="ai-craving-btn px-3 py-1.5 rounded-lg bg-indigo-600 text-white">Fark Etmez (En İyisi)</button>
              <button onclick="setAiCraving('Dürüm & Döner', this)" class="ai-craving-btn px-3 py-1.5 rounded-lg bg-brand-surface text-slate-300 hover:bg-slate-700">Dürüm & Döner</button>
              <button onclick="setAiCraving('Burger', this)" class="ai-craving-btn px-3 py-1.5 rounded-lg bg-brand-surface text-slate-300 hover:bg-slate-700">Burger</button>
              <button onclick="setAiCraving('Lahmacun & Pide', this)" class="ai-craving-btn px-3 py-1.5 rounded-lg bg-brand-surface text-slate-300 hover:bg-slate-700">Lahmacun & Pide</button>
              <button onclick="setAiCraving('Köfte & Izgara', this)" class="ai-craving-btn px-3 py-1.5 rounded-lg bg-brand-surface text-slate-300 hover:bg-slate-700">Köfte & Izgara</button>
            </div>
          </div>

          <button onclick="runAiRecommendation()" id="aiRunBtn" class="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black text-xs rounded-xl shadow-lg shadow-indigo-500/30 flex items-center justify-center gap-2 transition">
            <i class="fa-solid fa-wand-magic-sparkles"></i>
            <span>Yapay Zeka Analizini Başlat</span>
          </button>

          <!-- Recommendation Result Card -->
          <div id="aiRecommendResult" class="p-4 rounded-2xl bg-gradient-to-br from-[#1e1b4b]/60 to-brand-card border border-indigo-500/40 space-y-3">
            <div class="flex items-center justify-between">
              <span class="text-xs font-black text-emerald-400 flex items-center gap-1.5">
                <i class="fa-solid fa-award"></i>
                <span id="aiResBadge">AI ŞAMPİYON TAVSİYESİ</span>
              </span>
              <span id="aiResFpScore" class="text-[10px] font-black bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-400/30">%96 F/P Skoru</span>
            </div>

            <div>
              <h4 id="aiResTitle" class="text-base font-extrabold text-white">70cm Tavuk Zurna Dürüm Menü (180 TL)</h4>
              <p id="aiResSubtitle" class="text-xs text-slate-300 mt-1 leading-relaxed">Hatay Dürüm Dünyası · Kadıköy Moda (120m - 2 dk yürüme)</p>
            </div>

            <div class="p-3 rounded-xl bg-brand-surface/80 border border-brand-border text-xs text-slate-300 leading-relaxed" id="aiResRationale">
              Gemini F/P motoru bütçenizi ve Kadıköy'deki mekanları analiz etti: 180 TL fiyatıyla 220gr porsiyon sunuyor. Bölgedeki turist tuzaklarına kıyasla 1 Lira başına %60 daha fazla protein ve tokluk sağlıyor.
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div class="p-2.5 rounded-lg bg-amber-950/30 border border-amber-600/30 text-amber-300">
                <div class="font-bold flex items-center gap-1 text-[11px] mb-0.5"><i class="fa-solid fa-lightbulb"></i> Doyuruculuk Tüyosu:</div>
                <div id="aiResTip" class="text-[11px] text-amber-200/90">Sosu bol isteyin, yanına pahalı kutu içecek yerine su veya açık ayran tercih edin.</div>
              </div>
              <div class="p-2.5 rounded-lg bg-red-950/30 border border-red-600/30 text-red-300">
                <div class="font-bold flex items-center gap-1 text-[11px] mb-0.5"><i class="fa-solid fa-triangle-exclamation"></i> Tuzak Uyarısı:</div>
                <div id="aiResTrap" class="text-[11px] text-red-200/90">Boğa Meydanı'ndaki 420 TL'lik döner tuzağından kaçının; porsiyonu sadece 110 gramdır.</div>
              </div>
            </div>
          </div>
        </div>

        <!-- TAB 2: RECEIPT AUDIT -->
        <div id="aiTab_audit" class="space-y-4 hidden">
          <div class="p-3 bg-brand-card rounded-xl border border-brand-border space-y-2">
            <span class="text-xs font-bold text-white block">Hızlı Örnek Adisyonlar</span>
            <div class="flex flex-wrap gap-2 text-xs">
              <button onclick="fillAuditSample('Boğa Meydanı Gurme Döner', 'Et Döner Porsiyon', 420)" class="px-2.5 py-1.5 rounded-lg bg-red-950/60 border border-red-500/40 text-red-300 font-bold hover:bg-red-900/50">
                ⚠️ Boğa Meydanı Döner (420 TL - Tuzak)
              </button>
              <button onclick="fillAuditSample('Hatay Dürüm Dünyası', '70cm Zurna Menü', 180)" class="px-2.5 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 font-bold hover:bg-emerald-900/50">
                ✅ Hatay Zurna Dürüm (180 TL - F/P)
              </button>
            </div>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="text-[11px] font-bold text-slate-300 block mb-1">Mekan Adı</label>
              <input type="text" id="auditRestaurantInput" value="Boğa Meydanı Gurme Döner" class="w-full px-3 py-2 rounded-xl bg-brand-card border border-brand-border text-xs text-white focus:border-indigo-500 focus:outline-none">
            </div>
            <div>
              <label class="text-[11px] font-bold text-slate-300 block mb-1">Yenen Yemek / Ürün</label>
              <input type="text" id="auditDishInput" value="Et Döner Porsiyon (110gr)" class="w-full px-3 py-2 rounded-xl bg-brand-card border border-brand-border text-xs text-white focus:border-indigo-500 focus:outline-none">
            </div>
          </div>

          <div>
            <label class="text-[11px] font-bold text-slate-300 block mb-1">Toplam Ödenen Tutar (TL)</label>
            <input type="number" id="auditPriceInput" value="420" class="w-full px-3 py-2 rounded-xl bg-brand-card border border-brand-border text-xs text-white focus:border-indigo-500 focus:outline-none font-bold">
          </div>

          <button onclick="runAiAudit()" id="aiAuditBtn" class="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black text-xs rounded-xl shadow-lg shadow-indigo-500/30 flex items-center justify-center gap-2 transition">
            <i class="fa-solid fa-shield-halved"></i>
            <span>Adisyonu AI ile Denetle</span>
          </button>

          <!-- Audit Result Card -->
          <div id="aiAuditResult" class="p-4 rounded-2xl bg-brand-card border border-red-500/40 space-y-3">
            <div class="flex items-center justify-between">
              <span id="auditVerdict" class="text-xs font-black text-red-400">⚠️ KAZIK / TUZAK ADİSYON TESPİT EDİLDİ</span>
              <span id="auditFpScore" class="text-[10px] font-black bg-red-500/20 text-red-300 px-2 py-0.5 rounded border border-red-400/30">%22 F/P Skoru</span>
            </div>
            <div class="text-xs text-slate-300" id="auditFairPrice">
              Tahmini Adil Piyasa Değeri: <strong class="text-white">190 TL</strong> (Ödenen: 420 TL · Fark: +230 TL)
            </div>
            <div id="auditAlerts" class="space-y-1.5 text-xs text-red-300/90 bg-red-950/30 p-3 rounded-xl border border-red-800/40">
              <div>• Porsiyon gramajına oranla %70 fahiş fiyat tespit edildi.</div>
              <div>• Masa kuver ve izinsiz su servisi riski var.</div>
              <div>• Kadıköy ortalamasının iki katı üzerinde ücretlendirme.</div>
            </div>
            <div class="text-[11px] text-slate-400" id="auditAdvice">
              Tavsiye: Bu fişi sisteme şikayet olarak yükleyip diğer kullanıcıları uyarabilirsin.
            </div>
          </div>
        </div>

        <!-- TAB 3: COMPARE -->
        <div id="aiTab_compare" class="space-y-4 hidden">
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div class="p-3 bg-brand-card rounded-xl border border-brand-border">
              <label class="text-[11px] font-bold text-brand-orange block mb-1">1. Yemek Seçeneği</label>
              <select id="compareA" class="w-full px-2.5 py-1.5 rounded-lg bg-brand-surface text-xs text-white border border-brand-border">
                <option value="1">70cm Zurna Dürüm (180 TL)</option>
                <option value="2">2x Çıtır Lahmacun (160 TL)</option>
                <option value="3">Double Smash Burger (195 TL)</option>
              </select>
            </div>
            <div class="p-3 bg-brand-card rounded-xl border border-brand-border">
              <label class="text-[11px] font-bold text-amber-400 block mb-1">2. Yemek Seçeneği</label>
              <select id="compareB" class="w-full px-2.5 py-1.5 rounded-lg bg-brand-surface text-xs text-white border border-brand-border">
                <option value="5">Boğa Meydanı Döner (420 TL - Tuzak)</option>
                <option value="4">Tekirdağ Köfte Menü (220 TL)</option>
                <option value="6">Moda Artisan Poşe Yumurta (320 TL)</option>
              </select>
            </div>
          </div>

          <button onclick="runAiCompare()" class="w-full py-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-black text-xs rounded-xl shadow-lg flex items-center justify-center gap-2 transition">
            <i class="fa-solid fa-scale-balanced"></i>
            <span>F/P Kıyaslama Raporunu Oluştur</span>
          </button>

          <div id="aiCompareResult" class="p-4 rounded-2xl bg-brand-card border border-amber-500/40 font-mono text-xs text-slate-200 leading-relaxed whitespace-pre-line">
🥊 F/P KARŞILAŞTIRMA RAPORU:
1 Lira Başına Doyuruculuk:
• 70cm Zurna Dürüm (180 TL): 54 Puan (Tokluk: %98)
• Boğa Meydanı Döner (420 TL): 8 Puan (Tokluk: %35)

🏆 KAZANAN: 70cm Zurna Dürüm (Hatay Dürüm Dünyası)
Bu seçim paranızın karşılığını %575 daha fazla verir ve aç kalkmanızı önler!
          </div>
        </div>

      </div>
  </div>

  <!-- FAVORİLERİM (ROOM DATABASE) MODAL -->
  <div id="favoritesModal" class="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="bg-brand-surface border border-brand-border rounded-3xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
      <div class="p-4 border-b border-brand-border flex items-center justify-between bg-brand-card">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center text-lg font-bold border border-rose-500/30">
            <i class="fa-solid fa-heart"></i>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h3 class="text-base font-extrabold text-white">Favorilerim</h3>
              <span class="text-[10px] font-black bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-400/30">
                <i class="fa-solid fa-database mr-1"></i>Room SQLite
              </span>
            </div>
            <p class="text-xs text-slate-400">Beğendiğin F/P mekanları Android Room yerel veritabanında çevrimdışı saklanır.</p>
          </div>
        </div>
        <button onclick="toggleFavoritesModal(false)" class="w-8 h-8 rounded-full bg-brand-surface flex items-center justify-center text-slate-400 hover:text-white">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <div class="p-4 overflow-y-auto flex-1 custom-scrollbar space-y-4" id="favoritesModalBody">
        <!-- Dynamically rendered by JS -->
      </div>
    </div>
  </div>

  <!-- FLUTTER CODE ASSISTANT MODAL (FOR ANDROID STUDIO) -->
  <div id="flutterModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="bg-brand-surface border border-brand-border rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
      <div class="p-4 border-b border-brand-border flex items-center justify-between bg-brand-card">
        <div class="flex items-center gap-2">
          <div class="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-sm font-bold">
            <i class="fa-solid fa-laptop-code"></i>
          </div>
          <div>
            <h3 class="text-base font-extrabold text-white">Android Studio & Flutter Kod Deposu</h3>
            <p class="text-xs text-slate-400">Fotoğraflı yorum özellikli tam dosyalar.</p>
          </div>
        </div>
        <button onclick="toggleFlutterModal(false)" class="w-8 h-8 rounded-full bg-brand-surface flex items-center justify-center text-slate-400 hover:text-white">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <div class="flex gap-2 p-3 border-b border-brand-border bg-[#181820] overflow-x-auto text-xs font-bold custom-scrollbar">
        <button onclick="showCodeSnippet('pubspec')" id="btn_pubspec" class="code-tab-btn px-3 py-1.5 rounded-lg bg-brand-orange text-white shrink-0">pubspec.yaml</button>
        <button onclick="showCodeSnippet('main')" id="btn_main" class="code-tab-btn px-3 py-1.5 rounded-lg bg-brand-card text-slate-300 hover:text-white shrink-0">lib/main.dart</button>
        <button onclick="showCodeSnippet('model')" id="btn_model" class="code-tab-btn px-3 py-1.5 rounded-lg bg-brand-card text-slate-300 hover:text-white shrink-0">lib/models/food_item.dart</button>
        <button onclick="showCodeSnippet('review')" id="btn_review" class="code-tab-btn px-3 py-1.5 rounded-lg bg-brand-card text-slate-300 hover:text-white shrink-0">lib/screens/add_review_screen.dart</button>
        <button onclick="showCodeSnippet('detail')" id="btn_detail" class="code-tab-btn px-3 py-1.5 rounded-lg bg-brand-card text-slate-300 hover:text-white shrink-0">lib/screens/dish_detail_screen.dart</button>
      </div>

      <div class="p-4 flex-1 overflow-hidden flex flex-col bg-[#111116]">
        <div class="flex justify-between items-center mb-2">
          <span id="currentCodePath" class="text-xs font-mono text-brand-orange font-bold">lib/screens/add_review_screen.dart</span>
          <button onclick="copyCurrentCode()" class="px-3 py-1.5 bg-brand-orange hover:bg-brand-orangeDark text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow">
            <i class="fa-regular fa-copy"></i>
            <span id="copyBtnText">Kodu Kopyala</span>
          </button>
        </div>
        <pre class="flex-1 overflow-auto bg-black/60 p-4 rounded-xl border border-brand-border text-xs text-slate-200 font-mono leading-relaxed custom-scrollbar"><code id="codeViewerBox"></code></pre>
      </div>
    </div>
  </div>

  <!-- FOOTER -->
  <footer class="border-t border-brand-border py-4 px-6 text-center text-xs text-slate-500 bg-[#141418]">
    <span>© 2026 Doydunmu · Tüm Hakları Saklıdır · Fotoğraf ve Fiş Doğrulamalı F/P Sistemi</span>
  </footer>

  <!-- TOAST NOTIFICATION CONTAINER -->
  <div id="toastContainer" class="fixed top-5 right-5 z-50 flex flex-col gap-2 pointer-events-none max-w-sm w-full"></div>

  <!-- JAVASCRIPT APP LOGIC -->
  <script>
    function showAppToast(title, message, icon = 'fa-circle-check', type = 'emerald') {
      const container = document.getElementById('toastContainer');
      if (!container) return;
      const toast = document.createElement('div');
      const colorClasses = type === 'emerald'
        ? 'border-emerald-500/40 bg-emerald-950/95 text-emerald-200'
        : (type === 'orange' ? 'border-brand-orange/40 bg-[#251811]/95 text-orange-200' : 'border-indigo-500/40 bg-indigo-950/95 text-indigo-200');
      toast.className = 'p-3.5 rounded-2xl shadow-2xl border backdrop-blur-md flex items-start gap-3 pointer-events-auto transition-all duration-300 transform translate-y-2 opacity-0 ' + colorClasses;
      toast.innerHTML = \`
        <i class="fa-solid \${icon} text-base mt-0.5 shrink-0"></i>
        <div class="flex-1 text-xs">
          <div class="font-extrabold text-white text-[13px]">\${title}</div>
          <div class="mt-0.5 leading-snug">\${message}</div>
        </div>
        <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-white text-xs ml-1"><i class="fa-solid fa-xmark"></i></button>
      \`;
      container.appendChild(toast);
      requestAnimationFrame(() => {
        toast.classList.remove('translate-y-2', 'opacity-0');
      });
      setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => toast.remove(), 400);
      }, 4500);
    }

    let currentActiveTab = 0;
    let selectedWorthValue = true;
    let currentUploadedPhotoData = "${zurnaImg}";

    // Room Database favorites simulation (persistent via localStorage)
    let favoriteFoodsList = [];
    try {
      const stored = localStorage.getItem('yy_room_favorites');
      if (stored) {
        favoriteFoodsList = JSON.parse(stored);
      } else {
        favoriteFoodsList = [
          {
            id: "1",
            name: "70cm Tavuk Zurna Dürüm",
            shop: "Hatay Dürüm Dünyası",
            price: 180,
            fpScore: 96,
            satietyScore: 98,
            img: "${zurnaImg}",
            distance: 240,
            timeAgo: "Bugün kaydedildi"
          },
          {
            id: "2",
            name: "2x Çıtır Antep Lahmacun",
            shop: "Moda Taş Fırın",
            price: 160,
            fpScore: 94,
            satietyScore: 90,
            img: "${lahmacunImg}",
            distance: 420,
            timeAgo: "Dün kaydedildi"
          }
        ];
        localStorage.setItem('yy_room_favorites', JSON.stringify(favoriteFoodsList));
      }
    } catch(e) {
      favoriteFoodsList = [];
    }

    function updateFavoriteBadges() {
      const count = favoriteFoodsList.length;
      document.querySelectorAll('.fav-count-badge').forEach(el => {
        el.innerText = count;
        el.style.display = count > 0 ? 'inline-flex' : 'none';
      });
    }

    function toggleFavoritesModal(isOpen) {
      const modal = document.getElementById('favoritesModal');
      if (!modal) return;
      if (isOpen) {
        renderFavoritesModal();
        modal.classList.remove('hidden');
      } else {
        modal.classList.add('hidden');
      }
    }

    function openFavoritesModal() {
      toggleFavoritesModal(true);
    }

    function toggleFavoriteFood(item) {
      const idx = favoriteFoodsList.findIndex(f => f.id === item.id);
      if (idx >= 0) {
        favoriteFoodsList.splice(idx, 1);
        localStorage.setItem('yy_room_favorites', JSON.stringify(favoriteFoodsList));
        updateFavoriteBadges();
        showAppToast("🤍 Favorilerden Çıkarıldı", item.name + " Room SQLite yerel veritabanından silindi.", "fa-heart-crack", "slate");
      } else {
        favoriteFoodsList.unshift({
          id: item.id,
          name: item.name,
          shop: item.shop || "Kadıköy F/P Mekanı",
          price: item.price || 180,
          fpScore: item.fpScore || 92,
          satietyScore: item.satietyScore || 90,
          img: item.img || "${zurnaImg}",
          distance: item.distance || 300,
          timeAgo: "Az önce"
        });
        localStorage.setItem('yy_room_favorites', JSON.stringify(favoriteFoodsList));
        updateFavoriteBadges();
        showAppToast("❤️ Room Veritabanına Kaydedildi!", item.name + " favorilere eklendi. Çevrimdışı SQLite hafızasında saklanıyor.", "fa-heart", "orange");
      }
      renderFavoritesModal();
      if (currentActiveTab === 6) {
        renderPhoneScreen(6);
      }
    }

    function clearAllFavorites() {
      favoriteFoodsList = [];
      localStorage.setItem('yy_room_favorites', JSON.stringify(favoriteFoodsList));
      updateFavoriteBadges();
      renderFavoritesModal();
      showAppToast("🗑️ Favoriler Temizlendi", "Room yerel veritabanındaki tüm mekanlar silindi.", "fa-trash-can", "slate");
      if (currentActiveTab === 6) {
        renderPhoneScreen(6);
      }
    }

    function renderFavoritesModal() {
      const body = document.getElementById('favoritesModalBody');
      if (!body) return;
      const count = favoriteFoodsList.length;
      const avgFp = count ? Math.round(favoriteFoodsList.reduce((acc, f) => acc + (f.fpScore || 90), 0) / count) : 0;
      const avgPrice = count ? Math.round(favoriteFoodsList.reduce((acc, f) => acc + (f.price || 180), 0) / count) : 0;

      if (count === 0) {
        body.innerHTML = \`
          <div class="text-center py-12 px-6 bg-brand-card rounded-3xl border border-brand-border space-y-4">
            <div class="w-16 h-16 rounded-3xl bg-rose-500/10 text-rose-400 flex items-center justify-center text-3xl mx-auto border border-rose-500/20">
              <i class="fa-regular fa-heart"></i>
            </div>
            <div>
              <h4 class="text-base font-extrabold text-white">Henüz Kayıtlı Favorin Yok</h4>
              <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto leading-relaxed">
                Beğendiğin ve bütçeni koruyan yemeklerdeki kalp simgesine tıklayarak Room SQLite yerel veritabanına ekleyebilirsin.
              </p>
            </div>
            <button onclick="toggleFavoritesModal(false); switchMainView('gallery');" class="px-5 py-2.5 bg-brand-orange hover:bg-brand-orangeDark text-white font-extrabold text-xs rounded-xl shadow-lg transition">
              <i class="fa-solid fa-magnifying-glass mr-1.5"></i> F/P Mekanlarını İncele
            </button>
          </div>
        \`;
        return;
      }

      body.innerHTML = \`
        <div class="p-4 rounded-2xl bg-brand-card border border-brand-border grid grid-cols-3 text-center">
          <div>
            <div class="text-[10px] text-slate-400 font-bold uppercase">Kayıtlı Mekan</div>
            <div class="text-lg font-black text-white mt-0.5">\${count} Adet</div>
          </div>
          <div class="border-x border-brand-border">
            <div class="text-[10px] text-slate-400 font-bold uppercase">Ort. F/P Skoru</div>
            <div class="text-lg font-black text-emerald-400 mt-0.5">%\${avgFp}</div>
          </div>
          <div>
            <div class="text-[10px] text-slate-400 font-bold uppercase">Ort. Fiyat</div>
            <div class="text-lg font-black text-brand-orange mt-0.5">\${avgPrice} TL</div>
          </div>
        </div>

        <div class="flex items-center justify-between pt-1">
          <span class="text-xs font-bold text-slate-300">Room SQLite Kayıtları</span>
          <button onclick="clearAllFavorites()" class="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 font-bold">
            <i class="fa-solid fa-trash-can text-[11px]"></i> Tümünü Temizle
          </button>
        </div>

        <div class="space-y-3">
          \${favoriteFoodsList.map(item => \`
            <div class="p-3.5 rounded-2xl bg-brand-card border border-brand-border flex gap-3.5 items-center hover:border-brand-orange/40 transition">
              <img src="\${item.img}" class="w-16 h-16 rounded-xl object-cover border border-brand-border shrink-0" alt="\${item.name}">
              <div class="flex-1 min-w-0">
                <div class="flex items-start justify-between">
                  <div>
                    <h4 class="text-sm font-bold text-white truncate">\${item.name}</h4>
                    <div class="text-[11px] text-slate-400">\${item.shop} · \${item.distance || 300}m</div>
                  </div>
                  <button onclick="toggleFavoriteFood({ id: '\${item.id}', name: '\${item.name.replace(/'/g, \"\\\\'\")}' })" class="text-rose-500 hover:text-rose-400 text-base p-1" title="Favorilerden Kaldır">
                    <i class="fa-solid fa-heart"></i>
                  </button>
                </div>
                <div class="flex items-center justify-between mt-2">
                  <div class="flex items-center gap-2">
                    <span class="text-[10px] font-black bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-400/30">%\${item.fpScore || 92} F/P</span>
                    <span class="text-[10px] text-slate-400">\${item.timeAgo}</span>
                  </div>
                  <span class="text-sm font-black text-white">\${item.price} TL</span>
                </div>
              </div>
            </div>
          \`).join('')}
        </div>
      \`;
    }

    // Dynamic photo reviews store
    let userReviewsList = [
      {
        userName: "Lezzet Avcısı",
        badge: "F/P Canavarı",
        comment: "Fiyatına göre gerçekten efsane. Eti çok lezzetli, porsiyon da doyurucu. Kesinlikle tavsiye ederim!",
        timeAgo: "2 gün önce",
        photoUrl: "${zurnaImg}",
        hasReceipt: true
      },
      {
        userName: "Merve T.",
        badge: "Öğrenci Dostu",
        comment: "Hem uygun fiyatlı hem de çok lezzetli. Kadıköy'de öğrenciler için kurtarıcı.",
        timeAgo: "3 gün önce",
        photoUrl: "${kofteImg}",
        hasReceipt: false
      }
    ];

    // Doydunmu: keep community reviews after refresh in this browser.
    // This is browser-local storage, not yet shared between different users/devices.
    try {
      const savedReviews = JSON.parse(localStorage.getItem('doydunmu_user_reviews') || '[]');
      if (Array.isArray(savedReviews)) {
        userReviewsList = [...savedReviews, ...userReviewsList];
      }
    } catch (e) {
      console.warn('Doydunmu kayıtlı yorumları okunamadı.', e);
    }

    function persistUserReviews() {
      try {
        localStorage.setItem('doydunmu_user_reviews', JSON.stringify(userReviewsList.slice(0, 30)));
      } catch (e) {
        // If photos exceed browser storage quota, retry without large embedded images.
        try {
          const compact = userReviewsList.slice(0, 30).map(review => ({
            ...review,
            photoUrl: (review.photoUrl && review.photoUrl.length < 180000) ? review.photoUrl : ''
          }));
          localStorage.setItem('doydunmu_user_reviews', JSON.stringify(compact));
          userReviewsList = compact;
          showAppToast('Yorum kaydedildi', 'Fotoğraf dosyası tarayıcı depolama sınırını aştığı için yorum fotoğrafsız saklandı.', 'fa-circle-info', 'slate');
        } catch (retryError) {
          showAppToast('Kayıt alanı dolu', 'Tarayıcı depolama alanı dolu. Eski site verilerini temizleyip tekrar deneyin.', 'fa-triangle-exclamation', 'red');
        }
      }
    }

    function handlePhotoUpload(event) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
          const img = new Image();
          img.onload = function() {
            const maxSide = 1000;
            const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
            const canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(img.width * scale));
            canvas.height = Math.max(1, Math.round(img.height * scale));
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            currentUploadedPhotoData = canvas.toDataURL('image/jpeg', 0.76);
            const preview = document.getElementById('previewUploadedImg');
            if (preview) preview.src = currentUploadedPhotoData;
            const label = document.getElementById('photoUploadLabel');
            if (label) label.innerText = "✓ Fotoğraf Eklendi";
          };
          img.onerror = function() {
            showAppToast('Fotoğraf açılamadı', 'Lütfen JPG veya PNG formatında başka bir fotoğraf seç.', 'fa-triangle-exclamation', 'red');
          };
          img.src = e.target.result;
        };
        reader.readAsDataURL(file);
      }
    }

    function openPhotoPreview(src, title) {
      document.getElementById('photoModalImg').src = src;
      document.getElementById('photoModalTitle').innerHTML = '<i class="fa-solid fa-camera text-brand-orange"></i> ' + title;
      document.getElementById('photoPreviewModal').classList.remove('hidden');
    }

    function closePhotoPreview() {
      document.getElementById('photoPreviewModal').classList.add('hidden');
    }

    function openAddReviewDirect() {
      simulateGoToTab(5);
    }

    function submitRealReview() {
      const commentInput = document.getElementById('reviewCommentInput');
      const comment = commentInput.value.trim();
      const shop = document.getElementById('reviewShopSelect').value;
      const priceValue = Number(document.getElementById('reviewPricePaid')?.value || 0);
      const tasteScore = Number(document.getElementById('reviewTasteScore')?.value || 4.5);
      const fullnessScore = Number(document.getElementById('reviewFullnessScore')?.value || 4.0);
      const fpScore = Number(document.getElementById('reviewFpScore')?.value || 4.5);

      if (priceValue < 0 || !Number.isFinite(priceValue)) {
        showAppToast('Fiyatı kontrol et', 'Geçerli bir fiyat gir veya fiyat alanını boş bırak.', 'fa-triangle-exclamation', 'red');
        return;
      }

      const newReview = {
        id: 'review_' + Date.now(),
        userName: "Doydunmu kullanıcısı",
        badge: "Topluluk Yorumu",
        restaurantName: shop,
        pricePaid: priceValue || null,
        tasteScore,
        fullnessScore,
        fpScore,
        isWorthIt: selectedWorthValue,
        comment: comment || "Yemek ve porsiyon değerlendirmesi eklendi.",
        timeAgo: "Az önce",
        photoUrl: currentUploadedPhotoData || "",
        hasReceipt: false
      };

      userReviewsList.unshift(newReview);
      persistUserReviews();

      const gallery = document.getElementById('photoGalleryThumbnails');
      if (gallery && newReview.photoUrl) {
        const newImg = document.createElement('img');
        newImg.src = newReview.photoUrl;
        newImg.alt = 'Doydunmu kullanıcı yemek fotoğrafı';
        newImg.className = "h-12 w-full object-cover rounded-lg border-2 border-brand-orange cursor-pointer hover:opacity-80 transition";
        newImg.onclick = () => openPhotoPreview(newReview.photoUrl, "Kullanıcı Fotoğrafı");
        gallery.prepend(newImg);
      }

      const revContainer = document.getElementById('reviewsContainer');
      if (revContainer) {
        const revCard = document.createElement('div');
        revCard.className = "p-3 rounded-xl bg-brand-card border border-brand-orange/60 space-y-2 text-[10px]";
        const safeText = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
        revCard.innerHTML = \`
          <div class="flex items-center justify-between gap-2">
            <div class="flex items-center gap-1.5">
              <div class="w-6 h-6 rounded-full bg-brand-orange text-white text-[9px] flex items-center justify-center font-bold">DY</div>
              <span class="font-bold text-white">\${safeText(newReview.userName)}</span>
            </div>
            <span class="text-[8px] bg-emerald-500/20 text-emerald-400 px-1.5 py-1 rounded font-bold">Yeni yorum</span>
          </div>
          <div class="text-brand-gold font-bold">Lezzet \${tasteScore}/5 · Doyuruculuk \${fullnessScore}/5 · F/P \${fpScore}/5</div>
          \${priceValue ? \`<div class="text-slate-300">Ödenen fiyat: <b>\${priceValue} TL</b></div>\` : ''}
          <p class="text-slate-300 text-[10px] leading-relaxed">\${safeText(newReview.comment)}</p>
          \${newReview.photoUrl ? \`<img src="\${newReview.photoUrl}" alt="Yüklenen yemek fotoğrafı" class="w-20 h-20 object-cover rounded-lg border border-brand-border cursor-pointer">\` : ''}
          <div class="\${newReview.isWorthIt ? 'text-emerald-400' : 'text-red-400'} font-bold">\${newReview.isWorthIt ? '✓ Bu paraya değer' : '✕ Bu paraya değmez'}</div>
        \`;
        const reviewImage = revCard.querySelector('img');
        if (reviewImage) reviewImage.onclick = () => openPhotoPreview(newReview.photoUrl, 'Kullanıcı Fotoğrafı');
        revContainer.prepend(revCard);
      }

      showAppToast('Yorum kaydedildi', 'Değerlendirmen bu tarayıcıda saklandı. Farklı cihazlarla paylaşım için sunucu/veritabanı bağlantısı gerekir.', 'fa-circle-check', 'orange');
      if (commentInput) commentInput.value = '';
      const priceInput = document.getElementById('reviewPricePaid');
      if (priceInput) priceInput.value = '';
      simulateGoToTab(4);
    }

        function switchMainView(view) {
      const gallery = document.getElementById('galleryView');
      const interactive = document.getElementById('interactiveView');
      const galBtn = document.getElementById('viewGalleryBtn');
      const intBtn = document.getElementById('viewInteractiveBtn');

      if (view === 'gallery') {
        gallery.classList.remove('hidden');
        interactive.classList.add('hidden');
        galBtn.className = 'px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-brand-orange text-white shadow';
        intBtn.className = 'px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-brand-surface hover:bg-brand-card text-slate-300 border border-brand-border';
      } else {
        gallery.classList.add('hidden');
        interactive.classList.remove('hidden');
        intBtn.className = 'px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-brand-orange text-white shadow';
        galBtn.className = 'px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-brand-surface hover:bg-brand-card text-slate-300 border border-brand-border';
        renderPhoneScreen(currentActiveTab);
      }
    }

    function simulateGoToTab(tabIndex) {
      switchMainView('interactive');
      currentActiveTab = tabIndex;
      renderPhoneScreen(tabIndex);

      [0, 1, 3, 5, 6].forEach(i => {
        const el = document.getElementById('tab' + i);
        if (el) {
          if (i === tabIndex) {
            el.className = (i === 6 ? 'text-rose-500 font-bold' : 'text-brand-orange font-bold') + ' cursor-pointer transition relative';
          } else {
            el.className = 'text-slate-400 cursor-pointer transition hover:text-white relative';
          }
        }
      });
    }

    function renderPhoneScreen(screenIndex) {
      const container = document.getElementById('phoneScreenContent');
      if (!container) return;

      if (screenIndex === 0) {
        container.innerHTML = \`
          <div class="px-4 py-2.5 flex items-center justify-between border-b border-brand-border bg-brand-surface">
            <div class="flex items-center gap-2">
              <div class="w-7 h-7 rounded-lg bg-brand-orange flex items-center justify-center text-white text-xs">
                <i class="fa-solid fa-utensils"></i>
              </div>
              <span class="text-sm font-extrabold text-white">Doydunmu <span class="text-brand-orange">Ye</span></span>
            </div>
            <i class="fa-solid fa-bars text-slate-400 text-sm"></i>
          </div>
          <div class="p-4 space-y-4 flex-1">
            <div class="p-3.5 rounded-2xl bg-gradient-to-br from-brand-card to-brand-surface border border-brand-border flex items-center gap-3">
              <div>
                <h3 class="text-sm font-black text-white leading-tight">Bütçene ve konumuna en uygun yemekleri bul!</h3>
                <p class="text-[10px] text-slate-400 mt-1">Az para, çok lezzet. Doğru seçim senin elinde.</p>
              </div>
              <img src="${zurnaImg}" class="w-14 h-14 rounded-xl object-cover shrink-0 border border-brand-border" alt="Dürüm">
            </div>

            <div class="p-4 rounded-2xl bg-brand-card border border-brand-orange/40">
              <div class="flex items-center gap-2 text-brand-orangeLight text-xs font-extrabold uppercase">
                <i class="fa-solid fa-wallet"></i>
                <span>Bütçe Aralığın</span>
              </div>
              <div id="interactiveBudgetValue" class="text-2xl font-black text-white mt-1">200 TL</div>
              <input type="range" min="50" max="500" value="200" oninput="document.getElementById('interactiveBudgetValue').innerText = this.value + ' TL'" class="w-full accent-brand-orange mt-3 cursor-pointer h-1.5 bg-brand-border rounded">
            </div>

            <button onclick="simulateGoToTab(1)" class="w-full py-3 bg-brand-orange hover:bg-brand-orangeDark text-white font-extrabold text-sm rounded-xl shadow-lg shadow-orange-500/30 flex items-center justify-center gap-2 transition">
              <i class="fa-solid fa-magnifying-glass"></i>
              <span>En İyisini Bul</span>
            </button>
          </div>
        \`;
      } else if (screenIndex === 1) {
        container.innerHTML = \`
          <div class="p-3 bg-brand-surface border-b border-brand-border flex items-center gap-2">
            <div class="flex items-center gap-2 bg-brand-card rounded-xl px-3 py-1.5 border border-brand-border flex-1">
              <i class="fa-solid fa-magnifying-glass text-brand-orange text-xs"></i>
              <input type="text" value="Kadıköy" class="bg-transparent text-xs text-white focus:outline-none w-full" readonly>
            </div>
          </div>
          <div class="flex-1 relative bg-[#181a20] overflow-hidden" onclick="simulateGoToTab(2)">
            <svg class="w-full h-full opacity-35" viewBox="0 0 260 400">
              <path d="M0 60 Q 80 120 180 80 T 260 140" fill="none" stroke="#33374b" stroke-width="8"/>
              <path d="M40 0 L 80 400" fill="none" stroke="#252837" stroke-width="6"/>
            </svg>
            <div class="absolute top-12 left-16 cursor-pointer">
              <div class="px-2.5 py-1.5 rounded-lg bg-emerald-600 text-white text-[10px] font-extrabold shadow flex items-center gap-1 border border-emerald-400">
                <span>180 TL</span><span>★ 4.8</span>
              </div>
              <div class="w-2.5 h-2.5 bg-emerald-600 rotate-45 mx-auto -mt-1"></div>
            </div>
            <div class="absolute bottom-8 inset-x-4 bg-brand-surface/95 border border-brand-border p-3 rounded-2xl shadow-xl flex items-center justify-between">
              <div>
                <span class="text-xs font-bold text-white">Pine dokun:</span>
                <p class="text-[10px] text-slate-400">Detayları ve fotoğrafları gör</p>
              </div>
              <span class="text-xs text-brand-orange font-bold">Kartı Aç →</span>
            </div>
          </div>
        \`;
      } else if (screenIndex === 2) {
        container.innerHTML = \`
          <div class="p-3 bg-brand-surface border-b border-brand-border flex items-center justify-between">
            <span class="text-xs font-bold text-white">Kadıköy Moda Haritası</span>
            <i class="fa-solid fa-xmark text-slate-400 cursor-pointer" onclick="simulateGoToTab(1)"></i>
          </div>
          <div class="flex-1 bg-black/60 p-4 flex flex-col justify-end">
            <div class="bg-brand-surface border border-brand-border rounded-3xl p-4 shadow-2xl space-y-3">
              <div class="relative rounded-2xl overflow-hidden h-36 border border-brand-border">
                <img src="${zurnaImg}" class="w-full h-full object-cover" alt="Zurna">
                <div class="absolute top-2.5 right-2.5 bg-emerald-500 text-white text-[10px] font-black px-2.5 py-1 rounded-lg shadow flex items-center gap-1">
                  <i class="fa-solid fa-fire text-xs"></i>
                  <span>%92 F/P Canavarı</span>
                </div>
              </div>
              <h4 class="text-base font-black text-white">Zurna Döner</h4>
              <div class="text-xs text-slate-400">Dönerci Ali Usta · 450 m</div>
              <button onclick="simulateGoToTab(4)" class="w-full mt-2.5 py-2.5 bg-brand-orange text-white font-extrabold text-xs rounded-xl shadow">
                Detayları ve Fotoğrafları Gör >
              </button>
            </div>
          </div>
        \`;
      } else if (screenIndex === 3) {
        container.innerHTML = \`
          <div class="p-4 space-y-3 flex-1">
            <div class="flex items-center gap-2 bg-brand-surface rounded-xl px-3 py-2 border border-brand-border">
              <i class="fa-solid fa-magnifying-glass text-slate-400 text-xs"></i>
              <input type="text" placeholder="Mekan veya yemek ara..." class="bg-transparent text-xs text-white focus:outline-none w-full">
            </div>
            <div class="space-y-3 pt-2">
              <div class="p-3 rounded-2xl bg-brand-card border border-brand-border flex gap-3 cursor-pointer hover:border-brand-orange/50 transition" onclick="simulateGoToTab(4)">
                <img src="${zurnaImg}" class="w-16 h-16 rounded-xl object-cover shrink-0" alt="Zurna">
                <div class="flex-1">
                  <h4 class="text-xs font-bold text-white">Zurna Döner</h4>
                  <div class="text-[10px] text-slate-400">Dönerci Ali Usta · ★ 4.8</div>
                  <div class="text-sm font-black text-white mt-1">180 TL</div>
                </div>
              </div>
            </div>
          </div>
        \`;
      } else if (screenIndex === 4) {
        container.innerHTML = \`
          <div class="p-3 bg-brand-surface border-b border-brand-border flex items-center justify-between">
            <i class="fa-solid fa-chevron-left text-white text-xs cursor-pointer" onclick="simulateGoToTab(3)"></i>
            <h3 class="text-xs font-bold text-white">Mekan Detayı & Fotoğraflar</h3>
            <div class="w-3"></div>
          </div>
          <div class="p-4 space-y-4 flex-1">
            <div class="flex flex-col items-center justify-center py-2">
              <div class="relative w-28 h-28 flex items-center justify-center">
                <svg class="w-full h-full gauge-circle" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="42" fill="none" stroke="#25252e" stroke-width="8"/>
                  <circle cx="50" cy="50" r="42" fill="none" stroke="#10B981" stroke-width="8" stroke-dasharray="264" stroke-dashoffset="32" stroke-linecap="round"/>
                </svg>
                <div class="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <span class="text-2xl font-black text-white leading-none">%88</span>
                  <span class="text-[9px] font-extrabold text-emerald-400 tracking-wider">DEĞER</span>
                </div>
              </div>
            </div>
            <div class="text-center">
              <h3 class="text-base font-black text-white">Zurna Döner</h3>
              <div class="text-xs text-slate-400">Dönerci Ali Usta · 450 m</div>
            </div>

            <!-- Customer Photos -->
            <div>
              <div class="text-xs font-bold text-white mb-2">Masadan Müşteri Fotoğrafları</div>
              <div class="grid grid-cols-3 gap-2">
                <img src="${zurnaImg}" class="h-16 w-full object-cover rounded-xl border border-brand-border cursor-pointer hover:opacity-80 transition" onclick="openPhotoPreview('${zurnaImg}', 'Masadan Dürüm Görseli')">
                <img src="${kofteImg}" class="h-16 w-full object-cover rounded-xl border border-brand-border cursor-pointer hover:opacity-80 transition" onclick="openPhotoPreview('${kofteImg}', 'Köfte Tabağı')">
                <img src="${burgerImg}" class="h-16 w-full object-cover rounded-xl border border-brand-border cursor-pointer hover:opacity-80 transition" onclick="openPhotoPreview('${burgerImg}', 'Burger ve Fiş')">
              </div>
            </div>

            <button onclick="simulateGoToTab(5)" class="w-full py-3 bg-brand-orange hover:bg-brand-orangeDark text-white font-extrabold text-xs rounded-xl shadow flex items-center justify-center gap-1.5">
              <i class="fa-solid fa-camera"></i>
              <span>Fotoğraf & Yorum Ekle</span>
            </button>
          </div>
        \`;
      } else if (screenIndex === 5) {
        container.innerHTML = \`
          <div class="p-3 bg-brand-surface border-b border-brand-border flex items-center justify-between">
            <i class="fa-solid fa-xmark text-white text-xs cursor-pointer" onclick="simulateGoToTab(4)"></i>
            <h3 class="text-xs font-bold text-white">Dükkana Fotoğraf & Yorum Ekle</h3>
            <div class="w-3"></div>
          </div>
          <div class="p-4 space-y-4 flex-1">
            <input type="file" id="phonePhotoInput" accept="image/*" class="hidden" onchange="handlePhotoUpload(event)">
            <div onclick="document.getElementById('phonePhotoInput').click()" class="relative rounded-2xl overflow-hidden h-36 border border-brand-border cursor-pointer bg-brand-card">
              <img id="previewUploadedImg" src="\${currentUploadedPhotoData}" class="w-full h-full object-cover">
              <div class="absolute inset-0 bg-black/60 flex flex-col items-center justify-center p-3 text-center">
                <i class="fa-solid fa-camera text-brand-orange text-2xl mb-1"></i>
                <span class="text-xs font-bold text-white">Fotoğraf Çek / Galeriden Yükle</span>
                <p class="text-[9px] text-slate-300">Yemeğin porsiyonunu ve adisyon fişini göster.</p>
              </div>
            </div>

            <div class="space-y-3 text-xs">
              <div>
                <div class="flex justify-between items-center text-slate-300">
                  <span class="font-bold">Lezzet</span>
                  <span class="font-mono text-brand-gold font-bold">4.5</span>
                </div>
                <input type="range" min="1" max="5" step="0.5" value="4.5" class="w-full accent-brand-orange h-1.5 bg-brand-border rounded cursor-pointer mt-1">
              </div>
              <div>
                <div class="flex justify-between items-center text-slate-300">
                  <span class="font-bold">Doyuruculuk</span>
                  <span class="font-mono text-brand-green font-bold">4.0</span>
                </div>
                <input type="range" min="1" max="5" step="0.5" value="4.0" class="w-full accent-brand-green h-1.5 bg-brand-border rounded cursor-pointer mt-1">
              </div>
            </div>

            <textarea id="reviewCommentInput" placeholder="Yemek nasıldı? Porsiyon doyurdu mu? Diğer müşterilere tavsiyen nedir?.." rows="3" class="w-full bg-brand-card border border-brand-border rounded-xl text-white text-xs p-3 focus:outline-none"></textarea>

            <button onclick="submitRealReview()" class="w-full py-3 bg-brand-orange hover:bg-brand-orangeDark text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center justify-center gap-1.5">
              <i class="fa-solid fa-paper-plane"></i>
              <span>Fotoğraflı Yorumu Yayınla (+50 Puan)</span>
            </button>
          </div>
        \`;
      } else if (screenIndex === 6) {
        const favCount = favoriteFoodsList.length;
        const avgFp = favCount ? Math.round(favoriteFoodsList.reduce((acc, f) => acc + (f.fpScore || 90), 0) / favCount) : 0;
        const avgPrice = favCount ? Math.round(favoriteFoodsList.reduce((acc, f) => acc + (f.price || 180), 0) / favCount) : 0;

        container.innerHTML = \`
          <div class="px-4 py-3 bg-brand-surface border-b border-brand-border flex items-center justify-between">
            <div class="flex items-center gap-2">
              <div class="w-7 h-7 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center text-xs">
                <i class="fa-solid fa-heart"></i>
              </div>
              <div>
                <h3 class="text-xs font-black text-white">Favorilerim</h3>
                <p class="text-[9px] text-slate-400">Android Room SQLite Çevrimdışı</p>
              </div>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="text-[9px] font-black bg-brand-orange/20 text-brand-orange px-2 py-0.5 rounded-full border border-brand-orange/30">\${favCount} Mekan</span>
              \${favCount > 0 ? \`<button onclick="clearAllFavorites()" class="text-slate-400 hover:text-red-400 text-xs p-1" title="Tümünü Temizle"><i class="fa-solid fa-trash-can"></i></button>\` : ''}
            </div>
          </div>

          <div class="p-3.5 space-y-3 flex-1 overflow-y-auto custom-scrollbar">
            \${favCount > 0 ? \`
              <div class="p-2.5 rounded-xl bg-brand-card border border-brand-border grid grid-cols-3 text-center text-xs">
                <div>
                  <div class="text-[8px] text-slate-400">Kayıtlı</div>
                  <div class="text-xs font-black text-white mt-0.5">\${favCount}</div>
                </div>
                <div class="border-x border-brand-border">
                  <div class="text-[8px] text-slate-400">Ort. F/P</div>
                  <div class="text-xs font-black text-emerald-400 mt-0.5">%\${avgFp}</div>
                </div>
                <div>
                  <div class="text-[8px] text-slate-400">Ort. Fiyat</div>
                  <div class="text-xs font-black text-brand-orange mt-0.5">\${avgPrice} TL</div>
                </div>
              </div>

              <div class="space-y-2">
                \${favoriteFoodsList.map(item => \`
                  <div class="p-2.5 rounded-xl bg-brand-card border border-brand-border flex gap-2.5 items-center hover:border-brand-orange/40 transition">
                    <img src="\${item.img}" class="w-12 h-12 rounded-lg object-cover border border-brand-border shrink-0" alt="\${item.name}">
                    <div class="flex-1 min-w-0">
                      <div class="flex items-center justify-between">
                        <h4 class="text-xs font-bold text-white truncate">\${item.name}</h4>
                        <button onclick="toggleFavoriteFood({ id: '\${item.id}', name: '\${item.name.replace(/'/g, \"\\\\'\")}' })" class="text-rose-500 hover:text-rose-400 text-xs ml-1" title="Favorilerden Çıkar">
                          <i class="fa-solid fa-heart"></i>
                        </button>
                      </div>
                      <div class="text-[9px] text-slate-400 truncate">\${item.shop} · \${item.distance || 300}m</div>
                      <div class="flex items-center justify-between mt-1">
                        <span class="text-[8px] bg-emerald-500/20 text-emerald-400 font-extrabold px-1.5 py-0.5 rounded">%\${item.fpScore || 92} F/P</span>
                        <span class="text-xs font-black text-white">\${item.price} TL</span>
                      </div>
                    </div>
                  </div>
                \`).join('')}
              </div>
            \` : \`
              <div class="text-center py-8 px-4 space-y-2.5 bg-brand-card rounded-2xl border border-brand-border">
                <div class="w-12 h-12 rounded-full bg-rose-500/10 text-rose-400 flex items-center justify-center text-xl mx-auto">
                  <i class="fa-regular fa-heart"></i>
                </div>
                <h4 class="text-xs font-bold text-white">Henüz Favori Mekanın Yok</h4>
                <p class="text-[9px] text-slate-400 leading-relaxed">Yemeklerin üzerindeki kalp simgesine dokunarak Room SQLite veritabanına ekleyebilirsin.</p>
                <button onclick="simulateGoToTab(0)" class="px-3 py-1.5 bg-brand-orange hover:bg-brand-orangeDark text-white text-[10px] font-bold rounded-lg shadow transition">
                  F/P Mekanlarını Keşfet
                </button>
              </div>
            \`}
          </div>
        \`;
      }
    }

    function selectWorth(isYes) {
      selectedWorthValue = isYes;
      const btnYes = document.getElementById('btnWorthYes');
      const btnNo = document.getElementById('btnWorthNo');
      if (btnYes && btnNo) {
        if (isYes) {
          btnYes.className = 'py-2 rounded-xl bg-emerald-600 text-white font-extrabold flex items-center justify-center gap-1 shadow';
          btnNo.className = 'py-2 rounded-xl bg-brand-card text-slate-300 border border-brand-border font-bold flex items-center justify-center gap-1';
        } else {
          btnYes.className = 'py-2 rounded-xl bg-brand-card text-slate-300 border border-brand-border font-bold flex items-center justify-center gap-1';
          btnNo.className = 'py-2 rounded-xl bg-red-600 text-white font-extrabold flex items-center justify-center gap-1 shadow';
        }
      }
    }

    // Modal & Flutter Code Management
    const snippets = {
      pubspec: \`name: yemegini_ye
description: "Doydunmu - Fotoğraf ve Fiş Doğrulamalı F/P Rehberi"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.6
  google_fonts: ^6.2.1
  image_picker: ^1.1.2

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true\`,

      main: \`import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'models/food_item.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const YemeginiYeApp());
}

class YemeginiYeApp extends StatefulWidget {
  const YemeginiYeApp({super.key});

  @override
  State<YemeginiYeApp> createState() => _YemeginiYeAppState();
}

class _YemeginiYeAppState extends State<YemeginiYeApp> {
  final List<FoodItem> _foods = [
    FoodItem(
      id: '1',
      restaurantName: 'Dönerci Ali Usta',
      dishName: 'Zurna Döner',
      price: 180,
      category: 'Döner',
      fpScore: 92,
      satietyScore: 95,
      neighborhood: 'Kadıköy',
      imageUrl: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=600',
      reviewCount: 1248,
      rating: 4.8,
      distanceMeters: 450,
      tags: ['Döner', 'Öğrenci Dostu', 'Hızlı Servis'],
      photos: [
        'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=300',
        'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=300'
      ],
      mapX: 0.25,
      mapY: 0.32,
    ),
  ];

  final List<UserReview> _reviews = [
    UserReview(
      id: 'r1',
      userName: 'Lezzet Avcısı',
      userBadge: 'F/P Canavarı',
      comment: 'Fiyatına göre gerçekten efsane. Eti çok lezzetli, porsiyon da doyurucu. Fotoğrafımı ve fişimi ekledim!',
      timeAgo: '2 gün önce',
      tasteScore: 5.0,
      fullnessScore: 5.0,
      fpScore: 5.0,
      isWorthIt: true,
      photoUrl: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=300',
    ),
  ];

  void _addReview(UserReview review) {
    setState(() => _reviews.insert(0, review));
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Doydunmu',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
        primaryColor: const Color(0xFFFF5722),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFF5722),
          secondary: Color(0xFF10B981),
          surface: Color(0xFF1E1E24),
          error: Color(0xFFEF4444),
        ),
        textTheme: GoogleFonts.plusJakartaSansTextTheme(ThemeData.dark().textTheme),
        useMaterial3: true,
      ),
      home: HomeScreen(foods: _foods, reviews: _reviews, onAddReview: _addReview),
    );
  }
}\`,

      model: \`class FoodItem {
  final String id;
  final String restaurantName;
  final String dishName;
  final int price;
  final int? originalPrice;
  final String category;
  final int fpScore;
  final int satietyScore;
  final bool isTrap;
  final String? trapReason;
  final String neighborhood;
  final String imageUrl;
  final int reviewCount;
  final double rating;
  final int distanceMeters;
  final List<String> tags;
  final List<String> photos;
  final double mapX;
  final double mapY;

  FoodItem({
    required this.id,
    required this.restaurantName,
    required this.dishName,
    required this.price,
    this.originalPrice,
    required this.category,
    required this.fpScore,
    required this.satietyScore,
    this.isTrap = false,
    this.trapReason,
    required this.neighborhood,
    required this.imageUrl,
    required this.reviewCount,
    required this.rating,
    required this.distanceMeters,
    required this.tags,
    required this.photos,
    required this.mapX,
    required this.mapY,
  });
}

class UserReview {
  final String id;
  final String userName;
  final String userBadge;
  final String comment;
  final String timeAgo;
  final double tasteScore;
  final double fullnessScore;
  final double fpScore;
  final bool isWorthIt;
  final String? photoUrl;

  UserReview({
    required this.id,
    required this.userName,
    required this.userBadge,
    required this.comment,
    required this.timeAgo,
    required this.tasteScore,
    required this.fullnessScore,
    required this.fpScore,
    required this.isWorthIt,
    this.photoUrl,
  });
}\`,

      review: \`// Android Studio Yolu: lib/screens/add_review_screen.dart
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/food_item.dart';

class AddReviewScreen extends StatefulWidget {
  final FoodItem food;
  final Function(UserReview) onAddReview;

  const AddReviewScreen({super.key, required this.food, required this.onAddReview});

  @override
  State<AddReviewScreen> createState() => _AddReviewScreenState();
}

class _AddReviewScreenState extends State<AddReviewScreen> {
  final TextEditingController _commentController = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  XFile? _selectedImage;

  double _taste = 4.5;
  double _fullness = 4.0;
  double _fp = 4.5;
  bool _isWorthIt = true;

  Future<void> _pickImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() => _selectedImage = image);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        title: const Text('Fotoğraflı Yorum Ekle', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Fotoğraf Kutusu
          GestureDetector(
            onTap: _pickImage,
            child: Container(
              height: 140,
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E24),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFFF5722), width: 1.5),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.camera_alt, color: Color(0xFFFF5722), size: 36),
                  const SizedBox(height: 6),
                  Text(
                    _selectedImage != null ? '✓ Fotoğraf Seçildi' : 'Masadan Fotoğraf veya Fiş Yükle',
                    style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 13),
                  ),
                  const SizedBox(height: 2),
                  const Text('Müşterilerin gerçek porsiyonu görmesini sağla', style: TextStyle(color: Colors.grey, fontSize: 10)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Puanlama Sliderları
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Lezzet Puanı', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
              Text(_taste.toString(), style: const TextStyle(color: Color(0xFFFF5722), fontWeight: FontWeight.bold)),
            ],
          ),
          Slider(value: _taste, min: 1, max: 5, divisions: 8, activeColor: const Color(0xFFFF5722), onChanged: (v) => setState(() => _taste = v)),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Doyuruculuk', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
              Text(_fullness.toString(), style: const TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold)),
            ],
          ),
          Slider(value: _fullness, min: 1, max: 5, divisions: 8, activeColor: const Color(0xFF10B981), onChanged: (v) => setState(() => _fullness = v)),

          // Yorum Kutusu
          TextField(
            controller: _commentController,
            maxLines: 3,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Yemek ve porsiyon nasıldı? Fişini ekledin mi?..',
              hintStyle: const TextStyle(color: Colors.grey, fontSize: 12),
              filled: true,
              fillColor: const Color(0xFF1E1E24),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
          const SizedBox(height: 16),

          // Değer mi?
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: _isWorthIt ? const Color(0xFF10B981) : const Color(0xFF1E1E24)),
                  onPressed: () => setState(() => _isWorthIt = true),
                  child: const Text('EVET, DEĞER', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: !_isWorthIt ? const Color(0xFFEF4444) : const Color(0xFF1E1E24)),
                  onPressed: () => setState(() => _isWorthIt = false),
                  child: const Text('HAYIR', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          SizedBox(
            height: 50,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF5722), shape: RoundedCornerShape(14)),
              icon: const Icon(Icons.send, color: Colors.white),
              label: const Text('Fotoğraflı Yorumu Yayınla (+50 Puan)', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              onPressed: () {
                widget.onAddReview(UserReview(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  userName: 'Sen (Altın Denetçi)',
                  userBadge: 'F/P Canavarı',
                  comment: _commentController.text.isEmpty ? 'Masadan fotoğraf ve porsiyon doğrulaması yapıldı.' : _commentController.text,
                  timeAgo: 'Az önce',
                  tasteScore: _taste,
                  fullnessScore: _fullness,
                  fpScore: _fp,
                  isWorthIt: _isWorthIt,
                  photoUrl: widget.food.imageUrl,
                ));
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }
}\`,

      detail: \`// Android Studio Yolu: lib/screens/dish_detail_screen.dart
import 'package:flutter/material.dart';
import '../models/food_item.dart';
import 'add_review_screen.dart';

class DishDetailScreen extends StatelessWidget {
  final FoodItem food;
  final List<UserReview> reviews;
  final Function(UserReview) onAddReview;

  const DishDetailScreen({super.key, required this.food, required this.reviews, required this.onAddReview});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF121212),
        title: Text(food.restaurantName, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Fotoğraflar Galerisi
          const Text('Masadan Müşteri Fotoğrafları', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.white)),
          const SizedBox(height: 8),
          SizedBox(
            height: 80,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: food.photos.map((url) => Container(
                margin: const EdgeInsets.only(right: 8),
                width: 80,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  image: DecorationImage(image: NetworkImage(url), fit: BoxFit.cover),
                ),
              )).toList(),
            ),
          ),
          const SizedBox(height: 20),

          // Kullanıcı Yorumları (Fotoğraflı)
          const Text('Kullanıcı Yorumları', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.white)),
          const SizedBox(height: 10),
          ...reviews.map((rev) => Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: const Color(0xFF1E1E24), borderRadius: BorderRadius.circular(14)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(rev.userName, style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                    Text(rev.userBadge, style: const TextStyle(color: Color(0xFF10B981), fontSize: 11, fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(rev.comment, style: const TextStyle(color: Color(0xFFCBD5E1), fontSize: 12)),
                if (rev.photoUrl != null) ...[
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(rev.photoUrl!, height: 60, width: 60, fit: BoxFit.cover),
                  ),
                ],
              ],
            ),
          )),
        ],
      ),
    );
  }
}\`
    };

    let activeKey = 'review';

    function toggleFlutterModal(show) {
      const modal = document.getElementById('flutterModal');
      if (show) {
        modal.classList.remove('hidden');
        showCodeSnippet('review');
      } else {
        modal.classList.add('hidden');
      }
    }

    function showCodeSnippet(key) {
      activeKey = key;
      const paths = {
        pubspec: 'pubspec.yaml',
        main: 'lib/main.dart',
        model: 'lib/models/food_item.dart',
        detail: 'lib/screens/dish_detail_screen.dart',
        review: 'lib/screens/add_review_screen.dart'
      };

      document.getElementById('currentCodePath').innerText = paths[key] || key;
      document.getElementById('codeViewerBox').innerText = snippets[key] || '';

      document.querySelectorAll('.code-tab-btn').forEach(btn => {
        btn.className = 'code-tab-btn px-3 py-1.5 rounded-lg bg-brand-card text-slate-300 hover:text-white shrink-0';
      });
      const activeBtn = document.getElementById('btn_' + key);
      if (activeBtn) activeBtn.className = 'code-tab-btn px-3 py-1.5 rounded-lg bg-brand-orange text-white shrink-0';
    }

    function copyCurrentCode() {
      const text = snippets[activeKey] || '';
      navigator.clipboard.writeText(text).then(() => {
        const btnText = document.getElementById('copyBtnText');
        btnText.innerText = 'Kopyalandı! ✓';
        setTimeout(() => { btnText.innerText = 'Kodu Kopyala'; }, 2000);
      });
    }

    // ==========================================
    // PLAY SERVICES LOCATION CONTROLLER
    // ==========================================
    let userHasLocationPermission = false;
    let userLocation = { lat: 40.9880, lon: 29.0250, name: "Kadıköy Moda" };

    function toggleLocationModal(show) {
      const modal = document.getElementById('locationModal');
      if (show) modal.classList.remove('hidden');
      else modal.classList.add('hidden');
    }

    function requestPlayServicesLocation() {
      toggleLocationModal(true);
    }

    function executeLocationPermission(requestBrowser) {
      const statusBox = document.getElementById('gpsStatusBox');
      const coordsText = document.getElementById('gpsCoordsText');

      if (requestBrowser && navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            userLocation.lat = pos.coords.latitude;
            userLocation.lon = pos.coords.longitude;
            userLocation.name = "Kadıköy (Canlı GPS)";
            applyLocationSuccess();
          },
          (err) => {
            console.log("Geolocation fallback to Play Services default:", err.message);
            userLocation.lat = 40.9885;
            userLocation.lon = 29.0268;
            userLocation.name = "Kadıköy Moda (Play Services)";
            applyLocationSuccess();
          },
          { enableHighAccuracy: true, timeout: 6000 }
        );
      } else {
        userLocation.name = "Kadıköy Moda";
        applyLocationSuccess();
      }

      function applyLocationSuccess() {
        userHasLocationPermission = true;
        statusBox.classList.remove('hidden');
        coordsText.innerText = 'Enlem: ' + userLocation.lat.toFixed(4) + ' | Boylam: ' + userLocation.lon.toFixed(4) + ' (' + userLocation.name + ')';
        
        // Update header button
        const hdrText = document.getElementById('headerGpsText');
        if (hdrText) hdrText.innerText = 'GPS Aktif: ' + userLocation.name;
        const hdrBtn = document.getElementById('headerGpsBtn');
        if (hdrBtn) hdrBtn.className = 'px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 bg-emerald-600 text-white shadow-lg shadow-emerald-500/20';

        setTimeout(() => {
          toggleLocationModal(false);
          showAppToast(
            "📍 Play Services GPS Doğrulandı",
            "Konum: " + userLocation.name + " (" + userLocation.lat.toFixed(4) + ", " + userLocation.lon.toFixed(4) + "). Restoranların yürüme mesafeleri ve süreleri güncellendi.",
            "fa-satellite-dish",
            "emerald"
          );
        }, 500);
      }
    }

    // ==========================================
    // AI ADVISOR (GEMINI) CONTROLLER
    // ==========================================
    let aiSelectedHunger = 'Çok Açım';
    let aiSelectedCraving = 'Fark Etmez';

    function toggleAiAdvisorModal(show) {
      const modal = document.getElementById('aiAdvisorModal');
      if (show) modal.classList.remove('hidden');
      else modal.classList.add('hidden');
    }

    function openAiAdvisorModal() {
      toggleAiAdvisorModal(true);
    }

    function switchAiTab(tabKey) {
      ['recommend', 'audit', 'compare'].forEach(k => {
        document.getElementById('aiTab_' + k).classList.toggle('hidden', k !== tabKey);
        const btn = document.getElementById('aiTabBtn_' + k);
        if (btn) {
          if (k === tabKey) {
            btn.className = 'px-4 py-2.5 border-b-2 border-indigo-500 text-indigo-400 flex items-center gap-2';
          } else {
            btn.className = 'px-4 py-2.5 border-b-2 border-transparent text-slate-400 hover:text-white flex items-center gap-2';
          }
        }
      });
    }

    function setAiHunger(val, btn) {
      aiSelectedHunger = val;
      document.querySelectorAll('.ai-hunger-btn').forEach(b => {
        b.className = 'ai-hunger-btn py-1.5 text-[11px] font-bold rounded-lg bg-brand-surface text-slate-300 hover:bg-slate-700';
      });
      btn.className = 'ai-hunger-btn py-1.5 text-[11px] font-bold rounded-lg bg-indigo-600 text-white';
    }

    function setAiCraving(val, btn) {
      aiSelectedCraving = val;
      document.querySelectorAll('.ai-craving-btn').forEach(b => {
        b.className = 'ai-craving-btn px-3 py-1.5 rounded-lg bg-brand-surface text-slate-300 hover:bg-slate-700';
      });
      btn.className = 'ai-craving-btn px-3 py-1.5 rounded-lg bg-indigo-600 text-white';
    }

    async function runAiRecommendation() {
      const btn = document.getElementById('aiRunBtn');
      const budget = document.getElementById('aiBudgetInput').value;
      const originalText = btn.innerHTML;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Gemini F/P Motoru Analiz Ediyor...</span>';
      btn.disabled = true;

      try {
        const res = await fetch('/api/ai/recommend', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            budget: parseInt(budget, 10),
            hunger: aiSelectedHunger,
            craving: aiSelectedCraving,
            location: userLocation.name
          })
        });
        const data = await res.json();
        
        document.getElementById('aiResTitle').innerText = data.title;
        document.getElementById('aiResSubtitle').innerText = data.restaurant + ' · ' + data.price + ' TL (' + data.distance + ')';
        document.getElementById('aiResRationale').innerText = data.rationale;
        document.getElementById('aiResTip').innerText = data.satietyTip;
        document.getElementById('aiResTrap').innerText = data.trapWarning;
        document.getElementById('aiResFpScore').innerText = '%' + data.fpScore + ' F/P Skoru';
      } catch (e) {
        console.error(e);
      } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
      }
    }

    function fillAuditSample(rest, dish, price) {
      document.getElementById('auditRestaurantInput').value = rest;
      document.getElementById('auditDishInput').value = dish;
      document.getElementById('auditPriceInput').value = price;
      runAiAudit();
    }

    async function runAiAudit() {
      const rest = document.getElementById('auditRestaurantInput').value;
      const dish = document.getElementById('auditDishInput').value;
      const price = document.getElementById('auditPriceInput').value;
      const btn = document.getElementById('aiAuditBtn');
      const originalText = btn.innerHTML;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Adisyon Denetleniyor...</span>';
      btn.disabled = true;

      try {
        const res = await fetch('/api/ai/audit-receipt', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ restaurant: rest, dish: dish, price: price })
        });
        const data = await res.json();

        const card = document.getElementById('aiAuditResult');
        const verdict = document.getElementById('auditVerdict');
        const fpScore = document.getElementById('auditFpScore');
        const fairPrice = document.getElementById('auditFairPrice');
        const alerts = document.getElementById('auditAlerts');
        const advice = document.getElementById('auditAdvice');

        verdict.innerText = data.verdict;
        verdict.className = data.isFairPrice ? 'text-xs font-black text-emerald-400' : 'text-xs font-black text-red-400';
        fpScore.innerText = '%' + data.fpScore + ' F/P Skoru';
        fpScore.className = data.isFairPrice ? 'text-[10px] font-black bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-400/30' : 'text-[10px] font-black bg-red-500/20 text-red-300 px-2 py-0.5 rounded border border-red-400/30';
        card.className = data.isFairPrice ? 'p-4 rounded-2xl bg-brand-card border border-emerald-500/40 space-y-3' : 'p-4 rounded-2xl bg-brand-card border border-red-500/40 space-y-3';
        
        fairPrice.innerHTML = 'Tahmini Adil Piyasa Değeri: <strong class="text-white">' + data.estimatedFairPrice + ' TL</strong> (Ödenen: ' + price + ' TL)';
        alerts.innerHTML = data.fraudAlerts.map(function(a) { return '<div>• ' + a + '</div>'; }).join('');
        alerts.className = data.isFairPrice ? 'space-y-1.5 text-xs text-emerald-300/90 bg-emerald-950/30 p-3 rounded-xl border border-emerald-800/40' : 'space-y-1.5 text-xs text-red-300/90 bg-red-950/30 p-3 rounded-xl border border-red-800/40';
        advice.innerText = 'Tavsiye: ' + data.advice;
      } catch (e) {
        console.error(e);
      } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
      }
    }

    function runAiCompare() {
      const a = document.getElementById('compareA').value;
      const b = document.getElementById('compareB').value;
      const resultBox = document.getElementById('aiCompareResult');

      if (a === '1' && b === '5') {
        resultBox.innerText = [
          '🥊 F/P KARŞILAŞTIRMA RAPORU:',
          '1 Lira Başına Doyuruculuk Endeksi:',
          '• 70cm Tavuk Zurna (180 TL): 54 Puan (Tokluk: %98, Protein: 220gr)',
          '• Boğa Meydanı Döner (420 TL): 8 Puan (Tokluk: %35, Porsiyon: 110gr)',
          '',
          '🏆 KAZANAN: 70cm Tavuk Zurna Dürüm (Hatay Dürüm Dünyası)',
          'Bu seçim paranızın karşılığını %575 daha fazla verir ve 240 TL cebinizde kalır!'
        ].join('\n');
      } else {
        resultBox.innerText = [
          '🥊 F/P KARŞILAŞTIRMA RAPORU:',
          'Gemini F/P Yapay Zeka Motoru:',
          '• Seçilen A Menüsü: %92 Doyuruculuk / Fiyat Dengesi',
          '• Seçilen B Menüsü: %65 Doyuruculuk / Fiyat Dengesi',
          '',
          '🏆 KAZANAN: 1. Seçenek',
          'Gramaj başına birim maliyet Kadıköy ortalamasından daha avantajlıdır.'
        ].join('\n');
      }
    }

    // Initialize Room favorites badges
    updateFavoriteBadges();
  </script>
</body>
</html>`;

// Robust helper to query Gemini 3.8 Flash for AI features
async function callGemini(systemPrompt, userPrompt) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return null;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 7000);
    const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${key}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({
        contents: [{ parts: [{ text: userPrompt }] }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: {
          responseMimeType: "application/json"
        }
      })
    });
    clearTimeout(timeout);
    if (!resp.ok) return null;
    const json = await resp.json();
    const text = json.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) return null;
    return JSON.parse(text);
  } catch (e) {
    return null;
  }
}

// Create resilient server instance that binds safely
function createDoydunmuServer(port) {
  const srv = http.createServer((req, res) => {
    if (req.url === '/health' || req.url === '/_health') {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end('OK');
      return;
    }

    // AI API Endpoints
    if (req.url.startsWith('/api/ai/')) {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', async () => {
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Access-Control-Allow-Origin': '*'
        });
        try {
          const data = body ? JSON.parse(body) : {};
          if (req.url === '/api/ai/recommend') {
            const budget = data.budget || 200;
            const craving = data.craving || 'Fark Etmez';

            if (process.env.GEMINI_API_KEY) {
              const geminiRes = await callGemini(
                "Sen 'Doydunmu' uygulamasının F/P (Fiyat/Performans) yapay zeka gurmesisin. Kullanıcının bütçesine, açlığına ve konumuna göre İstanbul Kadıköy bölgesindeki en yüksek gramaj, tokluk ve lezzet sunan mekan tavsiyesini JSON formatında üret. Alanlar: title, restaurant, price (sayı), distance, fpScore (sayı 0-100), satietyScore (sayı 0-100), rationale, satietyTip, trapWarning.",
                `Bütçe: ${budget} TL, Açlık: ${data.hunger || 'Çok Açım'}, İstek: ${craving}, Konum: ${data.location || 'Kadıköy'}`
              );
              if (geminiRes && geminiRes.title) {
                res.end(JSON.stringify(geminiRes));
                return;
              }
            }

            let responseData;
            if (craving.includes('Burger')) {
              responseData = {
                title: "Yapay Zeka Tavsiyesi: Double Smash Cheddar Burger (195 TL)",
                restaurant: "Kadıköy Burger Lab",
                price: 195,
                distance: "240m (3 dk yürüme)",
                fpScore: 91,
                satietyScore: 92,
                rationale: `Kadıköy Burger Lab, ${budget} TL bütçen için 2x90gr gerçek dana köftesi ve çıtır patatesiyle zincir restoranlara kıyasla %55 daha yüksek gramaj ve F/P sunuyor.`,
                satietyTip: "Yanındaki patates standart menüde geliyor, ekstra sos söylemeyip 195 TL'de kalarak bütçeni koru.",
                trapWarning: "Moda girişindeki 350-400 TL'lik 'Gurme Smash' butiklerine gitme; aynı lezzeti yarı fiyatına alırsın."
              };
            } else if (craving.includes('Lahmacun')) {
              responseData = {
                title: "Yapay Zeka Tavsiyesi: 2x Çıtır Antep Lahmacun Menü (160 TL)",
                restaurant: "Moda Taş Fırın",
                price: 160,
                distance: "420m (5 dk yürüme)",
                fpScore: 94,
                satietyScore: 90,
                rationale: `${budget} TL bütçeyle en temiz unlu mamul ve protein dengesi. 2 adet çıtır fırın lahmacun ve sınırsız taze yeşillik.`,
                satietyTip: "İki lahmacunu bol yeşillikle sarıp yersen doyuruculuğu 5 saat boyunca açlık hissettirmez.",
                trapWarning: "Açık kutu meşrubatlara dikkat, lahmacunun yanında kapalı kutu ayran tercih et."
              };
            } else {
              responseData = {
                title: "Yapay Zeka F/P Şampiyonu: 70cm Özel Soslu Zurna Dürüm (180 TL)",
                restaurant: "Hatay Dürüm Dünyası",
                price: 180,
                distance: "120m (2 dk yürüme)",
                fpScore: 96,
                satietyScore: 98,
                rationale: `Gemini F/P motoru, Kadıköy'deki 34 mekan arasında ${budget} TL altındaki 1 Lira başına en yüksek tokluk puanını Hatay Dürüm Dünyası'nda tespit etti.`,
                satietyTip: "Sarımsaklı mayonezli özel sosu ve çift lavaşı sayesinde ek bir yan ürüne ihtiyaç bırakmaz.",
                trapWarning: "Boğa Meydanı'ndaki 420 TL'lik turist tuzakları 110 gr döner verirken burada 220 gr tavuk döner alırsın."
              };
            }
            res.end(JSON.stringify(responseData));
            return;
          }

          if (req.url === '/api/ai/audit-receipt') {
            const price = parseInt(data.price || '420', 10);
            const restaurant = data.restaurant || 'Boğa Meydanı Gurme Döner';

            if (process.env.GEMINI_API_KEY) {
              const geminiRes = await callGemini(
                "Sen restoran adisyon ve fiş denetçisi yapay zekasısın. İstanbul Kadıköy fiyatlarını ve porsiyon standartlarını baz alarak fişi denetle. Fahiş fiyat, kuver tuzağı veya adil F/P durumunu JSON olarak dön. Alanlar: isFairPrice (boolean), fpScore (sayı), estimatedFairPrice (sayı), verdict (metin), fraudAlerts (string dizisi), advice (metin).",
                `Mekan: ${restaurant}, Ürün/Yemek: ${data.dish || 'Yemek'}, Ödenen Fiyat: ${price} TL`
              );
              if (geminiRes && geminiRes.verdict) {
                res.end(JSON.stringify(geminiRes));
                return;
              }
            }

            const isTrap = price > 280 || restaurant.includes('Boğa') || restaurant.includes('Bistro');

            const auditData = {
              isFairPrice: !isTrap,
              fpScore: isTrap ? 22 : 94,
              estimatedFairPrice: isTrap ? Math.round(price * 0.45) : price,
              verdict: isTrap ? "⚠️ KAZIK / TUZAK ADİSYON TESPİT EDİLDİ" : "✅ F/P Onaylı Adil Adisyon",
              fraudAlerts: isTrap ? [
                "Porsiyon gramajına oranla %70 fahiş fiyat tespit edildi.",
                "Masa kuver ve izinsiz su servisi riski var.",
                "Kadıköy ortalamasının iki katı üzerinde ücretlendirme."
              ] : [
                "Fiyat Kadıköy F/P taban fiyat standartlarına uygundur.",
                "Herhangi bir gizli kuver veya haksız kalem tespit edilmedi."
              ],
              advice: isTrap ? "Bu mekana ait fişi sisteme şikayet olarak yükleyip diğer kullanıcıları uyarabilirsin." : "Topluluk denetimi için fiş puanını kaydet ve F/P rozetini kazan."
            };
            res.end(JSON.stringify(auditData));
            return;
          }

          res.end(JSON.stringify({ status: 'ok' }));
        } catch (e) {
          res.end(JSON.stringify({ error: e.message }));
        }
      });
      return;
    }

    res.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-cache'
    });
    if (req.method === 'HEAD') {
      res.end();
    } else {
      res.end(htmlContent);
    }
  });

  srv.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.log(`Port ${port} is already in use by proxy/system. Continuing on primary port.`);
    } else {
      console.error(`Server error on port ${port}:`, err);
    }
  });

  srv.listen(port, '0.0.0.0', () => {
    console.log(`Doydunmu Server listening at http://0.0.0.0:${port}`);
  });

  return srv;
}

// Server listens on DEFAULT_APP_PORT (3000 in AI Studio / Nginx environment) or PORT in standalone Cloud Run
const port = parseInt(process.env.PORT || process.env.DEFAULT_APP_PORT || '3000', 10);
createDoydunmuServer(port);


// Clean termination handlers for Cloud Run
process.on('SIGTERM', () => {
  console.log('Received SIGTERM. Exiting gracefully...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Received SIGINT. Exiting gracefully...');
  process.exit(0);
});

