# Doydunmu — Render dağıtım paketi

Bu paket, Doydunmu web sitesinin Node.js sunucusunu Render üzerinde çalıştırmak için hazırlanmıştır. Android/Gradle dosyaları web dağıtımına dahil edilmez; örnek yemek fotoğrafları korunur.

## Yerel çalıştırma

- Node.js 20 veya üzerini kur.
- Proje klasöründe `npm install` çalıştır.
- `npm start` ile sunucuyu başlat.
- `http://localhost:3000` adresini aç.
- `npm test` ile JavaScript sözdizimi kontrolünü çalıştır.

## Render dağıtımı (önemli)

1. Bu klasörün **içindeki dosyaları** GitHub deposunun kök dizinine yükle. `package.json`, `server.js` ve `render.yaml` aynı seviyede olmalı.
2. Render Dashboard > New > Web Service üzerinden bu GitHub deposunu bağla.
3. **Root Directory alanını boş bırak.** `src` veya `app` yazma; bu pakette `package.json` depo kökündedir.
4. Build Command: `npm install`
5. Start Command: `npm start`
6. Health Check Path: `/health`
7. Deploy et. Dağıtım tamamlanınca `https://SENIN-SITEN.onrender.com/health` adresi `OK` dönmeli.

`render.yaml` kullanıyorsan Render servis ayarlarını bu dosyadan okuyabilir. Dashboard'da eski bir Root Directory `src` olarak kayıtlıysa düzelt; bu, `Couldn't find a package.json file in '/opt/render/project/src'` hatasının yaygın nedenidir.

## GEMINI_API_KEY

AI özelliklerini kullanacaksan Render > Environment bölümüne `GEMINI_API_KEY` adlı gizli ortam değişkeni ekle. Gerçek API anahtarını GitHub'a veya kaynak koduna yazma. Anahtar olmadan uygulama tanımlı örnek cevaplarla açılır.

## Veri kalıcılığı notu

Bu prototipte favoriler ve gönderilen yorumlar tarayıcının `localStorage` alanında saklanır. Bu, yalnızca aynı tarayıcı/cihazda kalıcıdır; tüm kullanıcılar arasında paylaşım sağlamaz. Render ücretsiz dosya sistemi kalıcı veritabanı olarak kullanılmamalıdır. Ortak yorumlar ve fotoğraflar için Supabase Database + Storage entegrasyonu ayrıca yapılmalıdır.
