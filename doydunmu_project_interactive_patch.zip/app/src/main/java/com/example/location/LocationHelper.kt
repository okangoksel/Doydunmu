package com.example.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlin.math.*

data class UserLocationState(
  val latitude: Double = 40.9880,
  val longitude: Double = 29.0250,
  val locationName: String = "Kadıköy Moda",
  val isLiveLocation: Boolean = false,
  val error: String? = null
)

class PlayServicesLocationHelper(private val context: Context) {
  private val fusedLocationClient: FusedLocationProviderClient =
    LocationServices.getFusedLocationProviderClient(context)

  fun hasLocationPermission(): Boolean {
    val fine = ContextCompat.checkSelfPermission(
      context,
      Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(
      context,
      Manifest.permission.ACCESS_COARSE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED
    return fine || coarse
  }

  @SuppressLint("MissingPermission")
  fun getCurrentLocation(
    onSuccess: (Location) -> Unit,
    onError: (Exception) -> Unit
  ) {
    if (!hasLocationPermission()) {
      onError(SecurityException("Konum izni verilmedi"))
      return
    }

    try {
      val cts = CancellationTokenSource()
      fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
        .addOnSuccessListener { location: Location? ->
          if (location != null) {
            onSuccess(location)
          } else {
            // Fallback to lastLocation if current location returned null
            fusedLocationClient.lastLocation
              .addOnSuccessListener { lastLoc: Location? ->
                if (lastLoc != null) {
                  onSuccess(lastLoc)
                } else {
                  onError(IllegalStateException("Konum bilgisi alınamadı"))
                }
              }
              .addOnFailureListener { err -> onError(err) }
          }
        }
        .addOnFailureListener { err -> onError(err) }
    } catch (e: Exception) {
      onError(e)
    }
  }

  companion object {
    /**
     * Calculates distance in meters between two lat/lng points using Haversine formula
     */
    fun calculateDistanceMeters(
      lat1: Double,
      lon1: Double,
      lat2: Double,
      lon2: Double
    ): Int {
      val earthRadius = 6371000.0 // meters
      val dLat = Math.toRadians(lat2 - lat1)
      val dLon = Math.toRadians(lon2 - lon1)
      val a = sin(dLat / 2).pow(2) +
          cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
          sin(dLon / 2).pow(2)
      val c = 2 * atan2(sqrt(a), sqrt(1 - a))
      return (earthRadius * c).roundToInt()
    }

    fun formatDistance(meters: Int): String {
      return when {
        meters < 1000 -> "${meters}m (${max(1, (meters / 75.0).roundToInt())} dk yürüme)"
        else -> {
          val km = meters / 1000.0
          String.format("%.1f km (%d dk yürüme)", km, (meters / 75.0).roundToInt())
        }
      }
    }

    /**
     * Determines the closest neighborhood label based on coordinates
     */
    fun getNeighborhoodName(lat: Double, lon: Double): String {
      return when {
        lat < 40.9850 -> "Kadıköy Moda Burnu"
        lat < 40.9890 -> "Kadıköy Moda Caddesi"
        lat < 40.9930 && lon < 29.0270 -> "Kadıköy Rıhtım & İskele"
        lat < 40.9930 -> "Kadıköy Boğa & Çarşı"
        lat > 40.9950 && lon < 29.0200 -> "Üsküdar Sahil"
        else -> "Kadıköy Çarşı"
      }
    }
  }
}
