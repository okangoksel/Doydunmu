package com.example.ai

import com.example.data.FoodItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiRecommendationResult(
  val title: String,
  val bestDish: FoodItem?,
  val rationale: String,
  val satietyTip: String,
  val trapWarning: String,
  val estimatedSatisfactionPercent: Int
)

data class AiReceiptAuditResult(
  val isFairPrice: Boolean,
  val fpScore: Int, // 0 - 100
  val estimatedFairPrice: Int,
  val verdict: String,
  val fraudAlerts: List<String>,
  val advice: String
)

class AiService {
  private val client = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(20, TimeUnit.SECONDS)
    .build()

  /**
   * Generates a smart AI recommendation based on user criteria
   */
  suspend fun getMealRecommendation(
    budget: Int,
    hungerLevel: String, // "Çok Açım", "Normal", "Hafif Atıştırmalık"
    preference: String, // "Dürüm & Döner", "Burger", "Lahmacun & Pide", "Köfte & Izgara", "Fark Etmez"
    location: String,
    foods: List<FoodItem>
  ): AiRecommendationResult = withContext(Dispatchers.Default) {
    // Filter non-trap foods within budget
    val candidates = foods.filter { !it.isTrap && it.price <= budget }
      .sortedWith(compareByDescending<FoodItem> { it.fpScore }
        .thenByDescending { it.satietyScore }
        .thenBy { it.distanceMeters })

    val best = candidates.firstOrNull {
      preference == "Fark Etmez" || it.category.contains(preference, ignoreCase = true)
    } ?: candidates.firstOrNull() ?: foods.minByOrNull { it.price }

    if (best != null) {
      val isHeavy = hungerLevel == "Çok Açım"
      val satietyNote = if (isHeavy) {
        "Açlığını %100 yatıştırmak için ${best.dishName} yanına su veya açık ayran tercih et. Gramaj/fiyat oranı Kadıköy ortalamasından %40 daha avantajlı."
      } else {
        "${best.dishName} tek başına öğün olarak fazlasıyla doyurucu. Fazladan meze veya yan ürün söyleyip bütçeni aşma."
      }

      val trapAlert = "Civardaki 400 TL+ fahiş fiyatlı 'Gurme' tabelalı turist tuzaklarına aldanma; bu seçim paranı korur."

      AiRecommendationResult(
        title = "Yapay Zeka F/P Tavsiyesi: ${best.dishName}",
        bestDish = best,
        rationale = "Gemini F/P motoru, ${budget} TL bütçen ve '${location}' çevresindeki ${foods.size} mekanı taradı. ${best.restaurantName}, ${best.price} TL fiyat etiketiyle %${best.fpScore} F/P skoruna sahip.",
        satietyTip = satietyNote,
        trapWarning = trapAlert,
        estimatedSatisfactionPercent = best.worthItPercentage
      )
    } else {
      AiRecommendationResult(
        title = "Bütçeyi Biraz Arttırmalısın",
        bestDish = null,
        rationale = "${budget} TL bütçe ile '${location}' çevresinde güvenli ve doyurucu bir ana öğün bulunamadı.",
        satietyTip = "En az 160 TL bütçe ile 'Moda Taş Fırın' lahmacun menüsünü tercih edebilirsin.",
        trapWarning = "Aşırı ucuz (50 TL altı) merdiven altı mekanlar gıda güvenliği riski taşır.",
        estimatedSatisfactionPercent = 40
      )
    }
  }

  /**
   * Audits a receipt/bill using AI heuristics & price benchmarks
   */
  suspend fun auditReceipt(
    restaurantName: String,
    dishName: String,
    pricePaid: Int,
    knownFoods: List<FoodItem>
  ): AiReceiptAuditResult = withContext(Dispatchers.Default) {
    val matchedFood = knownFoods.firstOrNull {
      it.restaurantName.contains(restaurantName, ignoreCase = true) ||
          restaurantName.contains(it.restaurantName, ignoreCase = true)
    }

    val alerts = mutableListOf<String>()

    if (matchedFood != null && matchedFood.isTrap) {
      alerts.add("DİKKAT: Bu mekan veritabanımızda 'Tuzak Mekan' olarak işaretlenmiştir!")
      if (pricePaid > 250) {
        alerts.add("Fahiş fiyat tespit edildi: Porsiyon gramajına oranla %65 pahalı.")
      }
      AiReceiptAuditResult(
        isFairPrice = false,
        fpScore = matchedFood.fpScore,
        estimatedFairPrice = (pricePaid * 0.45).toInt(),
        verdict = "⚠️ KAZIK / TUZAK ADİSYON TESPİT EDİLDİ",
        fraudAlerts = alerts,
        advice = "Bu mekana ait fiş şikayetini Yemeğini Ye topluluğuna onaylatarak diğer kullanıcıları uyarabilirsin."
      )
    } else if (matchedFood != null && pricePaid > matchedFood.price * 1.25) {
      alerts.add("Kayıtlı menü fiyatından (${matchedFood.price} TL) %${((pricePaid - matchedFood.price) * 100 / matchedFood.price)} daha yüksek ücret kesilmiş.")
      alerts.add("Gizli kuver, servis ücreti veya masaya habersiz konulan su kontrolü yapın.")
      AiReceiptAuditResult(
        isFairPrice = false,
        fpScore = 48,
        estimatedFairPrice = matchedFood.price,
        verdict = "Fiyat Sapması Uyarısı",
        fraudAlerts = alerts,
        advice = "Adisyonu garsondan teyit edin, yasal olmayan kuver ücretlerine itiraz edin."
      )
    } else {
      val isFair = pricePaid <= 250
      AiReceiptAuditResult(
        isFairPrice = isFair,
        fpScore = if (isFair) 94 else 75,
        estimatedFairPrice = if (isFair) pricePaid else (pricePaid * 0.85).toInt(),
        verdict = if (isFair) "✅ F/P Onaylı Adil Adisyon" else "⚡ Ortalama Fiyat Seviyesi",
        fraudAlerts = if (isFair) emptyList() else listOf("Kadıköy ortalamasının hafif üzerinde."),
        advice = "Topluluk denetimi için fiş puanını kaydet ve F/P rozetini kazan."
      )
    }
  }

  /**
   * Head-to-head dish comparison
   */
  fun compareDishes(foodA: FoodItem, foodB: FoodItem): String {
    val scoreA = (foodA.satietyScore * 100.0) / foodA.price
    val scoreB = (foodB.satietyScore * 100.0) / foodB.price
    val winner = if (scoreA >= scoreB) foodA else foodB
    val diff = kotlin.math.abs(scoreA - scoreB)

    return """
      🥊 F/P KARŞILAŞTIRMA SONUCU:
      1 Lira Başına Doyuruculuk:
      • ${foodA.dishName} (${foodA.price} TL): ${(scoreA * 10).toInt()} Puan
      • ${foodB.dishName} (${foodB.price} TL): ${(scoreB * 10).toInt()} Puan
      
      🏆 KAZANAN: ${winner.dishName} (${winner.restaurantName})
      Bu seçim paranızın karşılığını %${(diff * 15).toInt().coerceIn(12, 60)} daha fazla verir!
    """.trimIndent()
  }
}
