package com.example

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FoodItem
import com.example.data.MockDataProvider
import com.example.data.ReviewItem
import com.example.data.local.AppDatabase
import com.example.data.local.FavoritesRepository
import com.example.location.PlayServicesLocationHelper
import com.example.location.UserLocationState
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        YemeginiYeApp()
      }
    }
  }
}

@Composable
fun YemeginiYeApp() {
  val context = LocalContext.current
  val locationHelper = remember { PlayServicesLocationHelper(context) }

  // Room Database & Favorites Repository
  val database = remember { AppDatabase.getDatabase(context) }
  val favoritesRepository = remember { FavoritesRepository(database.favoriteDao()) }
  val coroutineScope = rememberCoroutineScope()

  val favoriteFoods by favoritesRepository.allFavorites.collectAsState(initial = emptyList())
  val favoriteIds by favoritesRepository.favoriteIds.collectAsState(initial = emptySet())

  val handleToggleFavorite: (FoodItem) -> Unit = { food ->
    coroutineScope.launch {
      val added = favoritesRepository.toggleFavorite(food)
      if (added) {
        Toast.makeText(context, "❤️ Room Veritabanına Kaydedildi: ${food.dishName}", Toast.LENGTH_SHORT).show()
      } else {
        Toast.makeText(context, "🤍 Favorilerden Kaldırıldı", Toast.LENGTH_SHORT).show()
      }
    }
  }

  var foods by remember { mutableStateOf(MockDataProvider.initialFoods) }
  var reviews by remember { mutableStateOf(MockDataProvider.initialReviews) }

  var currentBudget by remember { mutableIntStateOf(200) }
  var selectedLocation by remember { mutableStateOf("Kadıköy Moda") }
  var userLocationState by remember { mutableStateOf(UserLocationState()) }

  var showPermissionRationale by remember { mutableStateOf(false) }

  var selectedTab by remember { mutableIntStateOf(0) } // 0: Home, 1: Map, 2: Favorites, 3: AI, 4: Search, 5: Guide
  var activeDetailFood by remember { mutableStateOf<FoodItem?>(null) }
  var activeReviewFood by remember { mutableStateOf<FoodItem?>(null) }
  var mapSelectedFood by remember { mutableStateOf<FoodItem?>(null) }

  // Location fetching function using Play Services Location
  val fetchPlayServicesLocation: () -> Unit = {
    locationHelper.getCurrentLocation(
      onSuccess = { loc ->
        val neighborhood = PlayServicesLocationHelper.getNeighborhoodName(loc.latitude, loc.longitude)
        userLocationState = UserLocationState(
          latitude = loc.latitude,
          longitude = loc.longitude,
          locationName = neighborhood,
          isLiveLocation = true
        )
        selectedLocation = neighborhood
        foods = MockDataProvider.recalculateDistances(foods, loc.latitude, loc.longitude)
        Toast.makeText(context, "📍 Canlı GPS Konumu Alındı: $neighborhood", Toast.LENGTH_SHORT).show()
      },
      onError = { err ->
        userLocationState = userLocationState.copy(error = err.message)
        Toast.makeText(context, "Konum alınamadı: ${err.message ?: "Varsayılan konum kullanılıyor"}", Toast.LENGTH_SHORT).show()
      }
    )
  }

  // Location Permission Launcher
  val locationPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestMultiplePermissions()
  ) { permissions ->
    val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
    val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false

    if (fineGranted || coarseGranted) {
      fetchPlayServicesLocation()
    } else {
      showPermissionRationale = true
    }
  }

  // Request location handler triggered by UI buttons
  val handleLocationRequest: () -> Unit = {
    if (locationHelper.hasLocationPermission()) {
      fetchPlayServicesLocation()
    } else {
      locationPermissionLauncher.launch(
        arrayOf(
          Manifest.permission.ACCESS_FINE_LOCATION,
          Manifest.permission.ACCESS_COARSE_LOCATION
        )
      )
    }
  }

  // Initial check on launch
  LaunchedEffect(Unit) {
    if (locationHelper.hasLocationPermission()) {
      fetchPlayServicesLocation()
    }
  }

  // Review submission handler
  val handleReviewSubmit = { newReview: ReviewItem, isWorthIt: Boolean ->
    reviews = listOf(newReview) + reviews
    foods = foods.map { item ->
      if (item.id == newReview.foodId) {
        val newPos = if (isWorthIt) item.positiveVotes + 1 else item.positiveVotes
        val newNeg = if (!isWorthIt) item.negativeVotes + 1 else item.negativeVotes
        val newReceiptCount = if (newReview.hasReceipt) item.receiptCount + 1 else item.receiptCount
        item.copy(
          positiveVotes = newPos,
          negativeVotes = newNeg,
          receiptCount = newReceiptCount,
          lastVerifiedDate = "Az önce güncellendi (Yeni Fiş)"
        )
      } else {
        item
      }
    }
  }

  // Permission Rationale Dialog
  if (showPermissionRationale) {
    AlertDialog(
      onDismissRequest = { showPermissionRationale = false },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.LocationOn, contentDescription = null, tint = BrandOrange)
          Text("Konum İzni Gerekli", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
      },
      text = {
        Text(
          "Yemeğini Ye, size en yakın F/P mekanlarını tespit etmek ve yürüme dakikalarını doğru hesaplamak için Google Play Services konum servisine ihtiyaç duyar. İzin vermeyi tekrar denemek ister misiniz?",
          fontSize = 13.sp,
          color = TextSecondary,
          lineHeight = 18.sp
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showPermissionRationale = false
            locationPermissionLauncher.launch(
              arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
              )
            )
          },
          colors = ButtonDefaults.buttonColors(containerColor = BrandOrange)
        ) {
          Text("İzin Ver", fontWeight = FontWeight.Bold, color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { showPermissionRationale = false }) {
          Text("Şimdilik Kadıköy Olarak Devam Et", color = TextMuted, fontSize = 12.sp)
        }
      },
      containerColor = DarkSlateSurface,
      shape = RoundedCornerShape(16.dp)
    )
  }

  // Handle Full Screen sub-routes
  when {
    activeReviewFood != null -> {
      AddReviewScreen(
        food = activeReviewFood!!,
        onBack = { activeReviewFood = null },
        onSubmitReview = { review, isWorthIt ->
          handleReviewSubmit(review, isWorthIt)
        }
      )
    }
    activeDetailFood != null -> {
      DishDetailScreen(
        food = activeDetailFood!!,
        reviews = reviews,
        onBack = { activeDetailFood = null },
        onAddReview = { food ->
          activeReviewFood = food
        },
        isFavorite = favoriteIds.contains(activeDetailFood!!.id),
        onToggleFavorite = { handleToggleFavorite(activeDetailFood!!) }
      )
    }
    else -> {
      // Main Shell with Top Bar, Bottom Bar, and Active Tab
      Scaffold(
        topBar = {
          Surface(
            color = DarkSlateSurface,
            border = androidx.compose.foundation.BorderStroke(0.5.dp, DarkSlateBorder),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              // Wordmark & Subtitle
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Surface(
                  color = BrandOrange,
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.size(32.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Text("YY", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                  }
                }

                Column {
                  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                      text = "Yemeğini Ye",
                      fontSize = 17.sp,
                      fontWeight = FontWeight.Black,
                      color = TextPrimary,
                      letterSpacing = (-0.5).sp
                    )
                    Surface(
                      color = Color(0xFF6366F1).copy(alpha = 0.2f),
                      shape = RoundedCornerShape(4.dp)
                    ) {
                      Text(
                        "AI",
                        color = Color(0xFFA5B4FC),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                      )
                    }
                  }
                  Text(
                    text = "Room SQLite & Play Services GPS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = BrandOrangeLight
                  )
                }
              }

              // Right actions: Location/Budget Badge + Guide Icon
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Surface(
                  color = DarkSlateCard,
                  shape = RoundedCornerShape(10.dp),
                  border = androidx.compose.foundation.BorderStroke(1.dp, if (userLocationState.isLiveLocation) FpGreen.copy(alpha = 0.5f) else DarkSlateBorder),
                  modifier = Modifier.clickable { handleLocationRequest() }
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                  ) {
                    Icon(
                      imageVector = if (userLocationState.isLiveLocation) Icons.Default.GpsFixed else Icons.Default.LocationOn,
                      contentDescription = null,
                      tint = if (userLocationState.isLiveLocation) FpGreen else BrandOrange,
                      modifier = Modifier.size(13.dp)
                    )
                    Text(
                      text = selectedLocation.split(" ").firstOrNull() ?: "Kadıköy",
                      color = TextPrimary,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold
                    )
                    Text(text = "·", color = TextMuted)
                    Text(
                      text = "${currentBudget} TL",
                      color = FpGreen,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.ExtraBold
                    )
                  }
                }

                IconButton(
                  onClick = { selectedTab = if (selectedTab == 5) 0 else 5 },
                  modifier = Modifier
                    .size(32.dp)
                    .background(DarkSlateCard, RoundedCornerShape(8.dp))
                    .border(0.5.dp, DarkSlateBorder, RoundedCornerShape(8.dp))
                ) {
                  Icon(
                    imageVector = Icons.Default.Code,
                    contentDescription = "Kod Rehberi",
                    tint = if (selectedTab == 5) FpGold else TextMuted,
                    modifier = Modifier.size(16.dp)
                  )
                }
              }
            }
          }
        },
        bottomBar = {
          Surface(
            color = DarkSlateSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier.fillMaxWidth()
          ) {
            NavigationBar(
              containerColor = DarkSlateSurface,
              modifier = Modifier.navigationBarsPadding(),
              tonalElevation = 8.dp
            ) {
              // Tab 0: Home
              NavigationBarItem(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                icon = {
                  Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "Keşfet",
                    tint = if (selectedTab == 0) BrandOrange else TextSecondary
                  )
                },
                label = {
                  Text(
                    "Keşfet",
                    fontSize = 10.sp,
                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Medium,
                    color = if (selectedTab == 0) BrandOrange else TextSecondary
                  )
                },
                colors = NavigationBarItemDefaults.colors(indicatorColor = DarkSlateCard)
              )

              // Tab 1: Map
              NavigationBarItem(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                icon = {
                  Icon(
                    imageVector = Icons.Default.Map,
                    contentDescription = "Harita",
                    tint = if (selectedTab == 1) BrandOrange else TextSecondary
                  )
                },
                label = {
                  Text(
                    "Harita",
                    fontSize = 10.sp,
                    fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Medium,
                    color = if (selectedTab == 1) BrandOrange else TextSecondary
                  )
                },
                colors = NavigationBarItemDefaults.colors(indicatorColor = DarkSlateCard)
              )

              // Tab 2: Favorilerim (Room DB)
              NavigationBarItem(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                icon = {
                  BadgedBox(
                    badge = {
                      if (favoriteFoods.isNotEmpty()) {
                        Badge(containerColor = BrandOrange, contentColor = Color.White) {
                          Text("${favoriteFoods.size}")
                        }
                      }
                    }
                  ) {
                    Icon(
                      imageVector = if (selectedTab == 2) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                      contentDescription = "Favorilerim",
                      tint = if (selectedTab == 2) BrandOrange else TextSecondary
                    )
                  }
                },
                label = {
                  Text(
                    "Favorilerim",
                    fontSize = 10.sp,
                    fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Medium,
                    color = if (selectedTab == 2) BrandOrange else TextSecondary
                  )
                },
                colors = NavigationBarItemDefaults.colors(indicatorColor = DarkSlateCard)
              )

              // Tab 3: AI Asistan
              NavigationBarItem(
                selected = selectedTab == 3,
                onClick = { selectedTab = 3 },
                icon = {
                  Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI Danışman",
                    tint = if (selectedTab == 3) Color(0xFF818CF8) else TextSecondary
                  )
                },
                label = {
                  Text(
                    "AI Asistan",
                    fontSize = 10.sp,
                    fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Medium,
                    color = if (selectedTab == 3) Color(0xFF818CF8) else TextSecondary
                  )
                },
                colors = NavigationBarItemDefaults.colors(indicatorColor = DarkSlateCard)
              )

              // Tab 4: Search
              NavigationBarItem(
                selected = selectedTab == 4,
                onClick = { selectedTab = 4 },
                icon = {
                  Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Ara",
                    tint = if (selectedTab == 4) BrandOrange else TextSecondary
                  )
                },
                label = {
                  Text(
                    "Ara",
                    fontSize = 10.sp,
                    fontWeight = if (selectedTab == 4) FontWeight.Bold else FontWeight.Medium,
                    color = if (selectedTab == 4) BrandOrange else TextSecondary
                  )
                },
                colors = NavigationBarItemDefaults.colors(indicatorColor = DarkSlateCard)
              )
            }
          }
        },
        containerColor = DarkSlateBg
      ) { innerPadding ->
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
        ) {
          when (selectedTab) {
            0 -> {
              HomeScreen(
                foods = foods,
                currentBudget = currentBudget,
                selectedLocation = selectedLocation,
                userLocationState = userLocationState,
                onRequestLocationPermission = handleLocationRequest,
                onBudgetChange = { currentBudget = it },
                onLocationChange = { loc ->
                  selectedLocation = loc
                  val (lat, lon) = when (loc) {
                    "Kadıköy Moda" -> 40.9880 to 29.0250
                    "Kadıköy Rıhtım & Çarşı" -> 40.9920 to 29.0240
                    "Kadıköy Boğa Meydanı" -> 40.9905 to 29.0289
                    "Beşiktaş Çarşı" -> 41.0425 to 29.0065
                    "Üsküdar İskele" -> 41.0250 to 29.0150
                    else -> 40.9880 to 29.0250
                  }
                  userLocationState = userLocationState.copy(latitude = lat, longitude = lon, locationName = loc)
                  foods = MockDataProvider.recalculateDistances(foods, lat, lon)
                },
                onFindBestClick = { selectedTab = 1 },
                onFoodSelected = { activeDetailFood = it },
                onOpenMapClick = { selectedTab = 1 },
                onOpenAiClick = { selectedTab = 3 },
                favoriteIds = favoriteIds,
                onToggleFavorite = handleToggleFavorite
              )
            }
            1 -> {
              FpMapView(
                foods = foods,
                currentBudget = currentBudget,
                selectedFood = mapSelectedFood,
                onFoodSelected = { mapSelectedFood = it },
                onOpenDishDetail = { activeDetailFood = it }
              )
            }
            2 -> {
              FavoritesScreen(
                favoriteFoods = favoriteFoods,
                onFoodSelected = { activeDetailFood = it },
                onRemoveFavorite = { food ->
                  coroutineScope.launch {
                    favoritesRepository.removeFavorite(food.id)
                    Toast.makeText(context, "Favorilerden kaldırıldı", Toast.LENGTH_SHORT).show()
                  }
                },
                onClearAll = {
                  coroutineScope.launch {
                    favoritesRepository.clearAllFavorites()
                    Toast.makeText(context, "Tüm favoriler silindi", Toast.LENGTH_SHORT).show()
                  }
                },
                onExploreClick = { selectedTab = 0 }
              )
            }
            3 -> {
              AiAdvisorScreen(
                foods = foods,
                currentBudget = currentBudget,
                userLocation = selectedLocation,
                onFoodSelected = { activeDetailFood = it }
              )
            }
            4 -> {
              SearchFilterScreen(
                foods = foods,
                currentBudget = currentBudget,
                onFoodSelected = { activeDetailFood = it },
                favoriteIds = favoriteIds,
                onToggleFavorite = handleToggleFavorite
              )
            }
            5 -> {
              FlutterCodeGuideScreen()
            }
          }
        }
      }
    }
  }
}
