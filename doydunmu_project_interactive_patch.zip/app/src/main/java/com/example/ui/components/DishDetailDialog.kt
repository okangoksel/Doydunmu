package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FoodItem
import com.example.data.ReviewItem
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DishDetailScreen(
  food: FoodItem,
  reviews: List<ReviewItem>,
  onBack: () -> Unit,
  onAddReview: (FoodItem) -> Unit,
  modifier: Modifier = Modifier,
  isFavorite: Boolean = false,
  onToggleFavorite: (() -> Unit)? = null
) {
  val foodReviews = reviews.filter { it.foodId == food.id }
  val worthItPct = food.worthItPercentage
  val notWorthItPct = 100 - worthItPct

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(food.dishName, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(food.restaurantName, fontSize = 12.sp, color = TextSecondary)
          }
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Geri", tint = TextPrimary)
          }
        },
        actions = {
          if (onToggleFavorite != null) {
            IconButton(onClick = onToggleFavorite) {
              Icon(
                imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (isFavorite) "Favorilerden Çıkar" else "Favorilere Ekle",
                tint = if (isFavorite) BrandOrange else TextSecondary
              )
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = DarkSlateSurface
        )
      )
    },
    bottomBar = {
      Surface(
        color = DarkSlateSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Porsiyon Fiyatı", fontSize = 11.sp, color = TextSecondary)
            Text("${food.price} TL", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = BrandOrange)
          }

          Button(
            onClick = { onAddReview(food) },
            colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Yorum & Fiş Ekle (+50 Puan)", fontWeight = FontWeight.Bold)
          }
        }
      }
    },
    containerColor = DarkSlateBg
  ) { paddingValues ->
    LazyColumn(
      modifier = modifier
        .fillMaxSize()
        .padding(paddingValues),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Dish Big Photo
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, DarkSlateBorder, RoundedCornerShape(20.dp))
        ) {
          Image(
            painter = painterResource(id = food.imageRes),
            contentDescription = food.dishName,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
          )

          // Verified date stamp on image
          Surface(
            color = Color.Black.copy(alpha = 0.75f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .align(Alignment.BottomStart)
              .padding(12.dp)
          ) {
            Text(
              text = "📍 ${food.neighborhood} · ${food.lastVerifiedDate}",
              color = Color.White,
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }

      // DEVASA F/P METRESİ: "%88 DEĞER" vs "%12 DEĞMEZ"
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
          shape = RoundedCornerShape(18.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Text(
              text = "⚡ GERÇEK FİYAT / PERFORMANS METRESİ",
              fontSize = 11.sp,
              fontWeight = FontWeight.ExtraBold,
              color = FpGold,
              letterSpacing = 1.sp
            )

            // Huge Percentage Split Bar
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Icon(Icons.Default.ThumbUp, contentDescription = null, tint = FpGreen, modifier = Modifier.size(20.dp))
                Text(
                  text = "%$worthItPct DEĞER",
                  fontSize = 20.sp,
                  fontWeight = FontWeight.Black,
                  color = FpGreen
                )
                Text("(${food.positiveVotes} Oy)", fontSize = 11.sp, color = TextSecondary)
              }

              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Text("(${food.negativeVotes} Oy)", fontSize = 11.sp, color = TextSecondary)
                Text(
                  text = "%$notWorthItPct DEĞMEZ",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                  color = FpRed
                )
                Icon(Icons.Default.ThumbDown, contentDescription = null, tint = FpRed, modifier = Modifier.size(18.dp))
              }
            }

            // Visual Progress Meter Bar
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .height(14.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(DarkSlateSurface)
            ) {
              Box(
                modifier = Modifier
                  .weight(worthItPct.toFloat().coerceAtLeast(1f))
                  .fillMaxHeight()
                  .background(FpGreen)
              )
              Box(
                modifier = Modifier
                  .weight(notWorthItPct.toFloat().coerceAtLeast(1f))
                  .fillMaxHeight()
                  .background(FpRed)
              )
            }

            // Breakdown stats row
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceAround
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Lezzet Puanı", fontSize = 11.sp, color = TextSecondary)
                Text("★ ${food.tasteRating} / 5", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = FpGold)
              }
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Doyuruculuk", fontSize = 11.sp, color = TextSecondary)
                Text("%${food.satietyScore}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = FpGreen)
              }
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Gramaj / Fiyat", fontSize = 11.sp, color = TextSecondary)
                Text(if (food.isTrap) "Düşük ⚠️" else "Çok İyi 🔥", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (food.isTrap) FpRed else FpGreen)
              }
            }
          }
        }
      }

      // SİSTEM HAKİKAT ÖZETİ (Yapay Zeka & Topluluk Raporu)
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = if (food.isTrap) FpRedBg.copy(alpha = 0.35f) else Color(0xFF1E293B)),
          shape = RoundedCornerShape(16.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, if (food.isTrap) FpRed else Color(0xFF334155))
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = if (food.isTrap) FpRed else BrandOrange,
                modifier = Modifier.size(16.dp)
              )
              Text(
                text = "SİSTEM HAKİKAT RAPORU",
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (food.isTrap) Color(0xFFFF8A80) else BrandOrange,
                letterSpacing = 0.5.sp
              )
            }

            Text(
              text = food.systemSummary,
              fontSize = 13.sp,
              color = Color.White,
              lineHeight = 18.sp,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }

      // FİŞ & TOPLULUK İNCELEMELERİ BAŞLIĞI
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Masadan Fişli İncelemeler (${foodReviews.size})",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )

          Surface(
            color = DarkSlateCard,
            shape = RoundedCornerShape(8.dp)
          ) {
            Text(
              text = "🛡️ Doğrulanmış Fişler",
              color = FpGold,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }

      // İnceleme Listesi
      if (foodReviews.isEmpty()) {
        item {
          Card(
            colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Text("Bu yemek için henüz fiş eklenmemiş.", color = TextSecondary, fontSize = 13.sp)
              Text("İlk fişi sen ekle, +50 Güven Puanı ve Altın Rozet kazan!", color = FpGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      } else {
        items(foodReviews) { review ->
          ReviewCard(review = review)
        }
      }
    }
  }
}

@Composable
fun ReviewCard(review: ReviewItem) {
  Card(
    colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
    shape = RoundedCornerShape(14.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Text(review.userName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
            Text(review.userBadge, fontSize = 11.sp, color = FpGold)
          }
          Text(review.timeAgo, fontSize = 10.sp, color = TextMuted)
        }

        Surface(
          color = if (review.isWorthIt) FpGreenBg else FpRedBg,
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            text = if (review.isWorthIt) "✓ Değer Buldu" else "✗ Değmez Dedi",
            color = if (review.isWorthIt) FpGreen else Color(0xFFFF8A80),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
          )
        }
      }

      // Review Details Chips
      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Ödenen: ${review.pricePaid} TL", fontSize = 11.sp, color = TextSecondary)
        Text("·", color = TextMuted)
        Text("Lezzet: ★${review.tasteScore}/5", fontSize = 11.sp, color = FpGold)
        Text("·", color = TextMuted)
        Text("Doyuruculuk: ${review.fullnessScore}/5", fontSize = 11.sp, color = FpGreen)
      }

      // Comment
      Text(
        text = review.comment,
        fontSize = 12.sp,
        color = TextPrimary,
        lineHeight = 16.sp
      )

      // Verified receipt marker
      if (review.hasReceipt) {
        Surface(
          color = DarkSlateSurface,
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(Icons.Default.Receipt, contentDescription = null, tint = FpGold, modifier = Modifier.size(13.dp))
            Text(
              text = "Restoran Kasa Fişi Doğrulandı (Kullanıcı Güven Skoru: 9.8/10)",
              fontSize = 10.sp,
              color = FpGold,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }
    }
  }
}
