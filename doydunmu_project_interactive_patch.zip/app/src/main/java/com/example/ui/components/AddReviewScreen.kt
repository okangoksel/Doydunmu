package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FoodItem
import com.example.data.ReviewItem
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddReviewScreen(
  food: FoodItem,
  onBack: () -> Unit,
  onSubmitReview: (ReviewItem, Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  var pricePaidText by remember { mutableStateOf(food.price.toString()) }
  var tasteScore by remember { mutableStateOf(5f) }
  var fullnessScore by remember { mutableStateOf(5f) }
  var isWorthIt by remember { mutableStateOf<Boolean?>(true) }
  var commentText by remember { mutableStateOf("") }
  var hasReceiptAttached by remember { mutableStateOf(true) }
  var isSuccessSubmitted by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text("3 Saniyelik F/P Değerlendirmesi", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(food.dishName, fontSize = 12.sp, color = TextSecondary)
          }
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Geri", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSlateSurface)
      )
    },
    containerColor = DarkSlateBg
  ) { paddingValues ->
    if (isSuccessSubmitted) {
      // Success Celebration Screen
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues),
        contentAlignment = Alignment.Center
      ) {
        Card(
          colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
          shape = RoundedCornerShape(24.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, FpGold),
          modifier = Modifier.padding(24.dp)
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = FpGold,
              modifier = Modifier.size(56.dp)
            )

            Text(
              text = "🎉 TEBRİKLER!",
              fontSize = 20.sp,
              fontWeight = FontWeight.Black,
              color = Color.White
            )

            Text(
              text = "Masadan gerçek fiş yüklediğin için +50 Kullanıcı Güven Skoru ve 'Altın Denetçi' Rozeti kazandın!",
              fontSize = 13.sp,
              color = TextSecondary,
              textAlign = androidx.compose.ui.text.style.TextAlign.Center,
              lineHeight = 18.sp
            )

            Surface(
              color = FpGold.copy(alpha = 0.2f),
              shape = RoundedCornerShape(12.dp)
            ) {
              Text(
                text = "🎖️ Yeni Seviye: Altın F/P Denetçisi",
                color = FpGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
              )
            }

            Button(
              onClick = onBack,
              colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("Yemek Sayfasına Dön", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    } else {
      Column(
        modifier = modifier
          .fillMaxSize()
          .padding(paddingValues)
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // Altın Rozet & Fiş Teşvik Banner'ı
        Card(
          colors = CardDefaults.cardColors(containerColor = Color(0xFF291E0D)),
          shape = RoundedCornerShape(16.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, FpGold)
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Icon(Icons.Default.Receipt, contentDescription = null, tint = FpGold, modifier = Modifier.size(32.dp))
            Column {
              Text("Masadan Fişini Göster, Altın Rozet Kazan!", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FpGold)
              Text("Fiş yükleyen kullanıcıların puanları 10 kat daha fazla etki eder.", fontSize = 11.sp, color = Color(0xFFFFD54F))
            }
          }
        }

        // Fiş / Fotoğraf Ekleme Bölümü
        Card(
          colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
          shape = RoundedCornerShape(16.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Text("1. Masadan Fiş & Yemek Fotoğrafı", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              // Fiş Kutusu
              Box(
                modifier = Modifier
                  .weight(1f)
                  .height(80.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(if (hasReceiptAttached) Color(0xFF1E3A2F) else DarkSlateSurface)
                  .border(
                    width = 1.dp,
                    color = if (hasReceiptAttached) FpGreen else DarkSlateBorder,
                    shape = RoundedCornerShape(12.dp)
                  )
                  .clickable { hasReceiptAttached = !hasReceiptAttached },
                contentAlignment = Alignment.Center
              ) {
                Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                  Icon(
                    imageVector = if (hasReceiptAttached) Icons.Default.Check else Icons.Default.Receipt,
                    contentDescription = null,
                    tint = if (hasReceiptAttached) FpGreen else TextSecondary,
                    modifier = Modifier.size(20.dp)
                  )
                  Text(
                    text = if (hasReceiptAttached) "✓ Fiş Eklendi" else "+ Fiş Fotoğrafı",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (hasReceiptAttached) FpGreen else TextSecondary
                  )
                }
              }

              // Yemek Fotoğrafı Kutusu
              Box(
                modifier = Modifier
                  .weight(1f)
                  .height(80.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(Color(0xFF1E3A2F))
                  .border(1.dp, FpGreen, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
              ) {
                Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                  Icon(Icons.Default.Check, contentDescription = null, tint = FpGreen, modifier = Modifier.size(20.dp))
                  Text("✓ Porsiyon Görseli", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FpGreen)
                }
              }
            }
          }
        }

        // Ödenen Net Tutar Girişi
        Card(
          colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
          shape = RoundedCornerShape(16.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Text("2. Ne Kadar Ödedin? (Net Tutar)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

            OutlinedTextField(
              value = pricePaidText,
              onValueChange = { pricePaidText = it },
              modifier = Modifier.fillMaxWidth(),
              trailingIcon = { Text("TL", color = BrandOrange, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 12.dp)) },
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandOrange,
                unfocusedBorderColor = DarkSlateBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
              ),
              shape = RoundedCornerShape(12.dp),
              singleLine = true
            )
          }
        }

        // 3 Saniyelik Hızlı Sliderlar (Lezzet & Doyuruculuk)
        Card(
          colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
          shape = RoundedCornerShape(16.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            Text("3. Hızlı Puanlama (1 - 5)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

            // Lezzet Slider
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("Lezzet: ★ ${tasteScore.toInt()} / 5", fontSize = 12.sp, color = FpGold, fontWeight = FontWeight.Bold)
                Text(if (tasteScore >= 4f) "Çok Lezzetli" else "Vasat", fontSize = 11.sp, color = TextSecondary)
              }
              Slider(
                value = tasteScore,
                onValueChange = { tasteScore = it },
                valueRange = 1f..5f,
                steps = 3,
                colors = SliderDefaults.colors(
                  thumbColor = FpGold,
                  activeTrackColor = FpGold,
                  inactiveTrackColor = DarkSlateBorder
                )
              )
            }

            // Doyuruculuk Slider
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("Doyuruculuk: ${fullnessScore.toInt()} / 5", fontSize = 12.sp, color = FpGreen, fontWeight = FontWeight.Bold)
                Text(if (fullnessScore >= 4f) "Tıka Basa Doyurdu" else "Aç Kaldım", fontSize = 11.sp, color = TextSecondary)
              }
              Slider(
                value = fullnessScore,
                onValueChange = { fullnessScore = it },
                valueRange = 1f..5f,
                steps = 3,
                colors = SliderDefaults.colors(
                  thumbColor = FpGreen,
                  activeTrackColor = FpGreen,
                  inactiveTrackColor = DarkSlateBorder
                )
              )
            }
          }
        }

        // İKİLİ KARAR BUTONU: "BU PARAYA DEĞER Mİ?"
        Card(
          colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
          shape = RoundedCornerShape(16.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Text("4. Son Kararın: Bu Paraya Değer mi?", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              // EVET - DEĞER
              Button(
                onClick = { isWorthIt = true },
                modifier = Modifier.weight(1f).height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = if (isWorthIt == true) FpGreen else DarkSlateSurface
                ),
                border = if (isWorthIt == true) null else androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
              ) {
                Icon(Icons.Default.ThumbUp, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("EVET, DEĞER", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
              }

              // HAYIR - DEĞMEZ
              Button(
                onClick = { isWorthIt = false },
                modifier = Modifier.weight(1f).height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = if (isWorthIt == false) FpRed else DarkSlateSurface
                ),
                border = if (isWorthIt == false) null else androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
              ) {
                Icon(Icons.Default.ThumbDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("HAYIR, TUZAK", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
              }
            }
          }
        }

        // Yorum Metni
        OutlinedTextField(
          value = commentText,
          onValueChange = { commentText = it },
          placeholder = { Text("Diğer kullanıcılar için 1 cümlelik tüyo bırak (Örn: Lavaşını çift isteyin)...", color = TextMuted, fontSize = 12.sp) },
          modifier = Modifier.fillMaxWidth().height(100.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BrandOrange,
            unfocusedBorderColor = DarkSlateBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          shape = RoundedCornerShape(12.dp)
        )

        // Gönder Butonu
        Button(
          onClick = {
            val paid = pricePaidText.toIntOrNull() ?: food.price
            val comment = if (commentText.isBlank()) "Fiyat/performans açısından değerlendirildi." else commentText
            val newReview = ReviewItem(
              id = "rev_${System.currentTimeMillis()}",
              foodId = food.id,
              userName = "Sen (Altın Denetçi)",
              userBadge = if (hasReceiptAttached) "Altın Denetçi 🎖️" else "F/P Avcısı 🔥",
              hasReceipt = hasReceiptAttached,
              pricePaid = paid,
              tasteScore = tasteScore.toInt(),
              fullnessScore = fullnessScore.toInt(),
              isWorthIt = isWorthIt ?: true,
              comment = comment,
              timeAgo = "Az önce"
            )
            onSubmitReview(newReview, isWorthIt ?: true)
            isSuccessSubmitted = true
          },
          colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
          Icon(Icons.Default.CheckCircle, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Değerlendirmeyi Yayınla (+50 Puan)", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        }
      }
    }
  }
}
