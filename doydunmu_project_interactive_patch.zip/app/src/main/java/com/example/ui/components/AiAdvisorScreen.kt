package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AiReceiptAuditResult
import com.example.ai.AiRecommendationResult
import com.example.ai.AiService
import com.example.data.FoodItem
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AiAdvisorScreen(
  foods: List<FoodItem>,
  currentBudget: Int,
  userLocation: String,
  onFoodSelected: (FoodItem) -> Unit,
  modifier: Modifier = Modifier
) {
  val aiService = remember { AiService() }
  val scope = rememberCoroutineScope()

  var selectedAiMode by remember { mutableIntStateOf(0) } // 0: Menü Önerisi, 1: Fiş Denetçisi, 2: Karşılaştırıcı
  val modes = listOf("Bugün Ne Yesem? 🤖", "Fiş Denetçisi 🧾", "Karşılaştırıcı 🥊")

  // State for Mode 0: Recommendation
  var budgetInput by remember { mutableIntStateOf(currentBudget) }
  var hungerLevel by remember { mutableStateOf("Çok Açım") }
  var preference by remember { mutableStateOf("Fark Etmez") }
  var isRecommending by remember { mutableStateOf(false) }
  var recommendationResult by remember { mutableStateOf<AiRecommendationResult?>(null) }

  // State for Mode 1: Receipt Audit
  var auditRestaurant by remember { mutableStateOf("Boğa Meydanı 'Gurme' Döner") }
  var auditDish by remember { mutableStateOf("Et Döner Porsiyon") }
  var auditPrice by remember { mutableStateOf("420") }
  var isAuditing by remember { mutableStateOf(false) }
  var auditResult by remember { mutableStateOf<AiReceiptAuditResult?>(null) }

  // State for Mode 2: Compare
  var compareFoodA by remember { mutableStateOf(foods.getOrNull(0) ?: foods.first()) }
  var compareFoodB by remember { mutableStateOf(foods.getOrNull(4) ?: foods.last()) }
  var compareResult by remember { mutableStateOf<String?>(null) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Hero Banner
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BrandOrange.copy(alpha = 0.4f))
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Surface(
              color = BrandOrange,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.size(32.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
              }
            }
            Column {
              Text("Yemeğini Ye AI Motoru", fontWeight = FontWeight.Black, fontSize = 15.sp, color = TextPrimary)
              Text("Gemini Destekli F/P & Tuzak Analiz Sistemi", fontSize = 11.sp, color = BrandOrangeLight)
            }
          }
          Text(
            "Bütçene göre en doyurucu tabağı seçer, şişirilmiş turist fiyatlarını ve gizli kuver tuzaklarını anında deşifre eder.",
            fontSize = 12.sp,
            color = TextSecondary,
            lineHeight = 16.sp
          )
        }
      }
    }

    // Mode Selector Pills
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        modes.forEachIndexed { index, title ->
          val isSelected = selectedAiMode == index
          Surface(
            color = if (isSelected) BrandOrange else DarkSlateSurface,
            shape = RoundedCornerShape(10.dp),
            border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier
              .weight(1f)
              .clickable { selectedAiMode = index }
          ) {
            Box(
              modifier = Modifier.padding(vertical = 10.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = title,
                color = if (isSelected) Color.White else TextSecondary,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
              )
            }
          }
        }
      }
    }

    // MODE 0: "Bugün Ne Yesem?"
    if (selectedAiMode == 0) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
          shape = RoundedCornerShape(16.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            Text("1. Açlık Seviyen", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              listOf("Çok Açım", "Normal", "Hafif").forEach { level ->
                val isSel = hungerLevel == level
                Surface(
                  color = if (isSel) BrandOrange else DarkSlateCard,
                  shape = RoundedCornerShape(8.dp),
                  border = if (isSel) null else androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                  modifier = Modifier
                    .weight(1f)
                    .clickable { hungerLevel = level }
                ) {
                  Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                    Text(
                      text = level,
                      fontSize = 12.sp,
                      color = if (isSel) Color.White else TextSecondary,
                      fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                    )
                  }
                }
              }
            }

            Text("2. Harcamak İstediğin Bütçe: ${budgetInput} TL", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
            Slider(
              value = budgetInput.toFloat(),
              onValueChange = { budgetInput = it.toInt() },
              valueRange = 80f..450f,
              steps = 7,
              colors = SliderDefaults.colors(
                thumbColor = BrandOrange,
                activeTrackColor = BrandOrange,
                inactiveTrackColor = DarkSlateBorder
              )
            )

            Text("3. Canın Ne Çekiyor?", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              listOf("Fark Etmez", "Dürüm", "Burger", "Lahmacun", "Köfte").forEach { cat ->
                val isSel = preference == cat
                Surface(
                  color = if (isSel) BrandOrange else DarkSlateCard,
                  shape = RoundedCornerShape(8.dp),
                  border = if (isSel) null else androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                  modifier = Modifier.clickable { preference = cat }
                ) {
                  Text(
                    text = cat,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    fontSize = 11.sp,
                    color = if (isSel) Color.White else TextSecondary,
                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                  )
                }
              }
            }

            Button(
              onClick = {
                isRecommending = true
                scope.launch {
                  val result = aiService.getMealRecommendation(
                    budget = budgetInput,
                    hungerLevel = hungerLevel,
                    preference = preference,
                    location = userLocation,
                    foods = foods
                  )
                  recommendationResult = result
                  isRecommending = false
                }
              },
              enabled = !isRecommending,
              colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
            ) {
              if (isRecommending) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("Gemini F/P Motoru Taranıyor...", color = Color.White, fontSize = 13.sp)
              } else {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Bana En Mantıklı Yemeği Bul", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              }
            }
          }
        }
      }

      // Result Card
      item {
        AnimatedVisibility(visible = recommendationResult != null) {
          recommendationResult?.let { res ->
            Card(
              colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
              shape = RoundedCornerShape(16.dp),
              border = androidx.compose.foundation.BorderStroke(1.5.dp, FpGreen)
            ) {
              Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text("🎯 AI ŞAMPİYON TAVSİYESİ", color = FpGreen, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                  Surface(
                    color = FpGreen.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(6.dp)
                  ) {
                    Text(
                      text = "%${res.estimatedSatisfactionPercent} Memnuniyet",
                      color = FpGreen,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                }

                Text(res.title, fontSize = 15.sp, fontWeight = FontWeight.Black, color = TextPrimary)
                Text(res.rationale, fontSize = 12.sp, color = TextSecondary, lineHeight = 16.sp)

                Surface(
                  color = DarkSlateSurface,
                  shape = RoundedCornerShape(10.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("💡 Doyuruculuk Tüyosu:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FpGold)
                    Text(res.satietyTip, fontSize = 11.sp, color = TextSecondary)
                  }
                }

                Surface(
                  color = FpRedBg.copy(alpha = 0.3f),
                  shape = RoundedCornerShape(10.dp),
                  border = androidx.compose.foundation.BorderStroke(1.dp, FpRed.copy(alpha = 0.4f)),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("⚠️ Tuzak Koruması Uyarısı:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FpRed)
                    Text(res.trapWarning, fontSize = 11.sp, color = Color(0xFFFF8A80))
                  }
                }

                res.bestDish?.let { dish ->
                  Button(
                    onClick = { onFoodSelected(dish) },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSlateSurface),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text("Mekan Detayını & Menüyü Aç →", color = BrandOrange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }
        }
      }
    }

    // MODE 1: Fiş & Adisyon Denetçisi
    if (selectedAiMode == 1) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
          shape = RoundedCornerShape(16.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Text("Adisyon & Fiş Bilgisi", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("Ödediğin veya ödeyeceğin adisyonun Kadıköy piyasa standartlarına ve fiş doğrulamalarına uygunluğunu denetle.", fontSize = 11.sp, color = TextMuted)

            // Hızlı Deneme Butonları
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Surface(
                color = DarkSlateCard,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.clickable {
                  auditRestaurant = "Boğa Meydanı 'Gurme' Döner"
                  auditDish = "Et Döner Porsiyon (110gr)"
                  auditPrice = "420"
                }
              ) {
                Text("Örnek: Tuzak Döner (420 TL)", fontSize = 10.sp, color = FpRed, modifier = Modifier.padding(6.dp))
              }

              Surface(
                color = DarkSlateCard,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.clickable {
                  auditRestaurant = "Hatay Dürüm Dünyası"
                  auditDish = "70cm Zurna Menü"
                  auditPrice = "180"
                }
              ) {
                Text("Örnek: Adil Fiş (180 TL)", fontSize = 10.sp, color = FpGreen, modifier = Modifier.padding(6.dp))
              }
            }

            OutlinedTextField(
              value = auditRestaurant,
              onValueChange = { auditRestaurant = it },
              label = { Text("Mekan Adı", fontSize = 11.sp) },
              modifier = Modifier.fillMaxWidth(),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandOrange,
                unfocusedBorderColor = DarkSlateBorder,
                focusedContainerColor = DarkSlateCard,
                unfocusedContainerColor = DarkSlateCard
              ),
              shape = RoundedCornerShape(10.dp)
            )

            OutlinedTextField(
              value = auditDish,
              onValueChange = { auditDish = it },
              label = { Text("Yenen Yemek / Ürün", fontSize = 11.sp) },
              modifier = Modifier.fillMaxWidth(),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandOrange,
                unfocusedBorderColor = DarkSlateBorder,
                focusedContainerColor = DarkSlateCard,
                unfocusedContainerColor = DarkSlateCard
              ),
              shape = RoundedCornerShape(10.dp)
            )

            OutlinedTextField(
              value = auditPrice,
              onValueChange = { auditPrice = it },
              label = { Text("Toplam Ödenen Tutar (TL)", fontSize = 11.sp) },
              modifier = Modifier.fillMaxWidth(),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandOrange,
                unfocusedBorderColor = DarkSlateBorder,
                focusedContainerColor = DarkSlateCard,
                unfocusedContainerColor = DarkSlateCard
              ),
              shape = RoundedCornerShape(10.dp)
            )

            Button(
              onClick = {
                isAuditing = true
                scope.launch {
                  val priceInt = auditPrice.toIntOrNull() ?: 200
                  val res = aiService.auditReceipt(
                    restaurantName = auditRestaurant,
                    dishName = auditDish,
                    pricePaid = priceInt,
                    knownFoods = foods
                  )
                  auditResult = res
                  isAuditing = false
                }
              },
              enabled = !isAuditing,
              colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
            ) {
              if (isAuditing) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
              } else {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Adisyonu AI ile Denetle", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              }
            }
          }
        }
      }

      // Audit Result
      item {
        AnimatedVisibility(visible = auditResult != null) {
          auditResult?.let { audit ->
            val isTrap = !audit.isFairPrice
            Card(
              colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
              shape = RoundedCornerShape(16.dp),
              border = androidx.compose.foundation.BorderStroke(1.5.dp, if (isTrap) FpRed else FpGreen)
            ) {
              Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(audit.verdict, color = if (isTrap) FpRed else FpGreen, fontWeight = FontWeight.Black, fontSize = 13.sp)
                  Surface(
                    color = (if (isTrap) FpRed else FpGreen).copy(alpha = 0.2f),
                    shape = RoundedCornerShape(6.dp)
                  ) {
                    Text(
                      text = "%${audit.fpScore} F/P Skoru",
                      color = if (isTrap) FpRed else FpGreen,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                }

                Text(
                  text = "Tahmini Adil Değer: ${audit.estimatedFairPrice} TL",
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )

                if (audit.fraudAlerts.isNotEmpty()) {
                  Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    audit.fraudAlerts.forEach { alert ->
                      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("•", color = FpRed, fontWeight = FontWeight.Bold)
                        Text(alert, fontSize = 11.sp, color = Color(0xFFFF8A80), lineHeight = 15.sp)
                      }
                    }
                  }
                }

                Text("Tavsiye: " + audit.advice, fontSize = 11.sp, color = TextSecondary)
              }
            }
          }
        }
      }
    }

    // MODE 2: Karşılaştırıcı
    if (selectedAiMode == 2) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
          shape = RoundedCornerShape(16.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Text("İki Yemeği Kıyasla", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("Hangi tabak 1 TL başına daha fazla gramaj ve tokluk sunuyor?", fontSize = 11.sp, color = TextMuted)

            // Select Food A
            Text("1. Tabak: ${compareFoodA.dishName} (${compareFoodA.price} TL)", fontSize = 11.sp, color = BrandOrange, fontWeight = FontWeight.Bold)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              foods.take(3).forEach { f ->
                Surface(
                  color = if (compareFoodA.id == f.id) BrandOrange else DarkSlateCard,
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.clickable { compareFoodA = f }
                ) {
                  Text(f.dishName.take(16) + "...", fontSize = 10.sp, color = Color.White, modifier = Modifier.padding(6.dp))
                }
              }
            }

            // Select Food B
            Text("2. Tabak: ${compareFoodB.dishName} (${compareFoodB.price} TL)", fontSize = 11.sp, color = FpGold, fontWeight = FontWeight.Bold)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              foods.drop(3).take(3).forEach { f ->
                Surface(
                  color = if (compareFoodB.id == f.id) FpGold else DarkSlateCard,
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.clickable { compareFoodB = f }
                ) {
                  Text(f.dishName.take(16) + "...", fontSize = 10.sp, color = Color.White, modifier = Modifier.padding(6.dp))
                }
              }
            }

            Button(
              onClick = {
                compareResult = aiService.compareDishes(compareFoodA, compareFoodB)
              },
              colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
            ) {
              Icon(Icons.Default.CompareArrows, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
              Spacer(Modifier.width(8.dp))
              Text("F/P Kıyaslamasını Çalıştır", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
          }
        }
      }

      item {
        AnimatedVisibility(visible = compareResult != null) {
          compareResult?.let { res ->
            Card(
              colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
              shape = RoundedCornerShape(16.dp),
              border = androidx.compose.foundation.BorderStroke(1.5.dp, FpGold)
            ) {
              Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Text(res, fontSize = 12.sp, color = TextPrimary, lineHeight = 18.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
              }
            }
          }
        }
      }
    }
  }
}
