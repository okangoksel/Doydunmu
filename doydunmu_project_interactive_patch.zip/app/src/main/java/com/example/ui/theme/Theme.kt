package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = BrandOrange,
    onPrimary = TextPrimary,
    primaryContainer = BrandOrangeDark,
    onPrimaryContainer = TextPrimary,
    secondary = FpGreen,
    onSecondary = TextPrimary,
    tertiary = FpGold,
    background = DarkSlateBg,
    onBackground = TextPrimary,
    surface = DarkSlateSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSlateCard,
    onSurfaceVariant = TextSecondary,
    outline = DarkSlateBorder,
    error = FpRed,
    onError = TextPrimary,
  )

private val LightColorScheme = DarkColorScheme // Modern dark slate interface as specified in prompt

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(colorScheme = DarkColorScheme, typography = Typography, content = content)
}
