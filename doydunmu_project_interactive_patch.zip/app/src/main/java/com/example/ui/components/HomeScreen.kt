package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FoodItem
import com.example.location.PlayServicesLocationHelper
import com.example.location.UserLocationState
import com.example.ui.theme.*

@Composable
fun HomeScreen(
  foods: List<FoodItem>,
  currentBudget: Int,
  selectedLocation: String,
  userLocationState: UserLocationState,
  onRequestLocationPermission: () -> Unit,
  onBudgetChange: (Int) -> Unit,
  onLocationChange: (String) -> Unit,
  onFindBestClick: () -> Unit,
  onFoodSelected: (FoodItem) -> Unit,
  onOpenMapClick: () -> Unit,
  onOpenAiClick: () -> Unit,
  modifier: Modifier = Modifier,
  favoriteIds: Set<String> = emptySet(),
  onToggleFavorite: ((FoodItem) -> Unit)? = null
) {
  var showLocationPicker by remember { mutableStateOf(false) }
  val locationList = listOf(
    "Kadıköy Moda",
    "Kadıköy Rıhtım & Çarşı",
    "Kadıköy Boğa Meydanı",
    "Beşiktaş Çarşı",
    "Üsküdar İskele",
    "Beyoğlu Taksim"
  )

  // Budget quick amounts
  val quickBudgets = listOf(100, 150, 200, 300, 500)

  // Filter foods by budget and value
  val budgetChampions = foods.filter { it.price <= currentBudget && !it.isTrap }

  // Closest restaurants sorted by distance
  val nearestFoods = foods.filter { !it.isTrap && it.price <= currentBudget }
    .sortedBy { it.distanceMeters }
    .take(3)

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. PLAY SERVICES LOCATION & GPS STATUS CARD
    item {
      Card(
        colors = CardDefaults.cardColors(
          containerColor = if (userLocationState.isLiveLocation) DarkSlateSurface else DarkSlateCard
        ),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
          width = 1.dp,
          color = if (userLocationState.isLiveLocation) FpGreen.copy(alpha = 0.5f) else BrandOrange.copy(alpha = 0.4f)
        )
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Surface(
                color = if (userLocationState.isLiveLocation) FpGreen else BrandOrange,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(32.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = if (userLocationState.isLiveLocation) Icons.Default.GpsFixed else Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                  )
                }
              }

              Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  Text(
                    text = if (userLocationState.isLiveLocation) "Canlı Konum (Play Services)" else "Mevcut Konum",
                    fontSize = 11.sp,
                    color = if (userLocationState.isLiveLocation) FpGreen else TextMuted,
                    fontWeight = FontWeight.Bold
                  )
                  if (userLocationState.isLiveLocation) {
                    Surface(
                      color = FpGreen.copy(alpha = 0.2f),
                      shape = RoundedCornerShape(4.dp)
                    ) {
                      Text(
                        "🛰️ GPS AKTİF",
                        color = FpGreen,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                      )
                    }
                  }
                }
                Text(
                  text = userLocationState.locationName,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Black,
                  color = TextPrimary
                )
              }
            }

            // Quick button: Request Location / Refresh GPS
            Surface(
              color = if (userLocationState.isLiveLocation) DarkSlateCard else BrandOrange,
              shape = RoundedCornerShape(8.dp),
              border = if (userLocationState.isLiveLocation) androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder) else null,
              modifier = Modifier.clickable { onRequestLocationPermission() }
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(
                  imageVector = if (userLocationState.isLiveLocation) Icons.Default.Refresh else Icons.Default.MyLocation,
                  contentDescription = null,
                  tint = if (userLocationState.isLiveLocation) FpGreen else Color.White,
                  modifier = Modifier.size(13.dp)
                )
                Text(
                  text = if (userLocationState.isLiveLocation) "Yenile" else "GPS'i Aç",
                  color = if (userLocationState.isLiveLocation) FpGreen else Color.White,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          // If location not yet requested or fallback
          if (!userLocationState.isLiveLocation) {
            Surface(
              color = DarkSlateSurface,
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Yakındaki restoranları mesafe sırasına göre görmek için konum izni verin.",
                  fontSize = 11.sp,
                  color = TextSecondary,
                  modifier = Modifier.weight(1f),
                  lineHeight = 15.sp
                )
                Spacer(Modifier.width(8.dp))
                Button(
                  onClick = onRequestLocationPermission,
                  colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                  shape = RoundedCornerShape(8.dp),
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                  modifier = Modifier.height(32.dp)
                ) {
                  Text("İzin Ver", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
              }
            }
          }

          // Manual region selector toggle
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { showLocationPicker = !showLocationPicker },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Bölgeyi manuel değiştirmek için tıkla",
              fontSize = 11.sp,
              color = BrandOrangeLight
            )
            Icon(
              imageVector = if (showLocationPicker) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
              contentDescription = null,
              tint = BrandOrangeLight,
              modifier = Modifier.size(16.dp)
            )
          }

          if (showLocationPicker) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
              verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              HorizontalDivider(color = DarkSlateBorder)
              locationList.forEach { loc ->
                Text(
                  text = "📍 $loc",
                  color = if (loc == selectedLocation) BrandOrange else TextSecondary,
                  fontSize = 12.sp,
                  fontWeight = if (loc == selectedLocation) FontWeight.Bold else FontWeight.Normal,
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      onLocationChange(loc)
                      showLocationPicker = false
                    }
                    .padding(vertical = 6.dp)
                )
              }
            }
          }
        }
      }
    }

    // 2. YAPAY ZEKA HIZLI ERİŞİM KARTI (GEMINI AI PROMPT BANNER)
    item {
      Surface(
        color = Color(0xFF1E1B4B).copy(alpha = 0.6f),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF6366F1).copy(alpha = 0.4f)),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onOpenAiClick() }
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Surface(
              color = Color(0xFF4F46E5),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.size(36.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
              }
            }

            Column {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Gemini F/P Danışmanı", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Surface(
                  color = Color(0xFF818CF8).copy(alpha = 0.3f),
                  shape = RoundedCornerShape(4.dp)
                ) {
                  Text("YAPAY ZEKA", color = Color(0xFFA5B4FC), fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                }
              }
              Text("${currentBudget} TL ile kararsız mısın? Yapay zeka senin için seçsin.", fontSize = 11.sp, color = Color(0xFFC7D2FE))
            }
          }

          Text("Danış →", color = Color(0xFFA5B4FC), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // 3. BÜTÇE KAYDIRICISI (BUDGET SLIDER HERO CARD)
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, BrandOrange.copy(alpha = 0.5f))
      ) {
        Column(
          modifier = Modifier.padding(18.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "CEBİNDEKİ BÜTÇE",
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                color = BrandOrangeLight,
                letterSpacing = 1.sp
              )
              Text(
                text = "Ne kadar harcamak istiyorsun?",
                fontSize = 12.sp,
                color = TextSecondary
              )
            }

            Surface(
              color = BrandOrange,
              shape = RoundedCornerShape(12.dp)
            ) {
              Text(
                text = "${currentBudget} TL",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
              )
            }
          }

          // Slider
          Slider(
            value = currentBudget.toFloat(),
            onValueChange = { onBudgetChange(it.toInt()) },
            valueRange = 50f..500f,
            steps = 8,
            colors = SliderDefaults.colors(
              thumbColor = BrandOrange,
              activeTrackColor = BrandOrange,
              inactiveTrackColor = DarkSlateBorder
            )
          )

          // Quick Budget Chips
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            quickBudgets.forEach { budgetVal ->
              val isSelected = currentBudget == budgetVal
              Surface(
                color = if (isSelected) BrandOrange else DarkSlateSurface,
                shape = RoundedCornerShape(8.dp),
                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.clickable { onBudgetChange(budgetVal) }
              ) {
                Text(
                  text = "${budgetVal} TL",
                  color = if (isSelected) Color.White else TextSecondary,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                )
              }
            }
          }

          // "EN İYİSİNİ BUL" BUTONU (PRIMARY CTA)
          Button(
            onClick = onFindBestClick,
            colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp)
          ) {
            Text(
              text = "${currentBudget} TL İle En İyisini Bul 🔥",
              fontWeight = FontWeight.Black,
              fontSize = 14.sp,
              color = Color.White
            )
          }
        }
      }
    }

    // 4. KONUMA GÖRE EN YAKIN RESTORANLAR (LOCATION-BASED SUGGESTIONS)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = FpGreen, modifier = Modifier.size(18.dp))
          Text(
            text = "Yürüme Mesafesindeki En Yakınlar",
            fontSize = 15.sp,
            fontWeight = FontWeight.ExtraBold,
            color = TextPrimary
          )
        }

        Surface(
          color = FpGreen.copy(alpha = 0.2f),
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            text = "Yürüyerek 1-7 dk",
            fontSize = 10.sp,
            color = FpGreen,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
          )
        }
      }
    }

    items(nearestFoods) { food ->
      FoodCard(
        item = food,
        isFavorite = favoriteIds.contains(food.id),
        onCardClick = { onFoodSelected(food) },
        onToggleFavorite = { onToggleFavorite?.invoke(food) }
      )
    }

    // Harita Hızlı Erişim Banner'ı
    item {
      Surface(
        color = Color(0xFF1E293B),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onOpenMapClick() }
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Icon(Icons.Default.Map, contentDescription = null, tint = FpGreen, modifier = Modifier.size(24.dp))
            Column {
              Text("İnteraktif F/P Haritası", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
              Text("Kadıköy'deki yeşil F/P pinlerini ve kırmızı tuzakları gör", fontSize = 11.sp, color = Color(0xFF94A3B8))
            }
          }

          Text("Haritayı Aç →", color = FpGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // 5. GÜNÜN F/P ŞAMPİYONLARI (Value Champions Feed)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(Icons.Default.TrendingUp, contentDescription = null, tint = BrandOrange, modifier = Modifier.size(18.dp))
          Text(
            text = "Günün F/P Şampiyonları",
            fontSize = 15.sp,
            fontWeight = FontWeight.ExtraBold,
            color = TextPrimary
          )
        }

        Text(
          text = "${currentBudget} TL Altı (${budgetChampions.size})",
          fontSize = 11.sp,
          color = FpGreen,
          fontWeight = FontWeight.Bold
        )
      }
    }

    // List of food cards under this budget
    items(budgetChampions) { food ->
      FoodCard(
        item = food,
        isFavorite = favoriteIds.contains(food.id),
        onCardClick = { onFoodSelected(food) },
        onToggleFavorite = { onToggleFavorite?.invoke(food) }
      )
    }

    // Notice about trap places
    item {
      val trapCount = foods.count { it.isTrap }
      Surface(
        color = FpRedBg.copy(alpha = 0.25f),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, FpRed.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text("⚠️", fontSize = 16.sp)
          Text(
            text = "Kadıköy çevresinde $trapCount adet parasına değmeyen 'Tuzak Mekan' tespit edildi ve filtrelendi. 'Harita' sekmesinden kırmızı pinleri inceleyebilirsiniz.",
            fontSize = 11.sp,
            color = Color(0xFFFF8A80),
            lineHeight = 15.sp
          )
        }
      }
    }
  }
}
