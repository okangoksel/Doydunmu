package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BrandOrange = Color(0xFFFF5722)
val BrandOrangeLight = Color(0xFFFF8A65)
val BrandOrangeDark = Color(0xFFE64A19)

val DarkSlateBg = Color(0xFF121212)
val DarkSlateSurface = Color(0xFF1E1E24)
val DarkSlateCard = Color(0xFF26262E)
val DarkSlateBorder = Color(0xFF33333F)

val FpGreen = Color(0xFF10B981)
val FpGreenBg = Color(0xFF064E3B)
val FpRed = Color(0xFFEF4444)
val FpRedBg = Color(0xFF7F1D1D)
val FpGold = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
