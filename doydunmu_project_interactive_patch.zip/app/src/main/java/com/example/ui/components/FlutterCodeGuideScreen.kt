package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun FlutterCodeGuideScreen(
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var selectedFileIndex by remember { mutableStateOf(0) }

  val files = listOf(
    Pair("RoomAppDatabase.kt", getRoomDatabaseCode()),
    Pair("FavoriteDao.kt", getFavoritesDaoCode()),
    Pair("pubspec.yaml", getPubspecYamlCode()),
    Pair("lib/main.dart", getMainDartCode()),
    Pair("lib/models/food_item.dart", getFoodItemModelCode()),
    Pair("lib/screens/home_screen.dart", getHomeScreenCode()),
    Pair("lib/screens/map_screen.dart", getMapScreenCode()),
    Pair("lib/screens/dish_detail_screen.dart", getDishDetailScreenCode()),
    Pair("lib/screens/add_review_screen.dart", getAddReviewScreenCode()),
    Pair("supabase_schema.sql", getSupabaseSqlCode())
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Header Info Card
    Card(
      colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
      shape = RoundedCornerShape(16.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, BrandOrange)
    ) {
      Row(
        modifier = Modifier.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Icon(Icons.Default.Info, contentDescription = null, tint = BrandOrange, modifier = Modifier.size(24.dp))
        Column {
          Text(
            text = "Android Studio Flutter Proje Rehberi",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Text(
            text = "Bu sekmeden tüm Flutter dosyalarını sırasıyla kopyalayabilirsin. '1-Tıkla Kopyala' butonuna basman yeterli!",
            fontSize = 11.sp,
            color = TextSecondary,
            lineHeight = 15.sp
          )
        }
      }
    }

    // File Selector Horizontal Tab Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      files.forEachIndexed { index, (fileName, _) ->
        val isSelected = selectedFileIndex == index
        Surface(
          color = if (isSelected) BrandOrange else DarkSlateCard,
          shape = RoundedCornerShape(10.dp),
          border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
          modifier = Modifier.clickable { selectedFileIndex = index }
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Folder,
              contentDescription = null,
              tint = if (isSelected) Color.White else TextSecondary,
              modifier = Modifier.size(14.dp)
            )
            Text(
              text = fileName,
              color = if (isSelected) Color.White else TextSecondary,
              fontSize = 12.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
          }
        }
      }
    }

    // Active File View & Copy Button
    val (activeFileName, activeCode) = files[selectedFileIndex]

    Card(
      colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
      shape = RoundedCornerShape(16.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Toolbar with File Name and Copy Action
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(DarkSlateSurface)
            .padding(horizontal = 14.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Dosya Yolu:", fontSize = 10.sp, color = TextMuted)
            Text(activeFileName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BrandOrange)
          }

          Button(
            onClick = {
              val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
              val clip = ClipData.newPlainText(activeFileName, activeCode)
              clipboard.setPrimaryClip(clip)
              Toast.makeText(context, "$activeFileName panoya kopyalandı!", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("1-Tıkla Kopyala", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }

        // Code Content Display
        LazyColumn(
          modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
        ) {
          item {
            Text(
              text = activeCode,
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              color = Color(0xFFE2E8F0),
              lineHeight = 16.sp
            )
          }
        }
      }
    }
  }
}

// Complete Flutter code snippets stored cleanly
private fun getPubspecYamlCode(): String = """
name: yemegini_ye
description: "Yemeğini Ye - F/P Yemek ve Mekan Rehberi"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.6
  google_fonts: ^6.2.1
  supabase_flutter: ^2.5.6
  flutter_map: ^6.1.0
  latlong2: ^0.9.1
  image_picker: ^1.1.2
  cached_network_image: ^3.3.1

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
""".trimIndent()

private fun getMainDartCode(): String = """
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const YemeginiYeApp());
}

class YemeginiYeApp extends StatelessWidget {
  const YemeginiYeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Yemeğini Ye',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
        primaryColor: const Color(0xFFFF5722),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFF5722),
          secondary: Color(0xFF10B981),
          surface: Color(0xFF1E1E24),
          error: Color(0xFFEF4444),
        ),
        textTheme: GoogleFonts.plusJakartaSansTextTheme(
          ThemeData.dark().textTheme,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
""".trimIndent()

private fun getFoodItemModelCode(): String = """
class FoodItem {
  final String id;
  final String restaurantName;
  final String dishName;
  final int price;
  final int? originalPrice;
  final String category;
  final int fpScore; // %96 F/P Canavarı
  final int satietyScore; // %98 Doyurucu
  final bool isTrap; // Tuzak Mekan
  final String? trapReason;
  final String neighborhood;
  final String imageUrl;
  final int receiptCount;
  final int positiveVotes;
  final int negativeVotes;
  final String systemSummary;
  final double tasteRating;
  final double fullnessRating;
  final String lastVerifiedDate;
  final bool isStudentFriendly;
  final bool isLateNight;
  final double latitude;
  final double longitude;

  FoodItem({
    required this.id,
    required this.restaurantName,
    required this.dishName,
    required this.price,
    this.originalPrice,
    required this.category,
    required this.fpScore,
    required this.satietyScore,
    this.isTrap = false,
    this.trapReason,
    required this.neighborhood,
    required this.imageUrl,
    required this.receiptCount,
    required this.positiveVotes,
    required this.negativeVotes,
    required this.systemSummary,
    required this.tasteRating,
    required this.fullnessRating,
    required this.lastVerifiedDate,
    this.isStudentFriendly = false,
    this.isLateNight = false,
    required this.latitude,
    required this.longitude,
  });

  int get worthItPercentage {
    final total = positiveVotes + negativeVotes;
    if (total == 0) return isTrap ? 20 : 85;
    return ((positiveVotes / total) * 100).toInt();
  }
}
""".trimIndent()

private fun getHomeScreenCode(): String = """
import 'package:flutter/material.dart';
import '../models/food_item.dart';
import 'map_screen.dart';
import 'dish_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double _budget = 200.0;
  String _selectedLocation = 'Kadıköy Moda';

  final List<FoodItem> _mockFoods = [
    FoodItem(
      id: '1',
      restaurantName: 'Hatay Dürüm Dünyası',
      dishName: '70cm Tavuk Zurna Dürüm',
      price: 180,
      originalPrice: 210,
      category: 'Dürüm',
      fpScore: 96,
      satietyScore: 98,
      neighborhood: 'Kadıköy Moda',
      imageUrl: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46',
      receiptCount: 142,
      positiveVotes: 384,
      negativeVotes: 28,
      systemSummary: '200 TL altı en doyurucu zurna dürüm. Lavaşı çıtır, sosu bol.',
      tasteRating: 4.8,
      fullnessRating: 4.9,
      lastVerifiedDate: 'Bugün (Fiş Onaylı)',
      isStudentFriendly: true,
      latitude: 40.9880,
      longitude: 29.0260,
    ),
    FoodItem(
      id: '2',
      restaurantName: 'Boğa Gurme Döner',
      dishName: 'Et Döner Porsiyon (100gr)',
      price: 420,
      category: 'Döner',
      fpScore: 22,
      satietyScore: 30,
      isTrap: true,
      trapReason: '100 gr et için 420 TL istiyorlar, porsiyon çok ufak!',
      neighborhood: 'Kadıköy Boğa',
      imageUrl: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1',
      receiptCount: 89,
      positiveVotes: 12,
      negativeVotes: 180,
      systemSummary: 'Turist tuzağı! Fiyat aşırı yüksek, tabak boş.',
      tasteRating: 2.8,
      fullnessRating: 2.0,
      lastVerifiedDate: 'Bugün (Şikayetli)',
      latitude: 40.9902,
      longitude: 29.0290,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final filtered = _mockFoods.where((f) => f.price <= _budget && !f.isTrap).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Yemeğini Ye', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF1E1E24),
        actions: [
          IconButton(
            icon: const Icon(Icons.map, color: Color(0xFFFF5722)),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => MapScreen(foods: _mockFoods, budget: _budget.toInt())),
              );
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Konum
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E24),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(Icons.location_on, color: Color(0xFFFF5722)),
                const SizedBox(width: 8),
                Text('Konum: ' + _selectedLocation, style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Bütçe Slider
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF26262E),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFFF5722).withOpacity(0.5)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('BÜTÇENİZ', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
                    Text(
                      _budget.toInt().toString() + ' TL',
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFFFF5722)),
                    ),
                  ],
                ),
                Slider(
                  value: _budget,
                  min: 50,
                  max: 500,
                  divisions: 9,
                  activeColor: const Color(0xFFFF5722),
                  onChanged: (v) => setState(() => _budget = v),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text('Günün F/P Şampiyonları', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...filtered.map((item) => Card(
            color: const Color(0xFF26262E),
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              title: Text(item.dishName, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(item.restaurantName + ' · ' + item.lastVerifiedDate),
              trailing: Text(item.price.toString() + ' TL', style: const TextStyle(color: Color(0xFFFF5722), fontWeight: FontWeight.bold, fontSize: 16)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => DishDetailScreen(food: item)),
                );
              },
            ),
          )),
        ],
      ),
    );
  }
}
""".trimIndent()

private fun getMapScreenCode(): String = """
import 'package:flutter/material.dart';
import '../models/food_item.dart';

class MapScreen extends StatelessWidget {
  final List<FoodItem> foods;
  final int budget;

  const MapScreen({super.key, required this.foods, required this.budget});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('F/P Haritası')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.map, size: 64, color: Color(0xFFFF5722)),
            const SizedBox(height: 16),
            Text('Bütçenize Uygun Pinler: ' + budget.toString() + ' TL'),
            const SizedBox(height: 8),
            const Text('Yeşil Pin: F/P Şampiyonu\nKırmızı Pin: Tuzak Mekan', textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
""".trimIndent()

private fun getDishDetailScreenCode(): String = """
import 'package:flutter/material.dart';
import '../models/food_item.dart';

class DishDetailScreen extends StatelessWidget {
  final FoodItem food;

  const DishDetailScreen({super.key, required this.food});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(food.dishName)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(food.restaurantName, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text('Fiyat: ' + food.price.toString() + ' TL', style: const TextStyle(fontSize: 18, color: Color(0xFFFF5722))),
            const SizedBox(height: 16),
            Text('Sistem Raporu:\n' + food.systemSummary),
            const SizedBox(height: 20),
            Text('Doyuruculuk Oranı: %' + food.satietyScore.toString(), style: const TextStyle(color: Colors.green)),
          ],
        ),
      ),
    );
  }
}
""".trimIndent()

private fun getAddReviewScreenCode(): String = """
import 'package:flutter/material.dart';
import '../models/food_item.dart';

class AddReviewScreen extends StatefulWidget {
  final FoodItem food;
  const AddReviewScreen({super.key, required this.food});

  @override
  State<AddReviewScreen> createState() => _AddReviewScreenState();
}

class _AddReviewScreenState extends State<AddReviewScreen> {
  double taste = 5;
  double fullness = 5;
  bool isWorth = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Yorum ve Fiş Ekle')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('Masadan Fişini Yükle, Altın Rozet Kazan!', style: TextStyle(fontWeight: FontWeight.bold)),
            Slider(value: taste, min: 1, max: 5, divisions: 4, onChanged: (v) => setState(() => taste = v)),
            Slider(value: fullness, min: 1, max: 5, divisions: 4, onChanged: (v) => setState(() => fullness = v)),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Değerlendirmeyi Kaydet (+50 Puan)'),
            )
          ],
        ),
      ),
    );
  }
}
""".trimIndent()

private fun getSupabaseSqlCode(): String = """
-- Supabase SQL Şeması (PostgreSQL / PostGIS)
create extension if not exists postgis;

create table restaurants (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  neighborhood text not null,
  location geography(point) not null,
  is_verified boolean default false,
  created_at timestamp with time zone default now()
);

create table dishes (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid references restaurants(id) on delete cascade,
  dish_name text not null,
  price integer not null,
  fp_score integer default 85,
  satiety_score integer default 90,
  is_trap boolean default false,
  trap_reason text,
  system_summary text,
  last_verified timestamp with time zone default now()
);

create table reviews (
  id uuid primary key default gen_random_uuid(),
  dish_id uuid references dishes(id) on delete cascade,
  user_name text not null,
  price_paid integer not null,
  taste_score integer not null,
  fullness_score integer not null,
  is_worth_it boolean not null,
  has_receipt boolean default false,
  comment text,
  created_at timestamp with time zone default now()
);
""".trimIndent()

private fun getRoomDatabaseCode(): String = """
package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [FavoriteFoodEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
  abstract fun favoriteDao(): FavoriteDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "yemeginiye_database"
        ).fallbackToDestructiveMigration().build()
        INSTANCE = instance
        instance
      }
    }
  }
}
""".trimIndent()

private fun getFavoritesDaoCode(): String = """
package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
  @Query("SELECT * FROM favorite_foods ORDER BY savedAtTimestamp DESC")
  fun getAllFavorites(): Flow<List<FavoriteFoodEntity>>

  @Query("SELECT EXISTS(SELECT 1 FROM favorite_foods WHERE id = :id)")
  fun isFavoriteFlow(id: String): Flow<Boolean>

  @Query("SELECT EXISTS(SELECT 1 FROM favorite_foods WHERE id = :id)")
  suspend fun isFavorite(id: String): Boolean

  @Query("SELECT id FROM favorite_foods")
  fun getAllFavoriteIds(): Flow<List<String>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFavorite(favorite: FavoriteFoodEntity)

  @Query("DELETE FROM favorite_foods WHERE id = :id")
  suspend fun deleteFavoriteById(id: String)

  @Delete
  suspend fun deleteFavorite(favorite: FavoriteFoodEntity)

  @Query("DELETE FROM favorite_foods")
  suspend fun clearAllFavorites()
}
""".trimIndent()

