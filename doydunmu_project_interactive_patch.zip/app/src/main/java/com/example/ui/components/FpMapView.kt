package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FoodItem
import com.example.ui.theme.*

@Composable
fun FpMapView(
  foods: List<FoodItem>,
  currentBudget: Int,
  selectedFood: FoodItem?,
  onFoodSelected: (FoodItem?) -> Unit,
  onOpenDishDetail: (FoodItem) -> Unit,
  modifier: Modifier = Modifier
) {
  Box(modifier = modifier.fillMaxSize()) {
    // Canvas stylized dark GPS map of Kadıköy with roads, coast, and landmarks
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
      val canvasWidth = constraints.maxWidth.toFloat()
      val canvasHeight = constraints.maxHeight.toFloat()

      Canvas(
        modifier = Modifier
          .fillMaxSize()
          .pointerInput(Unit) {
            detectTapGestures {
              // Tap outside pin closes selection
              onFoodSelected(null)
            }
          }
      ) {
        // 1. Dark Water Area (Marmara Denizi Shoreline)
        val seaPath = Path().apply {
          moveTo(0f, 0f)
          lineTo(size.width * 0.35f, 0f)
          cubicTo(
            size.width * 0.28f, size.height * 0.35f,
            size.width * 0.12f, size.height * 0.65f,
            size.width * 0.22f, size.height
          )
          lineTo(0f, size.height)
          close()
        }
        drawPath(path = seaPath, color = Color(0xFF0F172A))

        // 2. Land Background
        // Already dark background

        // 3. Shoreline highlight
        drawPath(
          path = seaPath,
          color = Color(0xFF38BDF8).copy(alpha = 0.3f),
          style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f)
        )

        // 4. Stylized Road Grids (Moda Caddesi, Bahariye, Rıhtım)
        val roadColor = Color(0xFF242633)
        val mainRoadColor = Color(0xFF373A4F)

        // Main Avenues
        drawLine(
          color = mainRoadColor,
          start = Offset(size.width * 0.35f, 0f),
          end = Offset(size.width * 0.95f, size.height * 0.7f),
          strokeWidth = 14f
        )
        drawLine(
          color = mainRoadColor,
          start = Offset(size.width * 0.22f, size.height * 0.9f),
          end = Offset(size.width * 0.85f, size.height * 0.1f),
          strokeWidth = 12f
        )

        // Cross Streets
        for (i in 1..7) {
          val y = size.height * (i * 0.13f)
          drawLine(
            color = roadColor,
            start = Offset(size.width * 0.25f, y),
            end = Offset(size.width, y + 40f),
            strokeWidth = 6f
          )
        }
        for (j in 2..7) {
          val x = size.width * (j * 0.12f)
          drawLine(
            color = roadColor,
            start = Offset(x, 0f),
            end = Offset(x - 30f, size.height),
            strokeWidth = 5f
          )
        }

        // Green Park Area (Moda Sahil Parkı)
        drawCircle(
          color = Color(0xFF064E3B).copy(alpha = 0.45f),
          radius = 110f,
          center = Offset(size.width * 0.22f, size.height * 0.45f)
        )
      }

      // Map Landmark Labels
      Box(
        modifier = Modifier
          .offset(x = 16.dp, y = 30.dp)
          .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Text("🌊 Kadıköy Rıhtım Sahil", color = Color(0xFF38BDF8), fontSize = 11.sp)
      }

      Box(
        modifier = Modifier
          .offset(x = (canvasWidth * 0.45f / 3).dp, y = (canvasHeight * 0.85f / 3).dp)
          .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Text("🌳 Moda Parkı & Burnı", color = Color(0xFF34D399), fontSize = 11.sp)
      }

      // Interactive Pins Overlay
      foods.forEach { food ->
        val pinX = (canvasWidth * food.mapX / 3f).dp
        val pinY = (canvasHeight * food.mapY / 3f).dp
        val isSelected = selectedFood?.id == food.id
        val isAffordable = food.price <= currentBudget

        Box(
          modifier = Modifier
            .offset(x = pinX, y = pinY)
            .clickable { onFoodSelected(food) }
        ) {
          MapPinBadge(
            food = food,
            isSelected = isSelected,
            isAffordable = isAffordable
          )
        }
      }
    }

    // Top Legend & Filter Info Chip
    Row(
      modifier = Modifier
        .align(Alignment.TopCenter)
        .padding(top = 16.dp, start = 16.dp, end = 16.dp)
        .fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        color = DarkSlateSurface.copy(alpha = 0.95f),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(modifier = Modifier.size(8.dp).background(FpGreen, CircleShape))
          Text("F/P Şampiyonu", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)

          Text("·", color = TextMuted)

          Box(modifier = Modifier.size(8.dp).background(FpRed, CircleShape))
          Text("Tuzak Mekan", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }

      Surface(
        color = BrandOrange.copy(alpha = 0.9f),
        shape = RoundedCornerShape(12.dp)
      ) {
        Text(
          text = "Bütçe: ${currentBudget} TL",
          color = Color.White,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
      }
    }

    // Bottom Sheet: Appears when a pin is tapped
    AnimatedVisibility(
      visible = selectedFood != null,
      enter = slideInVertically(initialOffsetY = { it }),
      exit = slideOutVertically(targetOffsetY = { it }),
      modifier = Modifier.align(Alignment.BottomCenter)
    ) {
      selectedFood?.let { food ->
        BottomSheetFoodCard(
          food = food,
          onClose = { onFoodSelected(null) },
          onViewDetail = { onOpenDishDetail(food) }
        )
      }
    }
  }
}

@Composable
fun MapPinBadge(
  food: FoodItem,
  isSelected: Boolean,
  isAffordable: Boolean
) {
  val pinColor = when {
    food.isTrap -> FpRed
    isAffordable -> FpGreen
    else -> Color(0xFFF59E0B) // Price exceeds current budget
  }

  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier.shadow(8.dp, RoundedCornerShape(14.dp))
  ) {
    // Pin Label Bubble
    Surface(
      color = if (isSelected) Color.White else pinColor,
      shape = RoundedCornerShape(12.dp),
      border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, pinColor) else null,
      modifier = Modifier.height(34.dp)
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        if (food.isTrap) {
          Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = null,
            tint = if (isSelected) FpRed else Color.White,
            modifier = Modifier.size(13.dp)
          )
        }
        Text(
          text = "${food.price} TL",
          color = if (isSelected) DarkSlateBg else Color.White,
          fontSize = 12.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = if (food.isTrap) "⚠️" else "★ ${food.tasteRating}",
          color = if (isSelected) DarkSlateBg else Color.White.copy(alpha = 0.9f),
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }

    // Triangle arrow pointing down
    Canvas(modifier = Modifier.size(width = 10.dp, height = 6.dp)) {
      val trianglePath = Path().apply {
        moveTo(0f, 0f)
        lineTo(size.width, 0f)
        lineTo(size.width / 2f, size.height)
        close()
      }
      drawPath(trianglePath, color = if (isSelected) Color.White else pinColor)
    }
  }
}

@Composable
fun BottomSheetFoodCard(
  food: FoodItem,
  onClose: () -> Unit,
  onViewDetail: () -> Unit
) {
  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .padding(12.dp)
      .shadow(16.dp, RoundedCornerShape(24.dp)),
    color = DarkSlateSurface,
    shape = RoundedCornerShape(24.dp),
    border = androidx.compose.foundation.BorderStroke(
      width = 1.dp,
      color = if (food.isTrap) FpRed.copy(alpha = 0.5f) else DarkSlateBorder
    )
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // Header: Close and Badges
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          if (food.isTrap) {
            Surface(
              color = FpRed,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = "⚠️ TUZAK MEKAN",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          } else {
            Surface(
              color = FpGreen,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = "🔥 %${food.fpScore} F/P Şampiyonu",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }

          Text(
            text = "Doyuruculuk: %${food.satietyScore}",
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
          )
        }

        IconButton(
          onClick = onClose,
          modifier = Modifier.size(28.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Kapat",
            tint = TextSecondary,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      // Title & Price Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = food.restaurantName,
            color = TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
          )
          Text(
            text = food.dishName,
            color = TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
        }

        Surface(
          color = if (food.isTrap) FpRed else BrandOrange,
          shape = RoundedCornerShape(10.dp)
        ) {
          Text(
            text = "${food.price} TL",
            color = Color.White,
            fontSize = 17.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
          )
        }
      }

      // System Truth Verdict
      Text(
        text = food.systemSummary,
        color = TextSecondary,
        fontSize = 12.sp,
        lineHeight = 16.sp
      )

      // Verification Date & Action CTA Button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = food.lastVerifiedDate,
          color = FpGold,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold
        )

        Button(
          onClick = onViewDetail,
          colors = ButtonDefaults.buttonColors(
            containerColor = if (food.isTrap) FpRed else BrandOrange
          ),
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
          Text(
            text = "İncelemeyi ve Fişleri Gör →",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
