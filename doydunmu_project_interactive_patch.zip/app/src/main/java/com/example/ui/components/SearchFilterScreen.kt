package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FoodItem
import com.example.ui.theme.*
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchFilterScreen(
  foods: List<FoodItem>,
  currentBudget: Int,
  onFoodSelected: (FoodItem) -> Unit,
  modifier: Modifier = Modifier,
  favoriteIds: Set<String> = emptySet(),
  onToggleFavorite: ((FoodItem) -> Unit)? = null
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("Tümü") }
  var priceRange by remember { mutableStateOf(50f..500f) }
  var selectedQuickPrice by remember { mutableStateOf("Tümü") }
  var selectedSmartTag by remember { mutableStateOf("Tümü") }
  var selectedSort by remember { mutableStateOf("F/P Skoru (En Yüksek)") }
  var isFiltersExpanded by remember { mutableStateOf(true) }

  // Yemek kategorileri
  val categories = listOf(
    "Tümü",
    "Kebap",
    "Döner",
    "Lahmacun & Pide",
    "Burger",
    "Ev Yemekleri & Çorba",
    "Sokak Lezzetleri",
    "Kahvaltı & Kafe"
  )

  // Hızlı fiyat aralığı seçenekleri
  val quickPriceOptions = listOf(
    "Tümü",
    "0 - 150 ₺",
    "150 - 250 ₺",
    "250 - 350 ₺",
    "350 ₺+"
  )

  // Akıllı F/P Kriterleri
  val smartTagOptions = listOf(
    "Tümü",
    "Öğrenci Dostu 🎓",
    "En Doyurucu (%90+) ⚡",
    "Parasını Hak Eden 🔥",
    "Gece Açlığı 🌙",
    "Tuzak Mekanlar ⚠️"
  )

  // Sıralama seçenekleri
  val sortOptions = listOf(
    "F/P Skoru (En Yüksek)",
    "Fiyat: En Düşük",
    "Fiyat: En Yüksek",
    "Doyuruculuk",
    "En Yakın Mesafe"
  )

  // Aktif filtre sayısı
  val activeFilterCount = remember(selectedCategory, selectedQuickPrice, priceRange, selectedSmartTag) {
    var count = 0
    if (selectedCategory != "Tümü") count++
    if (selectedQuickPrice != "Tümü" || priceRange.start > 55f || priceRange.endInclusive < 495f) count++
    if (selectedSmartTag != "Tümü") count++
    count
  }

  // Filtreleri sıfırlama fonksiyonu
  val resetFilters = {
    searchQuery = ""
    selectedCategory = "Tümü"
    priceRange = 50f..500f
    selectedQuickPrice = "Tümü"
    selectedSmartTag = "Tümü"
    selectedSort = "F/P Skoru (En Yüksek)"
  }

  // Filtrelenmiş ve sıralanmış liste
  val filteredList = remember(foods, searchQuery, selectedCategory, priceRange, selectedSmartTag, selectedSort) {
    foods.filter { item ->
      // Arama metni
      val matchesQuery = searchQuery.isBlank() ||
        item.dishName.contains(searchQuery, ignoreCase = true) ||
        item.restaurantName.contains(searchQuery, ignoreCase = true) ||
        item.category.contains(searchQuery, ignoreCase = true) ||
        item.neighborhood.contains(searchQuery, ignoreCase = true) ||
        item.systemSummary.contains(searchQuery, ignoreCase = true)

      // Yemek Kategorisi
      val matchesCategory = if (selectedCategory == "Tümü") {
        true
      } else {
        item.category.contains(selectedCategory, ignoreCase = true) ||
          (selectedCategory == "Kebap" && (item.category.contains("Köfte", ignoreCase = true) || item.dishName.contains("Kebap", ignoreCase = true))) ||
          (selectedCategory == "Döner" && (item.category.contains("Dürüm", ignoreCase = true) || item.dishName.contains("Döner", ignoreCase = true)))
      }

      // Fiyat Aralığı
      val minPrice = priceRange.start.roundToInt()
      val maxPrice = priceRange.endInclusive.roundToInt()
      val matchesPrice = item.price in minPrice..maxPrice

      // Akıllı F/P Kriteri
      val matchesSmartTag = when (selectedSmartTag) {
        "Öğrenci Dostu 🎓" -> item.isStudentFriendly
        "En Doyurucu (%90+) ⚡" -> item.satietyScore >= 90
        "Parasını Hak Eden 🔥" -> !item.isTrap && item.fpScore >= 90
        "Gece Açlığı 🌙" -> item.isLateNight
        "Tuzak Mekanlar ⚠️" -> item.isTrap
        else -> true
      }

      matchesQuery && matchesCategory && matchesPrice && matchesSmartTag
    }.sortedWith { a, b ->
      when (selectedSort) {
        "F/P Skoru (En Yüksek)" -> b.fpScore.compareTo(a.fpScore)
        "Fiyat: En Düşük" -> a.price.compareTo(b.price)
        "Fiyat: En Yüksek" -> b.price.compareTo(a.price)
        "Doyuruculuk" -> b.satietyScore.compareTo(a.satietyScore)
        "En Yakın Mesafe" -> a.distanceMeters.compareTo(b.distanceMeters)
        else -> b.fpScore.compareTo(a.fpScore)
      }
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. ARAMA ÇUBUĞU (SEARCH BAR)
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      modifier = Modifier.fillMaxWidth(),
      placeholder = { Text("Yemek adı, döner, kebap, lokanta ara...", color = TextMuted, fontSize = 13.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BrandOrange) },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { searchQuery = "" }) {
            Icon(Icons.Default.Clear, contentDescription = "Temizle", tint = TextSecondary)
          }
        }
      },
      colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = BrandOrange,
        unfocusedBorderColor = DarkSlateBorder,
        focusedContainerColor = DarkSlateSurface,
        unfocusedContainerColor = DarkSlateSurface,
        focusedTextColor = TextPrimary,
        unfocusedTextColor = TextPrimary
      ),
      shape = RoundedCornerShape(14.dp),
      singleLine = true
    )

    // 2. ARAMA FİLTRELERİ BİLEŞENİ (SEARCH FILTERS COMPONENT CARD)
    Card(
      colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
      shape = RoundedCornerShape(16.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, if (activeFilterCount > 0) BrandOrange.copy(alpha = 0.6f) else DarkSlateBorder),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Başlık Satırı & Filtre Paneli Aç/Kapa
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { isFiltersExpanded = !isFiltersExpanded },
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Surface(
              color = BrandOrange.copy(alpha = 0.15f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.size(30.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.Tune,
                  contentDescription = null,
                  tint = BrandOrange,
                  modifier = Modifier.size(16.dp)
                )
              }
            }

            Text(
              text = "Arama Filtreleri",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )

            if (activeFilterCount > 0) {
              Surface(
                color = BrandOrange,
                shape = RoundedCornerShape(12.dp)
              ) {
                Text(
                  text = "$activeFilterCount aktif",
                  color = Color.White,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                )
              }
            }
          }

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            if (activeFilterCount > 0) {
              TextButton(
                onClick = resetFilters,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(28.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.RestartAlt,
                  contentDescription = null,
                  tint = BrandOrangeLight,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(3.dp))
                Text(
                  text = "Sıfırla",
                  color = BrandOrangeLight,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }

            Icon(
              imageVector = if (isFiltersExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
              contentDescription = if (isFiltersExpanded) "Daralt" else "Genişlet",
              tint = TextSecondary,
              modifier = Modifier.size(20.dp)
            )
          }
        }

        // Genişleyebilir Filtre Detayları
        AnimatedVisibility(
          visible = isFiltersExpanded,
          enter = expandVertically() + fadeIn(),
          exit = shrinkVertically() + fadeOut()
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            HorizontalDivider(color = DarkSlateBorder.copy(alpha = 0.6f))

            // A) YEMEK KATEGORİSİ SEÇİMİ (Kebap, Döner, vb.)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "🍽️ Yemek Kategorisi",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
                if (selectedCategory != "Tümü") {
                  Text(
                    text = selectedCategory,
                    color = BrandOrange,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                  )
                }
              }

              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                categories.forEach { category ->
                  val isSelected = selectedCategory == category
                  Surface(
                    color = if (isSelected) BrandOrange else DarkSlateCard,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(
                      1.dp,
                      if (isSelected) BrandOrange else DarkSlateBorder
                    ),
                    modifier = Modifier.clickable {
                      selectedCategory = category
                    }
                  ) {
                    Text(
                      text = category,
                      color = if (isSelected) Color.White else TextSecondary,
                      fontSize = 12.sp,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                      modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                  }
                }
              }
            }

            // B) FİYAT ARALIĞI SEÇİMİ (RangeSlider & Preset Hızlı Çipler)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "💰 Fiyat Aralığı",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
                Surface(
                  color = DarkSlateCard,
                  shape = RoundedCornerShape(8.dp),
                  border = androidx.compose.foundation.BorderStroke(1.dp, FpGreen.copy(alpha = 0.4f))
                ) {
                  Text(
                    text = "${priceRange.start.roundToInt()} ₺ - ${priceRange.endInclusive.roundToInt()} ₺",
                    color = FpGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                  )
                }
              }

              // Çift Başlı Fiyat Aralığı Kaydırıcısı (RangeSlider)
              RangeSlider(
                value = priceRange,
                onValueChange = { range ->
                  priceRange = range
                  selectedQuickPrice = "Özel"
                },
                valueRange = 50f..500f,
                steps = 8,
                colors = SliderDefaults.colors(
                  thumbColor = BrandOrange,
                  activeTrackColor = BrandOrange,
                  inactiveTrackColor = DarkSlateBorder
                ),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(36.dp)
              )

              // Hızlı Fiyat Ön Tanımları
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                quickPriceOptions.forEach { preset ->
                  val isSelected = selectedQuickPrice == preset
                  Surface(
                    color = if (isSelected) BrandOrange.copy(alpha = 0.2f) else DarkSlateCard,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(
                      1.dp,
                      if (isSelected) BrandOrange else DarkSlateBorder
                    ),
                    modifier = Modifier.clickable {
                      selectedQuickPrice = preset
                      priceRange = when (preset) {
                        "0 - 150 ₺" -> 50f..150f
                        "150 - 250 ₺" -> 150f..250f
                        "250 - 350 ₺" -> 250f..350f
                        "350 ₺+" -> 350f..500f
                        else -> 50f..500f
                      }
                    }
                  ) {
                    Text(
                      text = preset,
                      color = if (isSelected) BrandOrange else TextSecondary,
                      fontSize = 11.sp,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                  }
                }
              }
            }

            // C) AKILLI F/P KRİTERLERİ (Öğrenci Dostu, Doyurucu, vb.)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                text = "⚡ Akıllı F/P Kriteri",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )

              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                smartTagOptions.forEach { tag ->
                  val isSelected = selectedSmartTag == tag
                  Surface(
                    color = if (isSelected) Color(0xFF6366F1) else DarkSlateCard,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(
                      1.dp,
                      if (isSelected) Color(0xFF818CF8) else DarkSlateBorder
                    ),
                    modifier = Modifier.clickable { selectedSmartTag = tag }
                  ) {
                    Text(
                      text = tag,
                      color = if (isSelected) Color.White else TextSecondary,
                      fontSize = 11.sp,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                  }
                }
              }
            }

            // D) SIRALAMA SEÇENEĞİ (SORTING)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "Sıralama:",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextMuted
              )

              Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                sortOptions.forEach { sort ->
                  val isSelected = selectedSort == sort
                  Surface(
                    color = if (isSelected) DarkSlateCard else Color.Transparent,
                    shape = RoundedCornerShape(6.dp),
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, BrandOrange) else null,
                    modifier = Modifier.clickable { selectedSort = sort }
                  ) {
                    Text(
                      text = sort,
                      color = if (isSelected) BrandOrange else TextMuted,
                      fontSize = 10.sp,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                      modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // 3. SONUÇ BAŞLIĞI & ÖZETİ
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Text(
          text = "${filteredList.size} Mekan Bulundu",
          color = TextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold
        )
        if (selectedCategory != "Tümü") {
          Surface(
            color = BrandOrange.copy(alpha = 0.2f),
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = selectedCategory,
              color = BrandOrange,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
            )
          }
        }
      }

      Text(
        text = selectedSort,
        color = FpGold,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium
      )
    }

    // 4. SONUÇ LİSTESİ (RESULTS LIST)
    if (filteredList.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentAlignment = Alignment.Center
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.padding(24.dp)
        ) {
          Surface(
            color = DarkSlateSurface,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.size(56.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.FilterAlt,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(28.dp)
              )
            }
          }

          Text(
            text = "Kriterlere Uygun Lezzet Bulunamadı",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )

          Text(
            text = "Seçili fiyat aralığında veya '${selectedCategory}' kategorisinde henüz kayıtlı mekan yok.",
            color = TextMuted,
            fontSize = 12.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = 16.sp
          )

          Button(
            onClick = resetFilters,
            colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.padding(top = 6.dp)
          ) {
            Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("Filtreleri Sıfırla", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
      ) {
        items(filteredList, key = { it.id }) { food ->
          FoodCard(
            item = food,
            isFavorite = favoriteIds.contains(food.id),
            onCardClick = { onFoodSelected(food) },
            onToggleFavorite = { onToggleFavorite?.invoke(food) }
          )
        }
      }
    }
  }
}
