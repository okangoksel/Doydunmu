package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FoodItem
import com.example.ui.theme.*

@Composable
fun FoodCard(
  item: FoodItem,
  onCardClick: () -> Unit,
  modifier: Modifier = Modifier,
  isFavorite: Boolean = false,
  onToggleFavorite: (() -> Unit)? = null
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(20.dp))
      .border(
        width = 1.dp,
        color = if (item.isTrap) FpRed.copy(alpha = 0.4f) else DarkSlateBorder,
        shape = RoundedCornerShape(20.dp)
      )
      .clickable { onCardClick() },
    colors = CardDefaults.cardColors(
      containerColor = DarkSlateCard
    ),
    shape = RoundedCornerShape(20.dp),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column {
      // Dish Image + Badge Overlay
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(180.dp)
      ) {
        Image(
          painter = painterResource(id = item.imageRes),
          contentDescription = item.dishName,
          modifier = Modifier.fillMaxSize(),
          contentScale = ContentScale.Crop
        )

        // Gradient scrim for text legibility
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  Color.Black.copy(alpha = 0.6f),
                  Color.Transparent,
                  Color.Black.copy(alpha = 0.85f)
                )
              )
            )
        )

        // Top Status Badges
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // FP Monster / Trap Badge
          if (item.isTrap) {
            Surface(
              color = FpRed,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.height(28.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Warning,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(14.dp)
                )
                Text(
                  text = "⚠️ PARASINA DEĞMEZ",
                  color = Color.White,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          } else {
            Surface(
              color = FpGreen,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.height(28.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Text(
                  text = "🔥 %${item.fpScore} F/P Canavarı",
                  color = Color.White,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          // Right side badges: Receipts badge & Favorite Heart button
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Surface(
              color = Color.Black.copy(alpha = 0.75f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.height(28.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Receipt,
                  contentDescription = null,
                  tint = FpGold,
                  modifier = Modifier.size(13.dp)
                )
                Text(
                  text = "${item.receiptCount} Fiş",
                  color = FpGold,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }

            if (onToggleFavorite != null) {
              Surface(
                color = if (isFavorite) BrandOrange else Color.Black.copy(alpha = 0.75f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                  .size(28.dp)
                  .clickable { onToggleFavorite() }
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = if (isFavorite) "Favorilerden Çıkar" else "Favorilere Ekle",
                    tint = if (isFavorite) Color.White else Color(0xFFFFB4AB),
                    modifier = Modifier.size(15.dp)
                  )
                }
              }
            }
          }
        }

        // Bottom Image Overlay: Price Tag & Distance
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.BottomStart)
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Bottom
        ) {
          Column {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Text(
                text = item.restaurantName,
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
              )
              Text(text = "•", color = TextMuted, fontSize = 10.sp)
              Text(
                text = "${item.distanceMeters}m (${(item.distanceMeters / 75).coerceAtLeast(1)} dk)",
                color = FpGreen,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
            Text(
              text = item.dishName,
              color = Color.White,
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }

          Column(horizontalAlignment = Alignment.End) {
            if (item.originalPrice != null) {
              Text(
                text = "${item.originalPrice} TL",
                color = TextMuted,
                fontSize = 11.sp,
                textDecoration = TextDecoration.LineThrough
              )
            }
            Surface(
              color = if (item.isTrap) FpRed else BrandOrange,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = "${item.price} TL",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }
        }
      }

      // Card Body Info
      Column(
        modifier = Modifier.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Warning or Praise Reason
        if (item.isTrap && item.trapReason != null) {
          Surface(
            color = FpRedBg.copy(alpha = 0.35f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = item.trapReason,
              color = Color(0xFFFF8A80),
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium,
              modifier = Modifier.padding(8.dp),
              lineHeight = 16.sp
            )
          }
        }

        // Stats Row (Doyuruculuk + Lezzet + Konum)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Satiety
            Text(
              text = "Doyuruculuk: %${item.satietyScore}",
              color = if (item.satietyScore >= 80) FpGreen else TextSecondary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
            Text(text = "·", color = TextMuted)
            // Rating
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                tint = FpGold,
                modifier = Modifier.size(13.dp)
              )
              Text(
                text = "${item.tasteRating}",
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          // Value ratio
          Text(
            text = "%${item.worthItPercentage} Değer",
            color = if (item.worthItPercentage >= 70) FpGreen else FpRed,
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold
          )
        }

        // Divider
        HorizontalDivider(color = DarkSlateBorder, thickness = 0.5.dp)

        // System Summary One-liner
        Text(
          text = item.systemSummary,
          color = TextSecondary,
          fontSize = 12.sp,
          lineHeight = 16.sp,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}
