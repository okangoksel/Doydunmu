package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FoodItem
import com.example.ui.theme.*

@Composable
fun FavoritesScreen(
  favoriteFoods: List<FoodItem>,
  onFoodSelected: (FoodItem) -> Unit,
  onRemoveFavorite: (FoodItem) -> Unit,
  onClearAll: () -> Unit,
  onExploreClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedFilter by remember { mutableStateOf("Tümü") }
  var showClearConfirm by remember { mutableStateOf(false) }

  val filteredFoods = remember(favoriteFoods, selectedFilter) {
    when (selectedFilter) {
      "F/P Canavarları" -> favoriteFoods.filter { it.fpScore >= 90 }
      "200 TL Altı" -> favoriteFoods.filter { it.price <= 200 }
      "En Yakın" -> favoriteFoods.sortedBy { it.distanceMeters }
      else -> favoriteFoods
    }
  }

  val avgFpScore = remember(favoriteFoods) {
    if (favoriteFoods.isEmpty()) 0 else favoriteFoods.map { it.fpScore }.average().toInt()
  }
  val avgPrice = remember(favoriteFoods) {
    if (favoriteFoods.isEmpty()) 0 else favoriteFoods.map { it.price }.average().toInt()
  }

  if (showClearConfirm) {
    AlertDialog(
      onDismissRequest = { showClearConfirm = false },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = FpRed)
          Text("Favorileri Temizle", fontWeight = FontWeight.Bold, color = TextPrimary)
        }
      },
      text = {
        Text(
          "Room yerel veritabanında kayıtlı tüm favori mekanlar silinecektir. Onaylıyor musunuz?",
          color = TextSecondary,
          fontSize = 13.sp
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showClearConfirm = false
            onClearAll()
          },
          colors = ButtonDefaults.buttonColors(containerColor = FpRed)
        ) {
          Text("Tümünü Sil", color = Color.White, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showClearConfirm = false }) {
          Text("Vazgeç", color = TextMuted)
        }
      },
      containerColor = DarkSlateSurface,
      shape = RoundedCornerShape(16.dp)
    )
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Header & Room DB Status Banner
    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Text(
                text = "Favorilerim",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary
              )
              Surface(
                color = BrandOrange.copy(alpha = 0.2f),
                shape = RoundedCornerShape(12.dp)
              ) {
                Text(
                  text = "${favoriteFoods.size} Mekan",
                  color = BrandOrange,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.ExtraBold,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
              }
            }
            Text(
              text = "Kayıtlı F/P canavarları & bütçe dostu lezzetler",
              fontSize = 12.sp,
              color = TextSecondary
            )
          }

          if (favoriteFoods.isNotEmpty()) {
            IconButton(
              onClick = { showClearConfirm = true },
              modifier = Modifier
                .size(36.dp)
                .background(DarkSlateCard, RoundedCornerShape(8.dp))
                .border(0.5.dp, DarkSlateBorder, RoundedCornerShape(8.dp))
            ) {
              Icon(Icons.Default.DeleteOutline, contentDescription = "Tümünü Temizle", tint = TextMuted, modifier = Modifier.size(18.dp))
            }
          }
        }

        // Room DB Tag
        Surface(
          color = Color(0xFF0F172A),
          shape = RoundedCornerShape(10.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.Storage, contentDescription = null, tint = FpGreen, modifier = Modifier.size(15.dp))
            Text(
              text = "Android Room (SQLite) Çevrimdışı Bellek Aktif",
              color = FpGreen,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }

    // 2. Summary stats if items exist
    if (favoriteFoods.isNotEmpty()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
          shape = RoundedCornerShape(16.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("Kayıtlı", fontSize = 11.sp, color = TextMuted)
              Text("${favoriteFoods.size}", fontSize = 18.sp, fontWeight = FontWeight.Black, color = TextPrimary)
            }
            Divider(
              modifier = Modifier
                .height(30.dp)
                .width(1.dp),
              color = DarkSlateBorder
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("Ort. F/P Skoru", fontSize = 11.sp, color = TextMuted)
              Text("%$avgFpScore", fontSize = 18.sp, fontWeight = FontWeight.Black, color = FpGreen)
            }
            Divider(
              modifier = Modifier
                .height(30.dp)
                .width(1.dp),
              color = DarkSlateBorder
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("Ort. Fiyat", fontSize = 11.sp, color = TextMuted)
              Text("$avgPrice TL", fontSize = 18.sp, fontWeight = FontWeight.Black, color = BrandOrange)
            }
          }
        }
      }

      // Filter chips
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("Tümü", "F/P Canavarları", "200 TL Altı", "En Yakın").forEach { filter ->
            val isSelected = selectedFilter == filter
            Surface(
              color = if (isSelected) BrandOrange else DarkSlateCard,
              shape = RoundedCornerShape(20.dp),
              border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isSelected) BrandOrange else DarkSlateBorder
              ),
              modifier = Modifier.weight(1f)
            ) {
              Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                  .padding(vertical = 8.dp)
              ) {
                Text(
                  text = filter,
                  fontSize = 11.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else TextSecondary,
                  textAlign = TextAlign.Center
                )
              }
            }
          }
        }
      }
    }

    // 3. Empty State or Items List
    if (favoriteFoods.isEmpty()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
          shape = RoundedCornerShape(20.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            Surface(
              color = BrandOrange.copy(alpha = 0.15f),
              shape = RoundedCornerShape(24.dp),
              modifier = Modifier.size(72.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  Icons.Default.FavoriteBorder,
                  contentDescription = null,
                  tint = BrandOrange,
                  modifier = Modifier.size(36.dp)
                )
              }
            }

            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Text(
                text = "Henüz Favori Mekanın Yok",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Text(
                text = "Keşfet veya Harita sekmesindeki yemeklerin üzerindeki kalp ikonuna dokunarak Room SQLite veritabanına ekleyebilirsin. İnternetsiz ortamda bile favorilerine kolayca ulaş!",
                fontSize = 12.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
              )
            }

            Button(
              onClick = onExploreClick,
              colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("F/P Mekanlarını Keşfet", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    } else {
      items(filteredFoods, key = { it.id }) { item ->
        FoodCard(
          item = item,
          isFavorite = true,
          onCardClick = { onFoodSelected(item) },
          onToggleFavorite = { onRemoveFavorite(item) }
        )
      }
    }
  }
}
