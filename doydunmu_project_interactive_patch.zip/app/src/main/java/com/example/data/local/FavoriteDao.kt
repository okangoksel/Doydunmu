package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
  @Query("SELECT * FROM favorite_foods ORDER BY savedAtTimestamp DESC")
  fun getAllFavorites(): Flow<List<FavoriteFoodEntity>>

  @Query("SELECT EXISTS(SELECT 1 FROM favorite_foods WHERE id = :id)")
  fun isFavoriteFlow(id: String): Flow<Boolean>

  @Query("SELECT EXISTS(SELECT 1 FROM favorite_foods WHERE id = :id)")
  suspend fun isFavorite(id: String): Boolean

  @Query("SELECT id FROM favorite_foods")
  fun getAllFavoriteIds(): Flow<List<String>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFavorite(favorite: FavoriteFoodEntity)

  @Query("DELETE FROM favorite_foods WHERE id = :id")
  suspend fun deleteFavoriteById(id: String)

  @Delete
  suspend fun deleteFavorite(favorite: FavoriteFoodEntity)

  @Query("DELETE FROM favorite_foods")
  suspend fun clearAllFavorites()
}
