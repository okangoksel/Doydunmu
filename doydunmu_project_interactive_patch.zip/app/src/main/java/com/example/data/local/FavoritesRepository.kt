package com.example.data.local

import com.example.data.FoodItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class FavoritesRepository(private val dao: FavoriteDao) {
  val allFavorites: Flow<List<FoodItem>> = dao.getAllFavorites().map { list ->
    list.map { it.toFoodItem() }
  }

  val favoriteIds: Flow<Set<String>> = dao.getAllFavoriteIds().map { it.toSet() }

  fun isFavoriteFlow(foodId: String): Flow<Boolean> = dao.isFavoriteFlow(foodId)

  suspend fun isFavorite(foodId: String): Boolean = dao.isFavorite(foodId)

  suspend fun toggleFavorite(food: FoodItem): Boolean {
    val exists = dao.isFavorite(food.id)
    if (exists) {
      dao.deleteFavoriteById(food.id)
      return false
    } else {
      dao.insertFavorite(FavoriteFoodEntity.fromFoodItem(food))
      return true
    }
  }

  suspend fun addFavorite(food: FoodItem) {
    dao.insertFavorite(FavoriteFoodEntity.fromFoodItem(food))
  }

  suspend fun removeFavorite(foodId: String) {
    dao.deleteFavoriteById(foodId)
  }

  suspend fun clearAllFavorites() {
    dao.clearAllFavorites()
  }
}
