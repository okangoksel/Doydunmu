package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.FoodItem

@Entity(tableName = "favorite_foods")
data class FavoriteFoodEntity(
  @PrimaryKey
  val id: String,
  val restaurantName: String,
  val dishName: String,
  val price: Int,
  val originalPrice: Int? = null,
  val category: String,
  val fpScore: Int,
  val satietyScore: Int,
  val isTrap: Boolean = false,
  val trapReason: String? = null,
  val neighborhood: String,
  val imageRes: Int,
  val receiptCount: Int,
  val positiveVotes: Int,
  val negativeVotes: Int,
  val systemSummary: String,
  val tasteRating: Float,
  val fullnessRating: Float,
  val lastVerifiedDate: String,
  val isStudentFriendly: Boolean = false,
  val isLateNight: Boolean = false,
  val mapX: Float,
  val mapY: Float,
  val distanceMeters: Int,
  val latitude: Double,
  val longitude: Double,
  val savedAtTimestamp: Long = System.currentTimeMillis()
) {
  fun toFoodItem(): FoodItem = FoodItem(
    id = id,
    restaurantName = restaurantName,
    dishName = dishName,
    price = price,
    originalPrice = originalPrice,
    category = category,
    fpScore = fpScore,
    satietyScore = satietyScore,
    isTrap = isTrap,
    trapReason = trapReason,
    neighborhood = neighborhood,
    imageRes = imageRes,
    receiptCount = receiptCount,
    positiveVotes = positiveVotes,
    negativeVotes = negativeVotes,
    systemSummary = systemSummary,
    tasteRating = tasteRating,
    fullnessRating = fullnessRating,
    lastVerifiedDate = lastVerifiedDate,
    isStudentFriendly = isStudentFriendly,
    isLateNight = isLateNight,
    mapX = mapX,
    mapY = mapY,
    distanceMeters = distanceMeters,
    latitude = latitude,
    longitude = longitude
  )

  companion object {
    fun fromFoodItem(item: FoodItem, timestamp: Long = System.currentTimeMillis()): FavoriteFoodEntity = FavoriteFoodEntity(
      id = item.id,
      restaurantName = item.restaurantName,
      dishName = item.dishName,
      price = item.price,
      originalPrice = item.originalPrice,
      category = item.category,
      fpScore = item.fpScore,
      satietyScore = item.satietyScore,
      isTrap = item.isTrap,
      trapReason = item.trapReason,
      neighborhood = item.neighborhood,
      imageRes = item.imageRes,
      receiptCount = item.receiptCount,
      positiveVotes = item.positiveVotes,
      negativeVotes = item.negativeVotes,
      systemSummary = item.systemSummary,
      tasteRating = item.tasteRating,
      fullnessRating = item.fullnessRating,
      lastVerifiedDate = item.lastVerifiedDate,
      isStudentFriendly = item.isStudentFriendly,
      isLateNight = item.isLateNight,
      mapX = item.mapX,
      mapY = item.mapY,
      distanceMeters = item.distanceMeters,
      latitude = item.latitude,
      longitude = item.longitude,
      savedAtTimestamp = timestamp
    )
  }
}
