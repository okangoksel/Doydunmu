package com.example.data

data class Place(
    val id: String,
    val name: String,
    val subtitle: String,
    val emoji: String,
    val tags: List<String>,
    val avgPriceTl: Int,
    val rating: Float,
    val ratingCount: Int,
    val distanceM: Int,
    val fpPercent: Int,
    val mapX: Float,   // -1..1 (harita üzerindeki yatay konum)
    val mapY: Float    // -1..1 (harita üzerindeki dikey konum)
)

data class Review(
    val id: String,
    val placeId: String,
    val userName: String,
    val text: String,
    val taste: Float,      // 0..5
    val filling: Float,    // 0..5 (doyuruculuk / porsiyon)
    val value: Float,      // 0..5 (fiyat / performans)
    val worth: Boolean,    // "Bu paraya değer mi?"
    val photoUri: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val userAdded: Boolean = true
)

/** Test için örnek veriler. FoodModels.kt'ye dokunulmaz; kendi mekanlarını buraya da ekleyebilirsin. */
object MockData {
    private const val DAY = 86_400_000L
    private fun ago(days: Int) = System.currentTimeMillis() - days * DAY

    val places = listOf(
        Place("zurna-doner", "Zurna Döner", "Dönerci Ali Usta", "🌯",
            listOf("Döner", "Öğrenci Dostu", "En Doyurucu", "F/P Canavarı"),
            180, 4.8f, 1248, 450, 92, -0.5f, -0.6f),
        Place("kofteci-yusuf", "Köfteci Yusuf", "Köfte & Izgara", "🍖",
            listOf("Kebap", "En Doyurucu", "F/P Canavarı"),
            220, 4.5f, 982, 700, 88, 0.5f, -0.2f),
        Place("pizza-locale", "Pizza Locale", "Pizza", "🍕",
            listOf("Pizza", "Parasını Hak Eden"),
            250, 4.3f, 764, 1200, 81, -0.3f, 0.3f),
        Place("mavi-balik", "Mavi Balık", "Balık & Deniz Ürünleri", "🐟",
            listOf("Balık"),
            380, 2.9f, 410, 1500, 54, 0.4f, 0.1f),
        Place("hasan-usta-kebap", "Hasan Usta Kebap", "Kebap", "🍢",
            listOf("Kebap"),
            280, 3.2f, 210, 900, 58, 0.1f, -0.8f),
        Place("safa-ekmek-pasta", "Safa Ekmek & Pasta", "Fırın & Pastane", "🥐",
            listOf("Öğrenci Dostu", "Parasını Hak Eden"),
            120, 4.4f, 310, 300, 85, 0.6f, 0.6f)
    )

    val reviews = listOf(
        Review("r1", "zurna-doner", "Lezzet Avcısı", "Fiyatına göre gerçekten efsane. Çok lezzetli, porsiyon da doyurucu. Kesinlikle tavsiye ederim!",
            4.5f, 4.5f, 5f, true, createdAt = ago(2), userAdded = false),
        Review("r2", "zurna-doner", "Merve T.", "Hem uygun fiyatlı hem de çok lezzetli. Kadıköy'de öğrenciler için harika bir seçenek.",
            4.5f, 4f, 4.5f, true, createdAt = ago(3), userAdded = false),
        Review("r3", "safa-ekmek-pasta", "Ahmet K.", "Ekmek arası çok doyurucu, fiyatına göre harika.",
            4f, 5f, 4.5f, true, createdAt = ago(5), userAdded = false),
        Review("r4", "pizza-locale", "Elif D.", "Lezzetli ama porsiyon biraz küçük.",
            4.5f, 3f, 3.5f, false, createdAt = ago(7), userAdded = false)
    )
}
