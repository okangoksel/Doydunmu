package com.example.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MockData
import com.example.data.Place
import com.example.data.Review
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlin.math.roundToInt

class AppViewModel : ViewModel() {

    private val _reviews = MutableStateFlow(MockData.reviews)
    val reviews: StateFlow<List<Review>> = _reviews.asStateFlow()

    /** Yorumlara göre F/P yüzdesi ve puanı yeniden hesaplanmış mekanlar. */
    val places: StateFlow<List<Place>> = _reviews
        .map { revs -> MockData.places.map { p -> p.withReviews(revs.filter { it.placeId == p.id }) } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, MockData.places)

    var budget by mutableIntStateOf(200)          // Ana sayfadaki slider
    var budgetLimit by mutableStateOf<Int?>(null) // Aramada uygulanan bütçe filtresi
    val favorites = mutableStateListOf<String>()

    fun addReview(r: Review) = _reviews.update { listOf(r) + it }

    fun toggleFav(id: String) {
        if (!favorites.remove(id)) favorites.add(id)
    }
}

private fun Place.withReviews(r: List<Review>): Place {
    if (r.isEmpty()) return this
    val avg = r.map { (it.taste + it.filling + it.value) / 3f }.average().toFloat()
    return copy(
        fpPercent = (avg / 5f * 100).roundToInt(),
        rating = (avg * 10).roundToInt() / 10f,
        ratingCount = ratingCount + r.count { it.userAdded }
    )
}
