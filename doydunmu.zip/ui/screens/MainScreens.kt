package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Place
import com.example.ui.components.*

private val FILTERS = listOf(
    "Tümü", "Öğrenci Dostu", "En Doyurucu", "Parasını Hak Eden", "Döner", "Kebap", "Pizza", "Balık"
)

/* ---------------- 1) ANA SAYFA & BÜTÇE ---------------- */
@Composable
fun HomeScreen(budget: Int, onBudgetChange: (Int) -> Unit, onFind: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Doydunmu", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Orange)
        Text("Bütçene ve konumuna en uygun yemekleri bul!", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Az para, çok lezzet. Doğru seçim senin elinde.")

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Bütçe Aralığın")
                Text("$budget TL", fontSize = 40.sp, fontWeight = FontWeight.Bold)
                Slider(
                    value = budget.toFloat(),
                    onValueChange = { onBudgetChange(it.toInt()) },
                    valueRange = 50f..500f
                )
                Row {
                    Text("50 TL", fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text("500 TL", fontSize = 12.sp)
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, null, tint = Orange)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Konum", fontSize = 12.sp)
                    Text("Kadıköy", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }
        }

        Spacer(Modifier.weight(1f))
        Button(onClick = onFind, modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Icon(Icons.Default.Search, null)
            Spacer(Modifier.width(8.dp))
            Text("En İyisini Bul", fontWeight = FontWeight.Bold)
        }
    }
}

/* ---------------- 2) HARİTA + 3) ALT AÇILIR PENCERE ----------------
 * Şimdilik sahte harita. Gerçek haritaya geçince (maps-compose) pinleri
 * Marker olarak koyup aynı "selected" kartını kullanabilirsin.
 */
@Composable
fun MapScreen(places: List<Place>, onOpen: (Place) -> Unit) {
    var category by remember { mutableStateOf("Tümü") }
    var selected by remember { mutableStateOf<Place?>(null) }
    val shown = places.filter { category == "Tümü" || it.tags.contains(category) }

    Box(Modifier.fillMaxSize().background(Color(0xFF15181C))) {
        Canvas(Modifier.fillMaxSize()) {
            val step = 90f
            var x = 0f
            while (x < size.width) { drawLine(Color(0x14FFFFFF), Offset(x, 0f), Offset(x, size.height)); x += step }
            var y = 0f
            while (y < size.height) { drawLine(Color(0x14FFFFFF), Offset(0f, y), Offset(size.width, y)); y += step }
        }
        Text("Kadıköy", Modifier.align(Alignment.Center), color = Color(0x66FFFFFF), fontSize = 22.sp)

        shown.forEach { p ->
            Surface(
                modifier = Modifier.align(BiasAlignment(p.mapX, p.mapY)).clickable { selected = p },
                color = Color(0xE6000000),
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.5.dp, fpColor(p.fpPercent))
            ) {
                Text(
                    "${p.avgPriceTl} TL | ★ ${p.rating}",
                    Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    fontSize = 12.sp, color = Color.White
                )
            }
        }

        Column(Modifier.align(Alignment.TopCenter).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(shape = RoundedCornerShape(50), color = Color(0xE6000000)) {
                Text("Kadıköy", Modifier.padding(horizontal = 16.dp, vertical = 10.dp), color = Color.White)
            }
            ChipRow(FILTERS, category) { category = it; selected = null }
        }

        selected?.let { p ->
            Card(Modifier.align(Alignment.BottomCenter).padding(12.dp).fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PlaceThumb(p, 72)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(p.subtitle, fontSize = 12.sp)
                            Text("★ ${p.rating} (${p.ratingCount})  •  ${p.distanceM} m", fontSize = 12.sp, color = Orange)
                        }
                        IconButton(onClick = { selected = null }) { Icon(Icons.Default.Close, "Kapat") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        FpBadge(p.fpPercent, "F/P")
                        Text(p.tags.take(3).joinToString(" • "), fontSize = 11.sp)
                    }
                    Text("${p.avgPriceTl} TL (Ortalama fiyat)", fontWeight = FontWeight.Bold)
                    Button(onClick = { onOpen(p) }, modifier = Modifier.fillMaxWidth()) { Text("Detayları Gör") }
                }
            }
        }
    }
}

/* ---------------- 4) ARAMA & FİLTRELER ---------------- */
@Composable
fun SearchScreen(
    places: List<Place>,
    budgetLimit: Int?,
    onClearBudget: () -> Unit,
    onOpen: (Place) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Tümü") }

    val result = places
        .filter { p -> budgetLimit == null || p.avgPriceTl <= budgetLimit }
        .filter { p -> filter == "Tümü" || p.tags.contains(filter) }
        .filter { p ->
            query.isBlank() ||
                p.name.contains(query, ignoreCase = true) ||
                p.subtitle.contains(query, ignoreCase = true) ||
                p.tags.any { it.contains(query, ignoreCase = true) }
        }
        .sortedByDescending { it.fpPercent }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("Mekan, yemek veya bölge ara...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
        )
        ChipRow(FILTERS, filter) { filter = it }
        if (budgetLimit != null) {
            AssistChip(
                onClick = onClearBudget,
                label = { Text("Bütçe: en çok $budgetLimit TL  ✕") }
            )
        }
        if (result.isEmpty()) Text("Sonuç bulunamadı.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(result, key = { it.id }) { p -> PlaceCard(p) { onOpen(p) } }
        }
    }
}

/* ---------------- FAVORİLER ---------------- */
@Composable
fun FavoritesScreen(places: List<Place>, favoriteIds: List<String>, onOpen: (Place) -> Unit) {
    val favs = places.filter { it.id in favoriteIds }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Favoriler", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (favs.isEmpty()) Text("Henüz favori mekan yok. Mekan detayında kalbe dokun.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(favs, key = { it.id }) { p -> PlaceCard(p) { onOpen(p) } }
        }
    }
}

/* ---------------- PROFİL ---------------- */
@Composable
fun ProfileScreen(myReviewCount: Int, favoriteCount: Int) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Profil", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Yorumlarım: $myReviewCount")
                Text("Favorilerim: $favoriteCount")
            }
        }
    }
}
