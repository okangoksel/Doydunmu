package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Place
import com.example.data.Review
import com.example.ui.components.*
import java.util.UUID

/* ---------------- 5) MEKAN DETAYI ---------------- */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaceDetailScreen(
    place: Place,
    reviews: List<Review>,
    isFav: Boolean,
    onFav: () -> Unit,
    onBack: () -> Unit,
    onWriteReview: () -> Unit
) {
    val photos = reviews.mapNotNull { it.photoUri }
    val avgTaste = if (reviews.isEmpty()) 0f else reviews.map { it.taste }.average().toFloat()
    val avgFilling = if (reviews.isEmpty()) 0f else reviews.map { it.filling }.average().toFloat()
    val avgValue = if (reviews.isEmpty()) 0f else reviews.map { it.value }.average().toFloat()
    val worthPercent = if (reviews.isEmpty()) 0 else reviews.count { it.worth } * 100 / reviews.size

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Mekan Detayı") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") }
                },
                actions = {
                    IconButton(onClick = onFav) {
                        Icon(
                            if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            "Favori", tint = Orange
                        )
                    }
                }
            )
        },
        bottomBar = {
            Button(
                onClick = onWriteReview,
                modifier = Modifier.fillMaxWidth().padding(12.dp).height(52.dp)
            ) { Text("Yorum Yaz", fontWeight = FontWeight.Bold) }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    FpGauge(place.fpPercent)
                    Text(place.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(place.subtitle, fontSize = 13.sp)
                    Text(
                        "★ ${place.rating} (${place.ratingCount} değerlendirme)  •  ${place.distanceM} m",
                        color = Orange, fontSize = 13.sp
                    )
                    Text("Ortalama ${place.avgPriceTl} TL", fontWeight = FontWeight.Bold)
                }
            }

            if (reviews.isNotEmpty()) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            ScoreBar("Lezzet", avgTaste)
                            ScoreBar("Doyuruculuk / Porsiyon", avgFilling)
                            ScoreBar("Fiyat / Performans", avgValue)
                            Text("Yorum yapanların %$worthPercent'i \"Bu paraya değer\" diyor.", fontSize = 13.sp)
                        }
                    }
                }
            }

            item { Text("Fotoğraflar (${photos.size})", fontWeight = FontWeight.Bold) }
            item {
                if (photos.isEmpty()) {
                    Text("Henüz fotoğraf yok. İlk fotoğrafı sen ekle!", fontSize = 13.sp)
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(photos) { uri ->
                            AsyncImage(
                                model = uri, contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(110.dp).clip(RoundedCornerShape(10.dp))
                            )
                        }
                    }
                }
            }

            item { Text("Kullanıcı Yorumları (${reviews.size})", fontWeight = FontWeight.Bold) }
            if (reviews.isEmpty()) item { Text("Henüz yorum yok.") }
            items(reviews, key = { it.id }) { ReviewItem(it) }
        }
    }
}

@Composable
private fun ScoreBar(label: String, score: Float) {
    Column {
        Row {
            Text(label, Modifier.weight(1f), fontSize = 13.sp)
            Text("%.1f".format(score), fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(
            progress = { score / 5f },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = Orange
        )
    }
}

@Composable
private fun ReviewItem(r: Review) {
    val days = ((System.currentTimeMillis() - r.createdAt) / 86_400_000L).toInt()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(r.userName, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (r.worth) FpBadge(100, "Değer")
            }
            if (r.text.isNotBlank()) Text(r.text, fontSize = 13.sp)
            r.photoUri?.let {
                AsyncImage(
                    model = it, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(10.dp))
                )
            }
            Text(
                "Lezzet ${r.taste}  •  Doyuruculuk ${r.filling}  •  F/P ${r.value}",
                fontSize = 11.sp
            )
            Text(if (days <= 0) "Bugün" else "$days gün önce", fontSize = 11.sp, color = Color.Gray)
        }
    }
}

/* ---------------- 6) YORUM EKLEME ---------------- */
@Composable
fun AddReviewScreen(place: Place, onClose: () -> Unit, onSubmit: (Review) -> Unit) {
    var taste by remember { mutableFloatStateOf(4f) }
    var filling by remember { mutableFloatStateOf(4f) }
    var value by remember { mutableFloatStateOf(4f) }
    var worth by remember { mutableStateOf<Boolean?>(null) }
    var text by remember { mutableStateOf("") }
    var photo by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) photo = uri.toString()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Kapat") }
            Text("Yorum Ekle", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        }
        Text(place.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)

        Box(
            Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF2A2A2A))
                .clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            contentAlignment = Alignment.Center
        ) {
            if (photo != null) {
                AsyncImage(
                    model = photo, contentDescription = null,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                )
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📷", fontSize = 36.sp)
                    Text("Fotoğraf Ekle")
                }
            }
        }
        Text("Yemeğini veya fiyat fişini fotoğraflayarak yorumunu daha etkili hale getir.", fontSize = 12.sp)

        ScoreSlider("Lezzet", taste) { taste = it }
        ScoreSlider("Doyuruculuk", filling) { filling = it }
        ScoreSlider("Fiyat / Performans", value) { value = it }

        OutlinedTextField(
            value = text, onValueChange = { text = it },
            label = { Text("Yorumun") }, minLines = 3, modifier = Modifier.fillMaxWidth()
        )

        Text("Bu Paraya Değer mi?", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { worth = true },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (worth == true) FpGreen else Color(0xFF333333),
                    contentColor = Color.White
                )
            ) { Text("EVET") }
            Button(
                onClick = { worth = false },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (worth == false) FpRed else Color(0xFF333333),
                    contentColor = Color.White
                )
            ) { Text("HAYIR") }
        }

        Button(
            onClick = {
                onSubmit(
                    Review(
                        id = UUID.randomUUID().toString(),
                        placeId = place.id,
                        userName = "Sen",
                        text = text.trim(),
                        taste = taste, filling = filling, value = value,
                        worth = worth == true,
                        photoUri = photo
                    )
                )
            },
            enabled = worth != null,
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("Yorumu Gönder", fontWeight = FontWeight.Bold) }
        if (worth == null) Text("Göndermek için \"Bu paraya değer mi?\" sorusunu yanıtla.", fontSize = 12.sp)
    }
}

@Composable
private fun ScoreSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Column {
        Row {
            Text(label, Modifier.weight(1f))
            Text("%.1f".format(value), fontWeight = FontWeight.Bold, color = Orange)
        }
        Slider(value = value, onValueChange = onChange, valueRange = 0f..5f, steps = 9)
    }
}
