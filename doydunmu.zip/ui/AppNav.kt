package com.example.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.components.AppBottomBar
import com.example.ui.screens.*

private val MAIN_ROUTES = listOf("home", "map", "search", "favorites", "profile")

@Composable
fun AppNav(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val places by vm.places.collectAsStateWithLifecycle()
    val reviews by vm.reviews.collectAsStateWithLifecycle()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route

    fun goMain(r: String) {
        nav.navigate(r) {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    fun openPlace(id: String) = nav.navigate("detail/$id")

    Scaffold(
        bottomBar = { if (route in MAIN_ROUTES) AppBottomBar(route) { goMain(it) } }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {

            composable("home") {
                HomeScreen(
                    budget = vm.budget,
                    onBudgetChange = { vm.budget = it },
                    onFind = { vm.budgetLimit = vm.budget; goMain("search") }
                )
            }
            composable("map") { MapScreen(places) { openPlace(it.id) } }
            composable("search") {
                SearchScreen(places, vm.budgetLimit, { vm.budgetLimit = null }) { openPlace(it.id) }
            }
            composable("favorites") {
                FavoritesScreen(places, vm.favorites) { openPlace(it.id) }
            }
            composable("profile") {
                ProfileScreen(reviews.count { it.userAdded }, vm.favorites.size)
            }

            composable(
                "detail/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { e ->
                val id = e.arguments?.getString("id").orEmpty()
                places.firstOrNull { it.id == id }?.let { place ->
                    PlaceDetailScreen(
                        place = place,
                        reviews = reviews.filter { it.placeId == id },
                        isFav = vm.favorites.contains(id),
                        onFav = { vm.toggleFav(id) },
                        onBack = { nav.popBackStack() },
                        onWriteReview = { nav.navigate("review/$id") }
                    )
                }
            }

            composable(
                "review/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { e ->
                val id = e.arguments?.getString("id").orEmpty()
                places.firstOrNull { it.id == id }?.let { place ->
                    AddReviewScreen(
                        place = place,
                        onClose = { nav.popBackStack() },
                        onSubmit = { vm.addReview(it); nav.popBackStack() }
                    )
                }
            }
        }
    }
}
