package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Place

val Orange = Color(0xFFFF6A00)
val FpGreen = Color(0xFF22C55E)
val FpRed = Color(0xFFEF4444)

fun fpColor(percent: Int): Color = when {
    percent >= 80 -> FpGreen
    percent >= 65 -> Orange
    else -> FpRed
}

@Composable
fun AppBottomBar(current: String?, onNavigate: (String) -> Unit) {
    val items = listOf(
        Triple("home", "Ana Sayfa", Icons.Default.Home),
        Triple("map", "Harita", Icons.Default.Place),
        Triple("search", "Ara", Icons.Default.Search),
        Triple("favorites", "Favoriler", Icons.Default.Favorite),
        Triple("profile", "Profil", Icons.Default.Person)
    )
    NavigationBar {
        items.forEach { (route, label, icon) ->
            NavigationBarItem(
                selected = current == route,
                onClick = { onNavigate(route) },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label, fontSize = 10.sp) }
            )
        }
    }
}

@Composable
fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { o ->
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(o) })
        }
    }
}

@Composable
fun FpBadge(percent: Int, label: String = "F/P") {
    Surface(color = fpColor(percent), shape = RoundedCornerShape(50)) {
        Text(
            "%$percent $label",
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold
        )
    }
}

/** Fotoğraf yerine emoji kutusu (gerçek fotoğraflar Supabase'ten gelince AsyncImage ile değişir). */
@Composable
fun PlaceThumb(place: Place, size: Int = 84) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF2A2A2A)),
        contentAlignment = Alignment.Center
    ) { Text(place.emoji, fontSize = (size / 2).sp) }
}

@Composable
fun PlaceCard(place: Place, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PlaceThumb(place)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(place.name, fontWeight = FontWeight.Bold)
                Text(place.subtitle, fontSize = 12.sp)
                Text("★ ${place.rating} (${place.ratingCount})", fontSize = 12.sp, color = Orange)
                Text(place.tags.take(2).joinToString(" • "), fontSize = 11.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${place.avgPriceTl} TL", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    FpBadge(place.fpPercent)
                }
            }
        }
    }
}

@Composable
fun FpGauge(percent: Int, modifier: Modifier = Modifier) {
    val color = fpColor(percent)
    Box(modifier.size(170.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val pad = 16f
            val arcSize = Size(size.width - pad * 2, size.height - pad * 2)
            val stroke = Stroke(width = 22f, cap = StrokeCap.Round)
            drawArc(Color(0x33FFFFFF), 150f, 240f, false, Offset(pad, pad), arcSize, style = stroke)
            drawArc(color, 150f, 240f * percent / 100f, false, Offset(pad, pad), arcSize, style = stroke)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("%$percent", fontSize = 38.sp, fontWeight = FontWeight.Bold)
            Text("DEĞER", fontSize = 12.sp)
        }
    }
}

val DarkBorder = BorderStroke(1.dp, Color(0x33FFFFFF))
